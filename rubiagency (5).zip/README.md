# Rubi Agency - Website Oficial

Agência especializada em marketing digital, desenvolvimento web e estratégias de crescimento para empresas.

## 🚀 Tecnologias Utilizadas

- **Next.js 15** - Framework React para produção
- **TypeScript** - Tipagem estática
- **Tailwind CSS** - Framework CSS utilitário
- **Supabase** - Backend como serviço
- **Framer Motion** - Animações
- **Radix UI** - Componentes acessíveis
- **React Hook Form** - Gerenciamento de formulários
- **Zod** - Validação de esquemas

## 📦 Instalação

1. Clone o repositório:
\`\`\`bash
git clone https://github.com/GrowthSolutionsAI/v0-rubiagency-lancamento.git
cd v0-rubiagency-lancamento
\`\`\`

2. Instale as dependências:
\`\`\`bash
pnpm install
\`\`\`

3. Configure as variáveis de ambiente:
\`\`\`bash
cp .env.example .env.local
\`\`\`

4. Execute o projeto em desenvolvimento:
\`\`\`bash
pnpm dev
\`\`\`

## 🌐 Deploy

### Vercel (Recomendado)

1. Conecte seu repositório ao Vercel
2. Configure as variáveis de ambiente
3. Deploy automático a cada push

### Configurações do Vercel:

- **Framework Preset:** Next.js
- **Build Command:** `pnpm run build`
- **Install Command:** `pnpm install`
- **Node.js Version:** 18.x
- **Root Directory:** `./`

## 🔧 Variáveis de Ambiente

\`\`\`bash
# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

# Email SMTP
EMAIL_FROM=
SMTP_HOST=
SMTP_PORT=
SMTP_SECURE=
SMTP_USER=
SMTP_PASS=

# Site
NEXT_PUBLIC_SITE_URL=
NEXT_PUBLIC_APP_URL=
ADMIN_EMAIL=
\`\`\`

## 📁 Estrutura do Projeto

\`\`\`
├── app/                    # App Router (Next.js 13+)
│   ├── admin/             # Painel administrativo
│   ├── api/               # API Routes
│   ├── blog/              # Blog
│   └── globals.css        # Estilos globais
├── components/            # Componentes React
│   ├── ui/               # Componentes base (shadcn/ui)
│   └── ...               # Componentes específicos
├── lib/                  # Utilitários e configurações
├── public/               # Arquivos estáticos
├── scripts/              # Scripts SQL e utilitários
└── styles/               # Estilos adicionais
\`\`\`

## 🎨 Funcionalidades

- ✅ Landing page responsiva
- ✅ Formulário de contato
- ✅ Sistema de blog
- ✅ Painel administrativo
- ✅ Sistema de parceiros
- ✅ Integração com email
- ✅ SEO otimizado
- ✅ Modo escuro/claro
- ✅ Multilíngue (PT/EN)

## 📧 Configuração de Email

O sistema suporta SMTP para envio de emails. Configure as variáveis:

\`\`\`bash
SMTP_HOST=smtp.gmail.com
SMTP_PORT=465
SMTP_SECURE=true
SMTP_USER=seu-email@gmail.com
SMTP_PASS=sua-senha-de-app
\`\`\`

## 🗄️ Banco de Dados

O projeto usa Supabase como backend. Execute os scripts SQL na pasta `scripts/` para configurar as tabelas.

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 📞 Contato

- **Website:** [www.rubiagency.com](https://www.rubiagency.com)
- **Email:** contato@rubiagency.com
- **Instagram:** [@rubiagency.br](https://instagram.com/rubiagency.br)

---

Desenvolvido com ❤️ pela equipe Rubi Agency
