# 🚀 Guia de Deploy via Vercel CLI

## Pré-requisitos
- Node.js 18+
- pnpm instalado
- Conta no Vercel

## 📦 Passo 1: Instalar Vercel CLI

\`\`\`bash
# Instalar globalmente
npm install -g vercel

# Verificar instalação
vercel --version
\`\`\`

## 🔐 Passo 2: Fazer Login

\`\`\`bash
# Login no Vercel
vercel login

# Verificar se está logado
vercel whoami
\`\`\`

## ⚙️ Passo 3: Configurar Projeto

\`\`\`bash
# Na pasta do projeto
cd rubiagency

# Instalar dependências
pnpm install

# Configurar projeto Vercel
vercel
\`\`\`

**Configurações durante o setup:**
- **Set up and deploy?** → Y
- **Which scope?** → Sua conta pessoal
- **Link to existing project?** → N
- **Project name?** → rubiagency
- **In which directory?** → ./
- **Want to modify settings?** → N

## 🔧 Passo 4: Adicionar Variáveis de Ambiente

\`\`\`bash
# Supabase
vercel env add NEXT_PUBLIC_SUPABASE_URL
# Cole: https://lovnfxbjqclblzizokcn.supabase.co

vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY
# Cole sua chave anônima

vercel env add SUPABASE_SERVICE_ROLE_KEY
# Cole sua chave de serviço

# Email SMTP
vercel env add EMAIL_FROM
# Cole: contato@rubiagency.com

vercel env add SMTP_HOST
# Cole: smtp.gmail.com

vercel env add SMTP_PORT
# Cole: 465

vercel env add SMTP_SECURE
# Cole: true

vercel env add SMTP_USER
# Cole: contato@rubiagency.com

vercel env add SMTP_PASS
# Cole: ymxmutrfrtzkeice

# URLs do Site
vercel env add NEXT_PUBLIC_APP_URL
# Cole: https://rubiagency.vercel.app (ou seu domínio)

vercel env add ADMIN_EMAIL
# Cole: admin@rubiagency.com
\`\`\`

## 🚀 Passo 5: Deploy Final

\`\`\`bash
# Deploy para produção
vercel --prod

# Ou apenas
vercel
\`\`\`

## 🌐 Passo 6: Configurar Domínio (Opcional)

\`\`\`bash
# Adicionar domínio personalizado
vercel domains add rubiagency.com

# Configurar DNS
# Aponte seu domínio para: 76.76.19.61
\`\`\`

## ✅ Verificações Pós-Deploy

1. **Site funcionando:** Acesse a URL fornecida
2. **Formulário:** Teste o formulário de contato
3. **Admin:** Acesse `/admin` e faça login
4. **Email:** Verifique se emails estão sendo enviados

## 🔄 Comandos Úteis

\`\`\`bash
# Ver deployments
vercel ls

# Ver logs
vercel logs

# Remover projeto
vercel remove

# Ver domínios
vercel domains ls

# Redeploy
vercel --prod
\`\`\`

## 🆘 Solução de Problemas

### Build Error
\`\`\`bash
# Testar build local
pnpm build

# Ver logs detalhados
vercel logs --follow
\`\`\`

### Environment Variables
\`\`\`bash
# Listar variáveis
vercel env ls

# Remover variável
vercel env rm VARIABLE_NAME
\`\`\`

### Domínio não funciona
\`\`\`bash
# Verificar DNS
nslookup rubiagency.com

# Verificar configuração
vercel domains inspect rubiagency.com
\`\`\`

---

**🎉 Com esses passos, seu site estará online em poucos minutos!**
