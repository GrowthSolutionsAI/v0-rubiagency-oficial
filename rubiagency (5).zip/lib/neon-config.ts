import { neon } from "@neondatabase/serverless"

// Configurações do banco de dados (apenas server-side)
export function getDatabaseUrl(): string {
  // Prioridade: env vars > fallback
  const urls = [
    process.env.DATABASE_URL,
    process.env.POSTGRES_URL,
    process.env.NEON_DATABASE_URL,
    process.env.POSTGRES_PRISMA_URL,
  ]

  const validUrl = urls.find((url) => url && url.trim() !== "")

  if (!validUrl) {
    throw new Error("❌ Nenhuma URL de banco de dados encontrada")
  }

  console.log("🔗 Usando URL do banco:", validUrl.substring(0, 30) + "...")
  return validUrl
}

// Cliente Neon principal (com pooling)
export const sql = neon(getDatabaseUrl())

// Cliente sem pooling para operações específicas
export const sqlUnpooled = neon(
  process.env.DATABASE_URL_UNPOOLED || process.env.POSTGRES_URL_NON_POOLING || getDatabaseUrl(),
)

// Função para testar conexão com ambos os clientes
export async function testNeonConnection() {
  const results = {
    pooled: null as any,
    unpooled: null as any,
    summary: {
      success: false,
      message: "",
      errors: [] as string[],
    },
  }

  try {
    console.log("🔄 Testando conexão com pooling...")

    // Teste com pooling
    try {
      const pooledResult = await sql`SELECT 
        version() as postgres_version,
        current_database() as database_name,
        current_user as user_name,
        NOW() as current_time,
        'pooled' as connection_type
      `

      results.pooled = {
        success: true,
        data: pooledResult[0],
        message: "Conexão com pooling estabelecida",
      }
      console.log("✅ Conexão pooled OK")
    } catch (error) {
      results.pooled = {
        success: false,
        error: error.message,
        message: "Falha na conexão com pooling",
      }
      results.summary.errors.push(`Pooled: ${error.message}`)
      console.error("❌ Erro pooled:", error.message)
    }

    // Teste sem pooling
    try {
      const unpooledResult = await sqlUnpooled`SELECT 
        version() as postgres_version,
        current_database() as database_name,
        current_user as user_name,
        NOW() as current_time,
        'unpooled' as connection_type
      `

      results.unpooled = {
        success: true,
        data: unpooledResult[0],
        message: "Conexão sem pooling estabelecida",
      }
      console.log("✅ Conexão unpooled OK")
    } catch (error) {
      results.unpooled = {
        success: false,
        error: error.message,
        message: "Falha na conexão sem pooling",
      }
      results.summary.errors.push(`Unpooled: ${error.message}`)
      console.error("❌ Erro unpooled:", error.message)
    }

    // Resumo
    const successCount = [results.pooled?.success, results.unpooled?.success].filter(Boolean).length

    if (successCount === 2) {
      results.summary = {
        success: true,
        message: "Ambas as conexões (pooled e unpooled) funcionando perfeitamente!",
        errors: [],
      }
    } else if (successCount === 1) {
      results.summary = {
        success: true,
        message: "Uma conexão funcionando. Sistema operacional.",
        errors: results.summary.errors,
      }
    } else {
      results.summary = {
        success: false,
        message: "Nenhuma conexão estabelecida. Verifique as configurações.",
        errors: results.summary.errors,
      }
    }

    return results
  } catch (error) {
    console.error("❌ Erro geral na conexão:", error)
    return {
      pooled: null,
      unpooled: null,
      summary: {
        success: false,
        message: "Erro crítico na conexão",
        errors: [error.message],
      },
    }
  }
}

// Função para validar estrutura das tabelas
export async function validateDatabaseStructure() {
  try {
    console.log("🔄 Validando estrutura do banco...")

    // Verificar se as tabelas existem
    const tables = await sql`
      SELECT table_name, table_type
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_type = 'BASE TABLE'
      ORDER BY table_name
    `

    const expectedTables = ["user_registrations", "user_files", "system_settings", "admin_users"]

    const existingTables = tables.map((t) => t.table_name)
    const missingTables = expectedTables.filter((t) => !existingTables.includes(t))

    // Verificar estrutura específica da tabela user_registrations
    let userRegistrationsStructure = null
    if (existingTables.includes("user_registrations")) {
      userRegistrationsStructure = await sql`
        SELECT column_name, data_type, is_nullable, column_default
        FROM information_schema.columns 
        WHERE table_name = 'user_registrations'
        ORDER BY ordinal_position
      `
    }

    // Verificar se campo Instagram existe
    const hasInstagramField = userRegistrationsStructure?.some((col) => col.column_name === "instagram")

    return {
      success: missingTables.length === 0,
      message:
        missingTables.length === 0
          ? "Estrutura do banco validada com sucesso"
          : `Tabelas faltando: ${missingTables.join(", ")}`,
      tables: existingTables,
      missingTables,
      userRegistrationsStructure,
      hasInstagramField,
      recommendations:
        missingTables.length > 0
          ? [
              "Execute o script: scripts/001-create-tables.sql",
              "Execute o script: scripts/008-add-instagram-field.sql",
              "Verifique as permissões do usuário no banco",
            ]
          : [],
    }
  } catch (error) {
    console.error("❌ Erro na validação da estrutura:", error)
    return {
      success: false,
      error: error.message,
      message: "Falha na validação da estrutura do banco",
      recommendations: [
        "Verifique se o banco de dados existe",
        "Confirme as permissões do usuário",
        "Execute os scripts de criação das tabelas",
      ],
    }
  }
}

// Função para obter estatísticas detalhadas
export async function getDatabaseStats() {
  try {
    // Estatísticas básicas
    const basicStats = await sql`
      SELECT 
        (SELECT COUNT(*) FROM user_registrations) as total_registrations,
        (SELECT COUNT(*) FROM user_registrations WHERE status = 'pending') as pending_registrations,
        (SELECT COUNT(*) FROM user_registrations WHERE status = 'approved') as approved_registrations,
        (SELECT COUNT(*) FROM user_registrations WHERE status = 'rejected') as rejected_registrations,
        (SELECT COUNT(*) FROM system_settings) as total_settings,
        (SELECT COUNT(*) FROM admin_users) as total_admin_users
    `

    // Estatísticas por período
    const periodStats = await sql`
      SELECT 
        DATE_TRUNC('day', created_at) as date,
        COUNT(*) as registrations_count
      FROM user_registrations 
      WHERE created_at >= NOW() - INTERVAL '7 days'
      GROUP BY DATE_TRUNC('day', created_at)
      ORDER BY date DESC
    `

    // Últimos registros
    const recentRegistrations = await sql`
      SELECT id, name, email, instagram, status, created_at
      FROM user_registrations 
      ORDER BY created_at DESC 
      LIMIT 5
    `

    return {
      success: true,
      data: {
        ...basicStats[0],
        periodStats,
        recentRegistrations,
      },
    }
  } catch (error) {
    console.error("❌ Erro ao obter estatísticas:", error)
    return {
      success: false,
      error: error.message,
      message: "Falha ao obter estatísticas do banco",
    }
  }
}

// Função para executar query com logs detalhados
export async function executeQuery(query: string, params: any[] = []) {
  try {
    console.log("🔄 Executando query:", query.substring(0, 100) + "...")
    const startTime = Date.now()

    const result = await sql(query, params)

    const duration = Date.now() - startTime
    console.log(`✅ Query executada em ${duration}ms`)

    return {
      success: true,
      data: result,
      duration,
      rowCount: Array.isArray(result) ? result.length : 0,
    }
  } catch (error) {
    console.error("❌ Erro na execução da query:", error)
    return {
      success: false,
      error: error.message,
      query: query.substring(0, 200) + "...",
    }
  }
}

// Export do cliente principal
export { sql as default }
