"use client"

import type React from "react"

import { useState, useEffect, useCallback } from "react"

// Re-export from client-dynamic-components
export {
  LineChart,
  BarChart,
  PieChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Line,
  Bar,
  Cell,
  ResponsiveContainer,
  DatePicker,
  SketchPicker,
  ChromePicker,
  CompactPicker,
  MotionDiv,
  MotionSpan,
  AnimatePresence,
  safeWindow,
  safeDocument,
  safeLocalStorage,
  safeSessionStorage,
  safeNavigator,
} from "./client-dynamic-components"

// Client-only hooks
export const useIsClient = () => {
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
  }, [])

  return isClient
}

export const useLocalStorage = <T,>(key: string, initialValue: T) => {
  const [storedValue, setStoredValue] = useState<T>(initialValue)
  const isClient = useIsClient()

  useEffect(() => {
    if (!isClient) return

    try {
      const item = window.localStorage.getItem(key)
      if (item) {
        setStoredValue(JSON.parse(item))
      }
    } catch (error) {
      console.warn(`Error reading localStorage key "${key}":`, error)
    }
  }, [key, isClient])

  const setValue = useCallback(
    (value: T | ((val: T) => T)) => {
      if (!isClient) return

      try {
        const valueToStore = value instanceof Function ? value(storedValue) : value
        setStoredValue(valueToStore)
        window.localStorage.setItem(key, JSON.stringify(valueToStore))
      } catch (error) {
        console.warn(`Error setting localStorage key "${key}":`, error)
      }
    },
    [key, storedValue, isClient],
  )

  return [storedValue, setValue] as const
}

export const useSessionStorage = <T,>(key: string, initialValue: T) => {
  const [storedValue, setStoredValue] = useState<T>(initialValue)
  const isClient = useIsClient()

  useEffect(() => {
    if (!isClient) return

    try {
      const item = window.sessionStorage.getItem(key)
      if (item) {
        setStoredValue(JSON.parse(item))
      }
    } catch (error) {
      console.warn(`Error reading sessionStorage key "${key}":`, error)
    }
  }, [key, isClient])

  const setValue = useCallback(
    (value: T | ((val: T) => T)) => {
      if (!isClient) return

      try {
        const valueToStore = value instanceof Function ? value(storedValue) : value
        setStoredValue(valueToStore)
        window.sessionStorage.setItem(key, JSON.stringify(valueToStore))
      } catch (error) {
        console.warn(`Error setting sessionStorage key "${key}":`, error)
      }
    },
    [key, storedValue, isClient],
  )

  return [storedValue, setValue] as const
}

export const useWindowSize = () => {
  const [windowSize, setWindowSize] = useState({
    width: 0,
    height: 0,
  })
  const isClient = useIsClient()

  useEffect(() => {
    if (!isClient) return

    const handleResize = () => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight,
      })
    }

    handleResize()
    window.addEventListener("resize", handleResize)

    return () => window.removeEventListener("resize", handleResize)
  }, [isClient])

  return windowSize
}

export const useMediaQuery = (query: string) => {
  const [matches, setMatches] = useState(false)
  const isClient = useIsClient()

  useEffect(() => {
    if (!isClient) return

    const media = window.matchMedia(query)
    if (media.matches !== matches) {
      setMatches(media.matches)
    }

    const listener = () => setMatches(media.matches)
    media.addEventListener("change", listener)

    return () => media.removeEventListener("change", listener)
  }, [matches, query, isClient])

  return matches
}

export const useScrollPosition = () => {
  const [scrollPosition, setScrollPosition] = useState({ x: 0, y: 0 })
  const isClient = useIsClient()

  useEffect(() => {
    if (!isClient) return

    const updatePosition = () => {
      setScrollPosition({ x: window.pageXOffset, y: window.pageYOffset })
    }

    window.addEventListener("scroll", updatePosition)
    updatePosition()

    return () => window.removeEventListener("scroll", updatePosition)
  }, [isClient])

  return scrollPosition
}

export const useIntersectionObserver = (elementRef: React.RefObject<Element>, options?: IntersectionObserverInit) => {
  const [isIntersecting, setIsIntersecting] = useState(false)
  const isClient = useIsClient()

  useEffect(() => {
    if (!isClient || !elementRef.current) return

    const observer = new IntersectionObserver(([entry]) => {
      setIsIntersecting(entry.isIntersecting)
    }, options)

    observer.observe(elementRef.current)

    return () => observer.disconnect()
  }, [elementRef, options, isClient])

  return isIntersecting
}

export const useClipboard = () => {
  const [copied, setCopied] = useState(false)
  const isClient = useIsClient()

  const copyToClipboard = useCallback(
    async (text: string) => {
      if (!isClient || !navigator.clipboard) return false

      try {
        await navigator.clipboard.writeText(text)
        setCopied(true)
        setTimeout(() => setCopied(false), 2000)
        return true
      } catch (error) {
        console.warn("Failed to copy to clipboard:", error)
        return false
      }
    },
    [isClient],
  )

  return { copied, copyToClipboard }
}

export const useGeolocation = () => {
  const [location, setLocation] = useState<{
    latitude: number
    longitude: number
    accuracy: number
  } | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const isClient = useIsClient()

  const getCurrentLocation = useCallback(() => {
    if (!isClient || !navigator.geolocation) {
      setError("Geolocation is not supported")
      return
    }

    setLoading(true)
    setError(null)

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
        })
        setLoading(false)
      },
      (error) => {
        setError(error.message)
        setLoading(false)
      },
    )
  }, [isClient])

  return { location, error, loading, getCurrentLocation }
}
