// Configurações centralizadas do sistema

export const CONFIG = {
  // Configurações de arquivo
  FILE: {
    MAX_SIZE: 5 * 1024 * 1024, // 5MB
    ALLOWED_TYPES: ["image/jpeg", "image/png", "image/gif", "image/webp", "application/pdf"],
    MAX_FILES_PER_REGISTRATION: 10,
  },

  // Configurações de validação
  VALIDATION: {
    MIN_AGE: 18,
    MAX_AGE: 65,
    MIN_NAME_LENGTH: 2,
    MAX_NAME_LENGTH: 255,
    MIN_MESSAGE_LENGTH: 10,
    MAX_MESSAGE_LENGTH: 5000,
  },

  // Configurações de UI
  UI: {
    TOAST_DURATION: 5000,
    LOADING_TIMEOUT: 30000,
    DEBOUNCE_DELAY: 300,
  },

  // Configurações de segurança
  SECURITY: {
    SESSION_TIMEOUT: 3600, // 1 hora
    MAX_LOGIN_ATTEMPTS: 5,
    PASSWORD_MIN_LENGTH: 8,
  },

  // URLs e endpoints
  URLS: {
    WHATSAPP_BASE: "https://wa.me/",
    INSTAGRAM: "https://www.instagram.com/rubiagency.br/",
    FACEBOOK: "https://facebook.com/rubiagency",
  },

  // Configurações de email
  EMAIL: {
    FROM: "noreply@rubiagency.com",
    ADMIN: "admin@rubiagency.com",
    SUPPORT: "contato@rubiagency.com",
  },

  // Configurações de desenvolvimento
  DEV: {
    ENABLE_MOCK_DATA: !process.env.DATABASE_URL,
    LOG_LEVEL: process.env.NODE_ENV === "development" ? "debug" : "info",
    ENABLE_DEBUG_PANEL: process.env.NODE_ENV === "development",
  },
} as const

// Função para validar configurações
export function validateConfig() {
  const errors: string[] = []

  // Validar variáveis de ambiente obrigatórias em produção
  if (process.env.NODE_ENV === "production") {
    if (!process.env.DATABASE_URL) {
      errors.push("DATABASE_URL is required in production")
    }
  }

  // Validar configurações de arquivo
  if (CONFIG.FILE.MAX_SIZE <= 0) {
    errors.push("FILE.MAX_SIZE must be greater than 0")
  }

  if (CONFIG.FILE.ALLOWED_TYPES.length === 0) {
    errors.push("FILE.ALLOWED_TYPES cannot be empty")
  }

  // Validar configurações de validação
  if (CONFIG.VALIDATION.MIN_AGE >= CONFIG.VALIDATION.MAX_AGE) {
    errors.push("VALIDATION.MIN_AGE must be less than MAX_AGE")
  }

  if (errors.length > 0) {
    console.error("❌ Configuration validation failed:")
    errors.forEach((error) => console.error(`  - ${error}`))
    throw new Error("Invalid configuration")
  }

  console.log("✅ Configuration validation passed")
}

// Função para obter configuração específica
export function getConfig<T extends keyof typeof CONFIG>(section: T): (typeof CONFIG)[T] {
  return CONFIG[section]
}

// Função para verificar se está em modo de desenvolvimento
export function isDevelopment(): boolean {
  return process.env.NODE_ENV === "development"
}

// Função para verificar se está em modo de produção
export function isProduction(): boolean {
  return process.env.NODE_ENV === "production"
}

// Função para formatar tamanho de arquivo
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 Bytes"
  const k = 1024
  const sizes = ["Bytes", "KB", "MB", "GB"]
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
}

// Função para validar tipo de arquivo
export function isValidFileType(fileType: string): boolean {
  return CONFIG.FILE.ALLOWED_TYPES.includes(fileType)
}

// Função para validar tamanho de arquivo
export function isValidFileSize(fileSize: number): boolean {
  return fileSize > 0 && fileSize <= CONFIG.FILE.MAX_SIZE
}

// Inicializar validação de configuração
if (typeof window === "undefined") {
  // Apenas no servidor
  validateConfig()
}
