import { supabaseAdmin, supabasePublic, isSupabaseConfigured } from "./supabase"

// Types baseados na estrutura real do banco
export interface Registration {
  id: number
  name: string
  email: string
  phone: string | null
  instagram: string | null
  age: number
  subject: string | null
  experience: string | null
  message: string
  status: "pending" | "approved" | "rejected"
  partner_id: number | null
  partner_code: string | null
  partner_name: string | null
  created_at: string
  updated_at: string
  approved_at: string | null
  approved_by: string | null
}

export interface ContactRegistration {
  id: string
  name: string
  email: string
  phone: string | null
  instagram: string | null
  message: string | null
  status: "new" | "contacted" | "converted" | "rejected"
  created_at: string
  updated_at: string
  attachments: string[]
  partner_code: string | null
}

export interface Partner {
  id: number
  name: string
  email: string
  code: string
  description: string | null
  commission_rate: number
  is_active: boolean
  total_referrals: number
  total_registrations: number
  approved_registrations: number
  created_at: string
  updated_at: string
}

export interface RegistrationStats {
  total: number
  pending: number
  approved: number
  rejected: number
  thisMonth: number
  lastMonth: number
  growthRate: number
}

// Função para testar conexão com o banco
export async function testDatabaseConnection(): Promise<{ success: boolean; message: string }> {
  try {
    if (!isSupabaseConfigured()) {
      return {
        success: false,
        message: "Configurações do Supabase não encontradas",
      }
    }

    if (!supabaseAdmin) {
      return {
        success: false,
        message: "Cliente admin do Supabase não configurado",
      }
    }

    // Teste simples de conexão
    const { data, error } = await supabasePublic.from("system_settings").select("id").limit(1)

    if (error) {
      return {
        success: false,
        message: `Erro na conexão: ${error.message}`,
      }
    }

    return {
      success: true,
      message: "Conexão com banco de dados estabelecida com sucesso",
    }
  } catch (error) {
    return {
      success: false,
      message: `Erro inesperado: ${error instanceof Error ? error.message : "Erro desconhecido"}`,
    }
  }
}

// Função para verificar se o banco está disponível
export async function isDatabaseAvailable(): Promise<boolean> {
  try {
    const result = await testDatabaseConnection()
    return result.success
  } catch (error) {
    console.error("❌ Database availability check failed:", error)
    return false
  }
}

// Função para obter registros de usuários (user_registrations)
export async function getUserRegistrations(status?: string): Promise<Registration[]> {
  try {
    if (!isSupabaseConfigured() || !supabaseAdmin) {
      console.warn("⚠️ Supabase not configured")
      return []
    }

    let query = supabaseAdmin.from("user_registrations").select("*").order("created_at", { ascending: false })

    if (status && status !== "all") {
      query = query.eq("status", status)
    }

    const { data, error } = await query

    if (error) {
      console.error("❌ Error fetching user_registrations:", error.message)
      return []
    }

    return (data || []) as Registration[]
  } catch (error) {
    console.error("Error fetching registrations:", error instanceof Error ? error.message : "Unknown error")
    return []
  }
}

// Alias para compatibilidade
export const getRegistrations = getUserRegistrations

// Função para obter registros de contato (contact_registrations)
export async function getContactRegistrations(status?: string): Promise<ContactRegistration[]> {
  try {
    if (!isSupabaseConfigured() || !supabaseAdmin) {
      console.warn("⚠️ Supabase not configured")
      return []
    }

    let query = supabaseAdmin.from("contact_registrations").select("*").order("created_at", { ascending: false })

    if (status && status !== "all") {
      query = query.eq("status", status)
    }

    const { data, error } = await query

    if (error) {
      console.error("❌ Error fetching contact_registrations:", error.message)
      return []
    }

    return (data || []) as ContactRegistration[]
  } catch (error) {
    console.error("Error fetching contact registrations:", error instanceof Error ? error.message : "Unknown error")
    return []
  }
}

// Função para obter registro por ID
export async function getRegistrationById(id: string | number): Promise<Registration | null> {
  try {
    if (!isSupabaseConfigured() || !supabaseAdmin) {
      return null
    }

    const numId = typeof id === "string" ? Number.parseInt(id) : id

    const { data, error } = await supabaseAdmin.from("user_registrations").select("*").eq("id", numId).single()

    if (error) {
      if (error.code === "PGRST116") {
        return null // Not found
      }
      console.error("❌ Error fetching user_registration:", error.message)
      return null
    }

    return data as Registration
  } catch (error) {
    console.error("❌ Error in getRegistrationById:", error)
    return null
  }
}

// Alias para compatibilidade
export const getUserRegistrationById = getRegistrationById

// Função para atualizar status de registro
export async function updateRegistrationStatus(
  id: string | number,
  status: "pending" | "approved" | "rejected",
  notes?: string,
): Promise<boolean> {
  try {
    if (!isSupabaseConfigured() || !supabaseAdmin) {
      console.error("Supabase not configured")
      return false
    }

    const numId = typeof id === "string" ? Number.parseInt(id) : id

    const updateData: any = {
      status,
      updated_at: new Date().toISOString(),
    }

    if (status === "approved") {
      updateData.approved_at = new Date().toISOString()
      updateData.approved_by = "admin"
    }

    if (notes) {
      updateData.notes = notes
    }

    const { error } = await supabaseAdmin.from("user_registrations").update(updateData).eq("id", numId)

    if (error) {
      console.error("❌ Error updating user_registration status:", error.message)
      return false
    }

    console.log(`✅ User_registration ${numId} status updated to: ${status}`)
    return true
  } catch (error) {
    console.error("❌ Error in updateRegistrationStatus:", error)
    return false
  }
}

// Alias para compatibilidade
export const updateUserRegistrationStatus = updateRegistrationStatus

// Função para criar novo registro
export async function createRegistration(
  registration: Omit<Registration, "id" | "created_at" | "updated_at">,
): Promise<Registration | null> {
  try {
    if (!isSupabaseConfigured() || !supabaseAdmin) {
      throw new Error("Supabase not configured")
    }

    const { data, error } = await supabaseAdmin
      .from("user_registrations")
      .insert([
        {
          ...registration,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ])
      .select()
      .single()

    if (error) {
      console.error("❌ Error creating user_registration:", error.message)
      throw new Error(`Database error: ${error.message}`)
    }

    console.log(`✅ User_registration created with ID: ${data.id}`)
    return data as Registration
  } catch (error) {
    console.error("❌ Error in createRegistration:", error)
    throw error
  }
}

// Função para criar registro de contato
export async function createContactRegistration(
  registration: Omit<ContactRegistration, "id" | "created_at" | "updated_at">,
): Promise<ContactRegistration | null> {
  try {
    // Usar cliente público para inserções de contato
    const { data, error } = await supabasePublic
      .from("contact_registrations")
      .insert([
        {
          ...registration,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ])
      .select()
      .single()

    if (error) {
      console.error("❌ Error creating contact_registration:", error.message)
      throw new Error(`Database error: ${error.message}`)
    }

    console.log(`✅ Contact_registration created with ID: ${data.id}`)
    return data as ContactRegistration
  } catch (error) {
    console.error("❌ Error in createContactRegistration:", error)
    throw error
  }
}

// Função para obter estatísticas
export async function getRegistrationStats(): Promise<RegistrationStats> {
  try {
    if (!isSupabaseConfigured() || !supabaseAdmin) {
      console.warn("⚠️ Supabase not configured")
      return {
        total: 0,
        pending: 0,
        approved: 0,
        rejected: 0,
        thisMonth: 0,
        lastMonth: 0,
        growthRate: 0,
      }
    }

    // Buscar todos os registros de user_registrations
    const { data: allRegistrations, error: allError } = await supabaseAdmin
      .from("user_registrations")
      .select("status, created_at")

    if (allError) {
      console.error("❌ Error fetching user_registrations for stats:", allError.message)
      return {
        total: 0,
        pending: 0,
        approved: 0,
        rejected: 0,
        thisMonth: 0,
        lastMonth: 0,
        growthRate: 0,
      }
    }

    const registrations = allRegistrations || []

    // Calcular estatísticas
    const total = registrations.length
    const pending = registrations.filter((r) => r.status === "pending").length
    const approved = registrations.filter((r) => r.status === "approved").length
    const rejected = registrations.filter((r) => r.status === "rejected").length

    // Calcular registros deste mês
    const now = new Date()
    const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1)
    const thisMonth = registrations.filter((r) => new Date(r.created_at) >= thisMonthStart).length

    // Calcular registros do mês passado
    const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1)
    const lastMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0)
    const lastMonth = registrations.filter((r) => {
      const date = new Date(r.created_at)
      return date >= lastMonthStart && date <= lastMonthEnd
    }).length

    // Calcular taxa de crescimento
    const growthRate = lastMonth > 0 ? ((thisMonth - lastMonth) / lastMonth) * 100 : thisMonth > 0 ? 100 : 0

    const stats = {
      total,
      pending,
      approved,
      rejected,
      thisMonth,
      lastMonth,
      growthRate: Math.round(growthRate * 100) / 100,
    }

    console.log("✅ Registration stats calculated:", stats)
    return stats
  } catch (error) {
    console.error("❌ Error in getRegistrationStats:", error)
    // Retornar stats padrão em caso de erro
    return {
      total: 0,
      pending: 0,
      approved: 0,
      rejected: 0,
      thisMonth: 0,
      lastMonth: 0,
      growthRate: 0,
    }
  }
}

// Função para obter parceiros
export async function getPartners(): Promise<Partner[]> {
  try {
    if (!isSupabaseConfigured() || !supabaseAdmin) {
      console.warn("⚠️ Supabase not configured")
      return []
    }

    const { data, error } = await supabaseAdmin.from("partners").select("*").order("created_at", { ascending: false })

    if (error) {
      console.error("❌ Error fetching partners:", error.message)
      return []
    }

    return (data || []) as Partner[]
  } catch (error) {
    console.error("❌ Error in getPartners:", error)
    return []
  }
}

// Função para obter parceiro por código
export async function getPartnerByCode(code: string): Promise<Partner | null> {
  try {
    if (!isSupabaseConfigured()) {
      return null
    }

    // Usar cliente público para buscar parceiros ativos
    const { data, error } = await supabasePublic
      .from("partners")
      .select("*")
      .eq("code", code)
      .eq("is_active", true)
      .single()

    if (error) {
      if (error.code === "PGRST116") {
        return null // Not found
      }
      console.error("❌ Error fetching partner:", error.message)
      return null
    }

    return data as Partner
  } catch (error) {
    console.error("❌ Error in getPartnerByCode:", error)
    return null
  }
}

// Função para testar submissão de contato
export async function testContactSubmission(): Promise<{ success: boolean; message: string }> {
  try {
    const testData = {
      name: "Teste Sistema",
      email: "teste@rubiagency.com",
      phone: "(11) 99999-9999",
      message: "Teste de submissão do sistema",
      partner_code: "TEST",
      status: "new" as const,
      attachments: [],
    }

    const result = await createContactRegistration(testData)

    if (result) {
      // Limpar o registro de teste se possível
      if (supabaseAdmin) {
        await supabaseAdmin.from("contact_registrations").delete().eq("email", "teste@rubiagency.com")
      }

      return {
        success: true,
        message: "Teste de submissão realizado com sucesso",
      }
    } else {
      return {
        success: false,
        message: "Erro no teste de submissão",
      }
    }
  } catch (error) {
    return {
      success: false,
      message: `Erro inesperado no teste: ${error instanceof Error ? error.message : "Erro desconhecido"}`,
    }
  }
}

// Compatibilidade com código legado
export const sql = {
  query: async (text: string, params?: any[]) => {
    console.warn("sql.query é uma função de compatibilidade. Use as funções específicas do Supabase.")
    return { rows: [] }
  },
}

// Aliases para compatibilidade
export const getAllPartners = getPartners
export const getPartnerById = getPartnerByCode
export const saveContactRegistration = createContactRegistration

// Log de inicialização apenas no servidor
if (typeof window === "undefined") {
  console.log("🗄️ Database functions initialized")
  console.log("📊 Supabase configured:", isSupabaseConfigured())
}
