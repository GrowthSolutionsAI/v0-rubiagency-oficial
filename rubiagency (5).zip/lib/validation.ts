import { CONFIG } from "./config"

// Tipos para validação
export interface ValidationResult {
  isValid: boolean
  errors: string[]
}

export interface ContactFormData {
  name: string
  email: string
  whatsapp?: string
  age: number
  subject?: string
  experience?: string
  message: string
}

// Função principal de validação do formulário
export function validateContactForm(data: ContactFormData): ValidationResult {
  const errors: string[] = []

  // Validar nome
  const nameValidation = validateName(data.name)
  if (!nameValidation.isValid) {
    errors.push(...nameValidation.errors)
  }

  // Validar email
  const emailValidation = validateEmail(data.email)
  if (!emailValidation.isValid) {
    errors.push(...emailValidation.errors)
  }

  // Validar idade
  const ageValidation = validateAge(data.age)
  if (!ageValidation.isValid) {
    errors.push(...ageValidation.errors)
  }

  // Validar mensagem
  const messageValidation = validateMessage(data.message)
  if (!messageValidation.isValid) {
    errors.push(...messageValidation.errors)
  }

  // Validar WhatsApp (opcional)
  if (data.whatsapp) {
    const whatsappValidation = validateWhatsApp(data.whatsapp)
    if (!whatsappValidation.isValid) {
      errors.push(...whatsappValidation.errors)
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
  }
}

// Validação de nome
export function validateName(name: string): ValidationResult {
  const errors: string[] = []

  if (!name || typeof name !== "string") {
    errors.push("Nome é obrigatório")
    return { isValid: false, errors }
  }

  const trimmedName = name.trim()

  if (trimmedName.length < CONFIG.VALIDATION.MIN_NAME_LENGTH) {
    errors.push(`Nome deve ter pelo menos ${CONFIG.VALIDATION.MIN_NAME_LENGTH} caracteres`)
  }

  if (trimmedName.length > CONFIG.VALIDATION.MAX_NAME_LENGTH) {
    errors.push(`Nome deve ter no máximo ${CONFIG.VALIDATION.MAX_NAME_LENGTH} caracteres`)
  }

  // Verificar se contém apenas letras, espaços e acentos
  const nameRegex = /^[a-zA-ZÀ-ÿ\s]+$/
  if (!nameRegex.test(trimmedName)) {
    errors.push("Nome deve conter apenas letras e espaços")
  }

  return {
    isValid: errors.length === 0,
    errors,
  }
}

// Validação de email
export function validateEmail(email: string): ValidationResult {
  const errors: string[] = []

  if (!email || typeof email !== "string") {
    errors.push("Email é obrigatório")
    return { isValid: false, errors }
  }

  const trimmedEmail = email.trim().toLowerCase()

  // Regex mais rigoroso para email
  const emailRegex =
    /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/

  if (!emailRegex.test(trimmedEmail)) {
    errors.push("Email inválido")
  }

  if (trimmedEmail.length > 254) {
    errors.push("Email muito longo")
  }

  return {
    isValid: errors.length === 0,
    errors,
  }
}

// Validação de idade
export function validateAge(age: number): ValidationResult {
  const errors: string[] = []

  if (age === undefined || age === null || isNaN(age)) {
    errors.push("Idade é obrigatória")
    return { isValid: false, errors }
  }

  if (!Number.isInteger(age)) {
    errors.push("Idade deve ser um número inteiro")
  }

  if (age < CONFIG.VALIDATION.MIN_AGE) {
    errors.push(`Idade mínima é ${CONFIG.VALIDATION.MIN_AGE} anos`)
  }

  if (age > CONFIG.VALIDATION.MAX_AGE) {
    errors.push(`Idade máxima é ${CONFIG.VALIDATION.MAX_AGE} anos`)
  }

  return {
    isValid: errors.length === 0,
    errors,
  }
}

// Validação de mensagem
export function validateMessage(message: string): ValidationResult {
  const errors: string[] = []

  if (!message || typeof message !== "string") {
    errors.push("Mensagem é obrigatória")
    return { isValid: false, errors }
  }

  const trimmedMessage = message.trim()

  if (trimmedMessage.length < CONFIG.VALIDATION.MIN_MESSAGE_LENGTH) {
    errors.push(`Mensagem deve ter pelo menos ${CONFIG.VALIDATION.MIN_MESSAGE_LENGTH} caracteres`)
  }

  if (trimmedMessage.length > CONFIG.VALIDATION.MAX_MESSAGE_LENGTH) {
    errors.push(`Mensagem deve ter no máximo ${CONFIG.VALIDATION.MAX_MESSAGE_LENGTH} caracteres`)
  }

  return {
    isValid: errors.length === 0,
    errors,
  }
}

// Validação de WhatsApp
export function validateWhatsApp(whatsapp: string): ValidationResult {
  const errors: string[] = []

  if (!whatsapp || typeof whatsapp !== "string") {
    return { isValid: true, errors } // WhatsApp é opcional
  }

  const trimmedWhatsapp = whatsapp.trim()

  // Remover caracteres não numéricos para validação
  const numbersOnly = trimmedWhatsapp.replace(/\D/g, "")

  if (numbersOnly.length < 10) {
    errors.push("WhatsApp deve ter pelo menos 10 dígitos")
  }

  if (numbersOnly.length > 15) {
    errors.push("WhatsApp deve ter no máximo 15 dígitos")
  }

  // Verificar se começa com código do país válido
  if (numbersOnly.length >= 11 && !numbersOnly.startsWith("55")) {
    // Para números brasileiros
    if (
      numbersOnly.length === 11 &&
      ![
        "11",
        "12",
        "13",
        "14",
        "15",
        "16",
        "17",
        "18",
        "19",
        "21",
        "22",
        "24",
        "27",
        "28",
        "31",
        "32",
        "33",
        "34",
        "35",
        "37",
        "38",
        "41",
        "42",
        "43",
        "44",
        "45",
        "46",
        "47",
        "48",
        "49",
        "51",
        "53",
        "54",
        "55",
        "61",
        "62",
        "63",
        "64",
        "65",
        "66",
        "67",
        "68",
        "69",
        "71",
        "73",
        "74",
        "75",
        "77",
        "79",
        "81",
        "82",
        "83",
        "84",
        "85",
        "86",
        "87",
        "88",
        "89",
        "91",
        "92",
        "93",
        "94",
        "95",
        "96",
        "97",
        "98",
        "99",
      ].includes(numbersOnly.substring(0, 2))
    ) {
      errors.push("Código de área inválido")
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
  }
}

// Validação de arquivo
export function validateFile(file: File): ValidationResult {
  const errors: string[] = []

  if (!file) {
    errors.push("Arquivo é obrigatório")
    return { isValid: false, errors }
  }

  // Validar tipo
  if (!CONFIG.FILE.ALLOWED_TYPES.includes(file.type)) {
    errors.push(`Tipo de arquivo não permitido: ${file.type}`)
  }

  // Validar tamanho
  if (file.size > CONFIG.FILE.MAX_SIZE) {
    errors.push(`Arquivo muito grande. Máximo: ${CONFIG.FILE.MAX_SIZE / (1024 * 1024)}MB`)
  }

  if (file.size === 0) {
    errors.push("Arquivo está vazio")
  }

  // Validar nome do arquivo
  if (file.name.length > 255) {
    errors.push("Nome do arquivo muito longo")
  }

  return {
    isValid: errors.length === 0,
    errors,
  }
}

// Validação de múltiplos arquivos
export function validateFiles(files: File[]): ValidationResult {
  const errors: string[] = []

  if (files.length > CONFIG.FILE.MAX_FILES_PER_REGISTRATION) {
    errors.push(`Máximo ${CONFIG.FILE.MAX_FILES_PER_REGISTRATION} arquivos permitidos`)
  }

  // Validar cada arquivo
  files.forEach((file, index) => {
    const fileValidation = validateFile(file)
    if (!fileValidation.isValid) {
      errors.push(`Arquivo ${index + 1}: ${fileValidation.errors.join(", ")}`)
    }
  })

  return {
    isValid: errors.length === 0,
    errors,
  }
}

// Função para sanitizar entrada
export function sanitizeInput(input: string): string {
  if (!input || typeof input !== "string") {
    return ""
  }

  return input
    .trim()
    .replace(/[<>]/g, "") // Remove caracteres perigosos
    .replace(/\s+/g, " ") // Normaliza espaços
}

// Função para sanitizar dados do formulário
export function sanitizeContactForm(data: ContactFormData): ContactFormData {
  return {
    name: sanitizeInput(data.name),
    email: sanitizeInput(data.email).toLowerCase(),
    whatsapp: data.whatsapp ? sanitizeInput(data.whatsapp) : undefined,
    age: Number(data.age),
    subject: data.subject ? sanitizeInput(data.subject) : undefined,
    experience: data.experience ? sanitizeInput(data.experience) : undefined,
    message: sanitizeInput(data.message),
  }
}
