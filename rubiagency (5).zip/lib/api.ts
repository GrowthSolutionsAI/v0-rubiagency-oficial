import { getRegistrationStats, getUserRegistrations, isDatabaseAvailable } from "./database"

export async function fetchRegistrationStats() {
  try {
    const stats = await getRegistrationStats()
    return stats
  } catch (error) {
    console.error("Erro ao buscar estatísticas:", error)
    // Retornar dados mock em caso de erro
    return {
      total: 0,
      pending: 0,
      approved: 0,
      rejected: 0,
    }
  }
}

export async function fetchRecentRegistrations(limit = 10) {
  try {
    const registrations = await getUserRegistrations()
    return registrations.slice(0, limit)
  } catch (error) {
    console.error("Erro ao buscar cadastros recentes:", error)
    return []
  }
}

export async function fetchRegistrationsByStatus(status?: "pending" | "approved" | "rejected") {
  try {
    const registrations = await getUserRegistrations(status)
    return registrations
  } catch (error) {
    console.error("Erro ao buscar cadastros por status:", error)
    return []
  }
}

// Verificar se o sistema está funcionando em produção
export function isSystemOnline() {
  return isDatabaseAvailable
}

// Obter status detalhado do sistema
export async function getSystemHealth() {
  return {
    database: isDatabaseAvailable,
    emails: isDatabaseAvailable, // Em produção, emails dependem do banco
    analytics: true, // Analytics sempre disponível
    forms: true, // Formulários sempre funcionais
  }
}
