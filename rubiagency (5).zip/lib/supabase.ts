import { createClient, type SupabaseClient } from "@supabase/supabase-js"

// Tipos para as tabelas do banco
export interface UserRegistration {
  id: number
  name: string
  email: string
  phone?: string
  instagram?: string
  age?: number
  subject?: string
  experience?: string
  message: string
  status: "pending" | "approved" | "rejected"
  partner_id?: number
  partner_code?: string
  partner_name?: string
  created_at: string
  updated_at: string
  approved_at?: string
  approved_by?: string
  notes?: string
}

export interface Partner {
  id: number
  name: string
  email: string
  phone?: string
  company?: string
  website?: string
  description?: string
  status: "active" | "inactive"
  code: string
  referral_code?: string
  commission_rate: number
  total_referrals: number
  total_commission: number
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface SystemSetting {
  id: number
  setting_key: string
  setting_value: string
  description?: string
  created_at: string
  updated_at: string
}

// Configuração do Supabase
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

// Verificar se as variáveis estão configuradas
export function isSupabaseConfigured(): boolean {
  return !!(supabaseUrl && supabaseAnonKey)
}

// Cliente público do Supabase
export const supabasePublic: SupabaseClient =
  supabaseUrl && supabaseAnonKey ? createClient(supabaseUrl, supabaseAnonKey) : ({} as SupabaseClient)

// Cliente admin do Supabase (com service role key)
export const supabaseAdmin: SupabaseClient =
  supabaseUrl && supabaseServiceKey ? createClient(supabaseUrl, supabaseServiceKey) : ({} as SupabaseClient)

// Função para obter cliente público (compatibilidade)
export function getSupabaseClient(): SupabaseClient {
  return supabasePublic
}

// Função para obter cliente admin (compatibilidade)
export function getSupabaseAdmin(): SupabaseClient {
  return supabaseAdmin
}

// Função para testar conexão
export async function testSupabaseConnection(): Promise<{
  success: boolean
  message: string
  details?: any
}> {
  try {
    if (!isSupabaseConfigured()) {
      return {
        success: false,
        message: "Supabase não está configurado. Verifique as variáveis de ambiente.",
      }
    }

    // Testar conexão simples
    const { data, error } = await supabasePublic.from("user_registrations").select("count").limit(1)

    if (error) {
      return {
        success: false,
        message: `Erro na conexão: ${error.message}`,
        details: error,
      }
    }

    return {
      success: true,
      message: "Conexão com Supabase estabelecida com sucesso!",
    }
  } catch (error) {
    return {
      success: false,
      message: `Erro inesperado: ${error instanceof Error ? error.message : "Erro desconhecido"}`,
      details: error,
    }
  }
}

// Export default para compatibilidade
export default supabasePublic
