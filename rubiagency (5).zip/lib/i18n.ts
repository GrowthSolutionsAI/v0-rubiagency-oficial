export type Language = "pt" | "en" | "es"

export const languages: Record<Language, { name: string; flag: string }> = {
  pt: { name: "Português", flag: "🇧🇷" },
  en: { name: "English", flag: "🇺🇸" },
  es: { name: "Español", flag: "🇪🇸" },
}

export const translations = {
  pt: {
    // Navbar
    "nav.home": "Home",
    "nav.about": "Sobre Nós",
    "nav.services": "Serviços",
    "nav.testimonials": "Depoimentos",
    "nav.blog": "Blog",
    "nav.contact": "Contato",
    "nav.client-area": "Área do Cliente",
    "nav.login": "Pré Seleção",
    "nav.language": "Idioma",

    // Hero
    "hero.overline": "Agência para criadoras +18",
    "hero.title1": "BRILHE.",
    "hero.title2": "SEDUZA.",
    "hero.title3": "CONQUISTE.",
    "hero.subtitle": "Transformamos sensualidade em um modelo de negócio",
    "hero.subtitle.professional": "profissional",
    "hero.subtitle.profitable": "rentável",
    "hero.subtitle.respected": "respeitado",
    "hero.cta.primary": "NOSSOS SERVIÇOS",
    "hero.cta.secondary": "INICIAR PRÉ-SELEÇÃO",
    "hero.stats.experience": "Anos de Experiência",
    "hero.stats.careers": "Carreiras Transformadas",
    "hero.stats.satisfaction": "Satisfação",
    "hero.scroll": "Descubra mais",

    // About
    "about.overline": "Sobre Nós",
    "about.title": "A Excelência da",
    "about.title.highlight": "Rubi Agency",
    "about.subtitle":
      "Somos uma agência premium dedicada a transformar talentos em carreiras de sucesso. Com mais de uma década de experiência no mercado, oferecemos uma abordagem única que combina profissionalismo, exclusividade e resultados comprovados.",

    // Services
    "services.overline": "Serviços Premium",
    "services.title": "Nossos",
    "services.title.highlight": "Serviços",
    "services.subtitle":
      "Oferecemos uma gama completa de serviços premium para impulsionar sua carreira e maximizar seu potencial no mercado. Cada serviço é personalizado para atender às suas necessidades específicas com padrões internacionais de qualidade.",
    "services.service1.title": "Gestão de Carreira Premium",
    "services.service1.desc":
      "Planejamento estratégico personalizado e acompanhamento dedicado para o desenvolvimento profissional sustentável e de alto nível.",
    "services.service1.feature1": "Planejamento Estratégico",
    "services.service1.feature2": "Mentoria Individual",
    "services.service1.feature3": "Análise de Mercado",
    "services.service2.title": "Marketing Digital Exclusivo",
    "services.service2.desc":
      "Estratégias de presença online premium, gestão de redes sociais e posicionamento de marca pessoal de elite.",
    "services.service2.feature1": "Gestão de Redes",
    "services.service2.feature2": "Branding Pessoal",
    "services.service2.feature3": "Campanhas Digitais",
    "services.service3.title": "Networking de Elite",
    "services.service3.desc":
      "Acesso exclusivo a uma rede de contatos premium e oportunidades selecionadas no mercado nacional e internacional.",
    "services.service3.feature1": "Eventos Exclusivos",
    "services.service3.feature2": "Parcerias Premium",
    "services.service3.feature3": "Oportunidades Globais",
    "services.service4.title": "Contratos Seguros",
    "services.service4.desc":
      "Negociação especializada e gestão de contratos com garantias legais e condições vantajosas para nossos talentos.",
    "services.service4.feature1": "Assessoria Jurídica",
    "services.service4.feature2": "Negociação Especializada",
    "services.service4.feature3": "Proteção Legal",
    "services.service5.title": "Consultoria de Imagem",
    "services.service5.desc":
      "Orientação profissional para desenvolvimento de estilo pessoal e presença marcante no mercado premium.",
    "services.service5.feature1": "Análise de Estilo",
    "services.service5.feature2": "Personal Styling",
    "services.service5.feature3": "Consultoria de Imagem",
    "services.service6.title": "Desenvolvimento Profissional",
    "services.service6.desc":
      "Treinamentos especializados e workshops para aprimoramento de habilidades e competências profissionais.",
    "services.service6.feature1": "Workshops Exclusivos",
    "services.service6.feature2": "Treinamento Comportamental",
    "services.service6.feature3": "Desenvolvimento de Skills",
    "services.cta.title": "Pronto para Transformar sua Carreira?",
    "services.cta.desc":
      "Inicie seu processo de pré-seleção e descubra como podemos elevar sua carreira ao próximo nível com nossos serviços premium exclusivos.",
    "services.cta.button": "INICIAR PRÉ-SELEÇÃO",

    // Testimonials
    "testimonials.overline": "Histórias de Sucesso",
    "testimonials.title": "O que",
    "testimonials.title.highlight": "Dizem Sobre Nós",
    "testimonials.subtitle":
      "Conheça as histórias de sucesso e experiências de nossos talentos que transformaram suas carreiras com a Rubi Agency.",

    // Blog
    "blog.overline": "Conteúdo Exclusivo",
    "blog.title": "Blog da",
    "blog.title.highlight": "Rubi Agency",
    "blog.subtitle":
      "Conteúdo especializado para criadoras que querem crescer profissionalmente. Dicas, estratégias e insights exclusivos para maximizar seu sucesso no mercado digital.",

    // Contact
    "contact.badge": "Fale Conosco",
    "contact.title": "Entre em",
    "contact.titleHighlight": "Contato",
    "contact.description":
      "Inicie seu processo de pré-seleção preenchendo o formulário abaixo. Nossa equipe avaliará seu perfil e entrará em contato para as próximas etapas.",

    // FAQ
    "faq.overline": "Dúvidas Frequentes",
    "faq.title": "Perguntas",
    "faq.title.highlight": "Frequentes",
    "faq.subtitle":
      "Esclarecemos as principais dúvidas sobre nossos serviços, processo de seleção e como podemos transformar sua carreira no mercado digital.",

    // Footer
    "footer.description":
      "Agência premium especializada em gestão de carreira para criadoras de conteúdo adulto em Florianópolis. Transformando sensualidade em negócios profissionais e rentáveis desde 2014.",

    // Common
    "common.loading": "Carregando...",
    "common.error": "Erro",
    "common.success": "Sucesso",
    "common.required": "Obrigatório",
    "common.optional": "Opcional",
  },
  en: {
    // Navbar
    "nav.home": "Home",
    "nav.about": "About Us",
    "nav.services": "Services",
    "nav.testimonials": "Testimonials",
    "nav.blog": "Blog",
    "nav.contact": "Contact",
    "nav.client-area": "Client Area",
    "nav.login": "Pre Selection",
    "nav.language": "Language",

    // Hero
    "hero.overline": "Agency for creators +18",
    "hero.title1": "SHINE.",
    "hero.title2": "SEDUCE.",
    "hero.title3": "CONQUER.",
    "hero.subtitle": "We transform sensuality into a business model that is",
    "hero.subtitle.professional": "professional",
    "hero.subtitle.profitable": "profitable",
    "hero.subtitle.respected": "respected",
    "hero.cta.primary": "OUR SERVICES",
    "hero.cta.secondary": "START PRE-SELECTION",
    "hero.stats.experience": "Years of Experience",
    "hero.stats.careers": "Careers Transformed",
    "hero.stats.satisfaction": "Satisfaction",
    "hero.scroll": "Discover more",

    // About
    "about.overline": "About Us",
    "about.title": "The Excellence of",
    "about.title.highlight": "Rubi Agency",
    "about.subtitle":
      "We are a premium agency dedicated to transforming talents into successful careers. With over a decade of market experience, we offer a unique approach that combines professionalism, exclusivity, and proven results.",

    // Services
    "services.overline": "Premium Services",
    "services.title": "Our",
    "services.title.highlight": "Services",
    "services.subtitle":
      "We offer a complete range of premium services to boost your career and maximize your market potential. Each service is personalized to meet your specific needs with international quality standards.",
    "services.service1.title": "Premium Career Management",
    "services.service1.desc":
      "Personalized strategic planning and dedicated follow-up for sustainable and high-level professional development.",
    "services.service1.feature1": "Strategic Planning",
    "services.service1.feature2": "Individual Mentoring",
    "services.service1.feature3": "Market Analysis",
    "services.service2.title": "Exclusive Digital Marketing",
    "services.service2.desc":
      "Premium online presence strategies, social media management, and elite personal brand positioning.",
    "services.service2.feature1": "Social Media Management",
    "services.service2.feature2": "Personal Branding",
    "services.service2.feature3": "Digital Campaigns",
    "services.service3.title": "Elite Networking",
    "services.service3.desc":
      "Exclusive access to a premium contact network and selected opportunities in the national and international market.",
    "services.service3.feature1": "Exclusive Events",
    "services.service3.feature2": "Premium Partnerships",
    "services.service3.feature3": "Global Opportunities",
    "services.service4.title": "Secure Contracts",
    "services.service4.desc":
      "Specialized negotiation and contract management with legal guarantees and advantageous conditions for our talents.",
    "services.service4.feature1": "Legal Advisory",
    "services.service4.feature2": "Specialized Negotiation",
    "services.service4.feature3": "Legal Protection",
    "services.service5.title": "Image Consulting",
    "services.service5.desc":
      "Professional guidance for personal style development and striking presence in the premium market.",
    "services.service5.feature1": "Style Analysis",
    "services.service5.feature2": "Personal Styling",
    "services.service5.feature3": "Image Consulting",
    "services.service6.title": "Professional Development",
    "services.service6.desc": "Specialized training and workshops for improving professional skills and competencies.",
    "services.service6.feature1": "Exclusive Workshops",
    "services.service6.feature2": "Behavioral Training",
    "services.service6.feature3": "Skills Development",
    "services.cta.title": "Ready to Transform Your Career?",
    "services.cta.desc":
      "Start your pre-selection process and discover how we can elevate your career to the next level with our exclusive premium services.",
    "services.cta.button": "START PRE-SELECTION",

    // Testimonials
    "testimonials.overline": "Success Stories",
    "testimonials.title": "What They",
    "testimonials.title.highlight": "Say About Us",
    "testimonials.subtitle":
      "Discover the success stories and experiences of our talents who transformed their careers with Rubi Agency.",

    // Blog
    "blog.overline": "Exclusive Content",
    "blog.title": "Rubi Agency",
    "blog.title.highlight": "Blog",
    "blog.subtitle":
      "Specialized content for creators who want to grow professionally. Exclusive tips, strategies, and insights to maximize your success in the digital market.",

    // Contact
    "contact.badge": "Contact Us",
    "contact.title": "Get in",
    "contact.titleHighlight": "Touch",
    "contact.description":
      "Start your pre-selection process by filling out the form below. Our team will evaluate your profile and contact you for the next steps.",

    // FAQ
    "faq.overline": "Frequently Asked Questions",
    "faq.title": "Frequently Asked",
    "faq.title.highlight": "Questions",
    "faq.subtitle":
      "We clarify the main questions about our services, selection process and how we can transform your career in the digital market.",

    // Footer
    "footer.description":
      "Premium agency specialized in career management for adult content creators in Florianópolis. Transforming sensuality into professional and profitable businesses since 2014.",

    // Common
    "common.loading": "Loading...",
    "common.error": "Error",
    "common.success": "Success",
    "common.required": "Required",
    "common.optional": "Optional",
  },
  es: {
    // Navbar
    "nav.home": "Inicio",
    "nav.about": "Acerca de Nosotros",
    "nav.services": "Servicios",
    "nav.testimonials": "Testimonios",
    "nav.blog": "Blog",
    "nav.contact": "Contacto",
    "nav.client-area": "Área del Cliente",
    "nav.login": "Pre Selección",
    "nav.language": "Idioma",

    // Hero
    "hero.overline": "Agencia para creadoras +18",
    "hero.title1": "BRILLA.",
    "hero.title2": "SEDUCE.",
    "hero.title3": "CONQUISTA.",
    "hero.subtitle": "Transformamos sensualidad en un modelo de negocio",
    "hero.subtitle.professional": "profesional",
    "hero.subtitle.profitable": "rentable",
    "hero.subtitle.respected": "respetado",
    "hero.cta.primary": "NUESTROS SERVICIOS",
    "hero.cta.secondary": "INICIAR PRE-SELECCIÓN",
    "hero.stats.experience": "Años de Experiencia",
    "hero.stats.careers": "Carreras Transformadas",
    "hero.stats.satisfaction": "Satisfacción",
    "hero.scroll": "Descubre más",

    // About
    "about.overline": "Acerca de Nosotros",
    "about.title": "La Excelencia de",
    "about.title.highlight": "Rubi Agency",
    "about.subtitle":
      "Somos una agencia premium dedicada a transformar talentos en carreras exitosas. Con más de una década de experiencia en el mercado, ofrecemos un enfoque único que combina profesionalismo, exclusividad y resultados comprobados.",

    // Services
    "services.overline": "Servicios Premium",
    "services.title": "Nuestros",
    "services.title.highlight": "Servicios",
    "services.subtitle":
      "Ofrecemos una gama completa de servicios premium para impulsar tu carrera y maximizar tu potencial en el mercado. Cada servicio está personalizado para satisfacer tus necesidades específicas con estándares internacionales de calidad.",
    "services.service1.title": "Gestión de Carrera Premium",
    "services.service1.desc":
      "Planificación estratégica personalizada y seguimiento dedicado para el desarrollo profesional sostenible y de alto nivel.",
    "services.service1.feature1": "Planificación Estratégica",
    "services.service1.feature2": "Mentoría Individual",
    "services.service1.feature3": "Análisis de Mercado",
    "services.service2.title": "Marketing Digital Exclusivo",
    "services.service2.desc":
      "Estrategias de presencia online premium, gestión de redes sociales y posicionamiento de marca personal de élite.",
    "services.service2.feature1": "Gestión de Redes",
    "services.service2.feature2": "Branding Personal",
    "services.service2.feature3": "Campañas Digitales",
    "services.service3.title": "Networking de Élite",
    "services.service3.desc":
      "Acceso exclusivo a una red de contactos premium y oportunidades seleccionadas en el mercado nacional e internacional.",
    "services.service3.feature1": "Eventos Exclusivos",
    "services.service3.feature2": "Alianzas Premium",
    "services.service3.feature3": "Oportunidades Globales",
    "services.service4.title": "Contratos Seguros",
    "services.service4.desc":
      "Negociación especializada y gestión de contratos con garantías legales y condiciones ventajosas para nuestros talentos.",
    "services.service4.feature1": "Asesoría Legal",
    "services.service4.feature2": "Negociación Especializada",
    "services.service4.feature3": "Protección Legal",
    "services.service5.title": "Consultoría de Imagen",
    "services.service5.desc":
      "Orientación profesional para el desarrollo de estilo personal y presencia destacada en el mercado premium.",
    "services.service5.feature1": "Análisis de Estilo",
    "services.service5.feature2": "Personal Styling",
    "services.service5.feature3": "Consultoría de Imagen",
    "services.service6.title": "Desarrollo Profesional",
    "services.service6.desc":
      "Entrenamientos especializados y talleres para el mejoramiento de habilidades y competencias profesionales.",
    "services.service6.feature1": "Talleres Exclusivos",
    "services.service6.feature2": "Entrenamiento Comportamental",
    "services.service6.feature3": "Desarrollo de Habilidades",
    "services.cta.title": "¿Lista para Transformar tu Carrera?",
    "services.cta.desc":
      "Inicia tu proceso de pre-selección y descubre cómo podemos elevar tu carrera al siguiente nivel con nuestros servicios premium exclusivos.",
    "services.cta.button": "INICIAR PRE-SELECCIÓN",

    // Testimonials
    "testimonials.overline": "Historias de Éxito",
    "testimonials.title": "Lo que",
    "testimonials.title.highlight": "Dicen de Nosotros",
    "testimonials.subtitle":
      "Conoce las historias de éxito y experiencias de nuestros talentos que transformaron sus carreras con Rubi Agency.",

    // Blog
    "blog.overline": "Contenido Exclusivo",
    "blog.title": "Blog de",
    "blog.title.highlight": "Rubi Agency",
    "blog.subtitle":
      "Contenido especializado para creadoras que quieren crecer profesionalmente. Consejos, estrategias e insights exclusivos para maximizar tu éxito en el mercado digital.",

    // Contact
    "contact.badge": "Contáctanos",
    "contact.title": "Ponte en",
    "contact.titleHighlight": "Contacto",
    "contact.description":
      "Inicia tu proceso de pre-selección completando el formulario a continuación. Nuestro equipo evaluará tu perfil y se pondrá en contacto para los próximos pasos.",

    // FAQ
    "faq.overline": "Preguntas Frecuentes",
    "faq.title": "Preguntas",
    "faq.title.highlight": "Frecuentes",
    "faq.subtitle":
      "Aclaramos las principales dudas sobre nuestros servicios, proceso de selección y cómo podemos transformar tu carrera en el mercado digital.",

    // Footer
    "footer.description":
      "Agencia premium especializada en gestión de carrera para creadoras de contenido adulto en Florianópolis. Transformando sensualidad en negocios profesionales y rentables desde 2014.",

    // Common
    "common.loading": "Cargando...",
    "common.error": "Error",
    "common.success": "Éxito",
    "common.required": "Requerido",
    "common.optional": "Opcional",
  },
}

export type TranslationKey = keyof typeof translations.pt

export function getTranslation(key: TranslationKey, language: Language): string {
  return translations[language]?.[key] || translations.pt[key] || key
}
