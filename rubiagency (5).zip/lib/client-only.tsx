"use client"

import { useEffect, useState, type ReactNode } from "react"

interface ClientOnlyProps {
  children: ReactNode
  fallback?: ReactNode
}

export function ClientOnly({ children, fallback = null }: ClientOnlyProps) {
  const [hasMounted, setHasMounted] = useState(false)

  useEffect(() => {
    setHasMounted(true)
  }, [])

  if (!hasMounted) {
    return <>{fallback}</>
  }

  return <>{children}</>
}

// ✅ HOOK PARA VERIFICAR SE ESTÁ NO CLIENTE
export function useIsClient() {
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
  }, [])

  return isClient
}

// ✅ HOOK PARA LOCAL STORAGE (CLIENT-SAFE)
export function useLocalStorage<T>(key: string, initialValue: T) {
  const [storedValue, setStoredValue] = useState<T>(initialValue)
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    try {
      if (typeof window !== "undefined") {
        const item = window.localStorage.getItem(key)
        if (item) {
          setStoredValue(JSON.parse(item))
        }
      }
    } catch (error) {
      console.error("Error reading localStorage:", error)
    } finally {
      setIsLoaded(true)
    }
  }, [key])

  const setValue = (value: T) => {
    try {
      setStoredValue(value)
      if (typeof window !== "undefined") {
        window.localStorage.setItem(key, JSON.stringify(value))
      }
    } catch (error) {
      console.error("Error setting localStorage:", error)
    }
  }

  return [storedValue, setValue, isLoaded] as const
}

// ✅ HOOK PARA SESSION STORAGE (CLIENT-SAFE)
export function useSessionStorage<T>(key: string, initialValue: T) {
  const [storedValue, setStoredValue] = useState<T>(initialValue)
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    try {
      if (typeof window !== "undefined") {
        const item = window.sessionStorage.getItem(key)
        if (item) {
          setStoredValue(JSON.parse(item))
        }
      }
    } catch (error) {
      console.error("Error reading sessionStorage:", error)
    } finally {
      setIsLoaded(true)
    }
  }, [key])

  const setValue = (value: T) => {
    try {
      setStoredValue(value)
      if (typeof window !== "undefined") {
        window.sessionStorage.setItem(key, JSON.stringify(value))
      }
    } catch (error) {
      console.error("Error setting sessionStorage:", error)
    }
  }

  return [storedValue, setValue, isLoaded] as const
}

// ✅ HOOK PARA WINDOW SIZE (CLIENT-SAFE)
export function useWindowSize() {
  const [windowSize, setWindowSize] = useState({
    width: 0,
    height: 0,
  })

  useEffect(() => {
    function handleResize() {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight,
      })
    }

    if (typeof window !== "undefined") {
      handleResize()
      window.addEventListener("resize", handleResize)
      return () => window.removeEventListener("resize", handleResize)
    }
  }, [])

  return windowSize
}

// ✅ LOG DE INICIALIZAÇÃO (APENAS NO CLIENTE)
if (typeof window !== "undefined") {
  console.log("🌐 Client-only utilities initialized")
}
