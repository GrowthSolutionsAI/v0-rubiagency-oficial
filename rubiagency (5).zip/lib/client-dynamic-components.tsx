"use client"

import dynamic from "next/dynamic"
import type { ComponentType } from "react"

// Safe browser globals
export const safeWindow = typeof window !== "undefined" ? window : undefined
export const safeDocument = typeof document !== "undefined" ? document : undefined
export const safeLocalStorage = typeof localStorage !== "undefined" ? localStorage : undefined
export const safeSessionStorage = typeof sessionStorage !== "undefined" ? sessionStorage : undefined
export const safeNavigator = typeof navigator !== "undefined" ? navigator : undefined

// Recharts components with dynamic imports
export const LineChart = dynamic(() => import("recharts").then((mod) => mod.LineChart), {
  ssr: false,
}) as ComponentType<any>

export const BarChart = dynamic(() => import("recharts").then((mod) => mod.BarChart), {
  ssr: false,
}) as ComponentType<any>

export const PieChart = dynamic(() => import("recharts").then((mod) => mod.PieChart), {
  ssr: false,
}) as ComponentType<any>

export const XAxis = dynamic(() => import("recharts").then((mod) => mod.XAxis), { ssr: false }) as ComponentType<any>

export const YAxis = dynamic(() => import("recharts").then((mod) => mod.YAxis), { ssr: false }) as ComponentType<any>

export const CartesianGrid = dynamic(() => import("recharts").then((mod) => mod.CartesianGrid), {
  ssr: false,
}) as ComponentType<any>

export const Tooltip = dynamic(() => import("recharts").then((mod) => mod.Tooltip), {
  ssr: false,
}) as ComponentType<any>

export const Legend = dynamic(() => import("recharts").then((mod) => mod.Legend), { ssr: false }) as ComponentType<any>

export const Line = dynamic(() => import("recharts").then((mod) => mod.Line), { ssr: false }) as ComponentType<any>

export const Bar = dynamic(() => import("recharts").then((mod) => mod.Bar), { ssr: false }) as ComponentType<any>

export const Cell = dynamic(() => import("recharts").then((mod) => mod.Cell), { ssr: false }) as ComponentType<any>

export const ResponsiveContainer = dynamic(() => import("recharts").then((mod) => mod.ResponsiveContainer), {
  ssr: false,
}) as ComponentType<any>

// Date picker components
export const DatePicker = dynamic(() => import("react-datepicker").then((mod) => mod.default), {
  ssr: false,
}) as ComponentType<any>

// Color picker components
export const SketchPicker = dynamic(() => import("react-color").then((mod) => mod.SketchPicker), {
  ssr: false,
}) as ComponentType<any>

export const ChromePicker = dynamic(() => import("react-color").then((mod) => mod.ChromePicker), {
  ssr: false,
}) as ComponentType<any>

export const CompactPicker = dynamic(() => import("react-color").then((mod) => mod.CompactPicker), {
  ssr: false,
}) as ComponentType<any>

// Framer Motion components
export const MotionDiv = dynamic(() => import("framer-motion").then((mod) => mod.motion.div), {
  ssr: false,
}) as ComponentType<any>

export const MotionSpan = dynamic(() => import("framer-motion").then((mod) => mod.motion.span), {
  ssr: false,
}) as ComponentType<any>

export const AnimatePresence = dynamic(() => import("framer-motion").then((mod) => mod.AnimatePresence), {
  ssr: false,
}) as ComponentType<any>
