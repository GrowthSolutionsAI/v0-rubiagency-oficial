import { neon } from "@neondatabase/serverless"

// Obter URL do banco de forma segura
function getDatabaseUrl() {
  return (
    process.env.DATABASE_URL ||
    process.env.POSTGRES_URL ||
    process.env.NEON_DATABASE_URL ||
    process.env.POSTGRES_PRISMA_URL
  )
}

// Cliente do banco
const sql = neon(getDatabaseUrl()!)

// Função para verificar e criar tabelas
export async function setupDatabase() {
  try {
    console.log("🔄 Configurando banco de dados...")

    // 1. Testar conexão
    await sql`SELECT 1 as test`
    console.log("✅ Conexão com banco OK")

    // 2. Verificar se tabelas existem
    const tables = await sql`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public'
      AND table_name IN ('user_registrations', 'user_files', 'system_settings', 'admin_users')
    `

    console.log(
      "📋 Tabelas existentes:",
      tables.map((t) => t.table_name),
    )

    // 3. Criar tabelas se não existirem
    if (tables.length === 0) {
      await createTables()
      await insertDefaultSettings()
      await createAdminUser()
    }

    return true
  } catch (error) {
    console.error("❌ Erro na configuração do banco:", error)
    return false
  }
}

// Criar tabelas
async function createTables() {
  console.log("🏗️ Criando tabelas...")

  await sql`
    CREATE TABLE IF NOT EXISTS user_registrations (
      id SERIAL PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      email VARCHAR(255) NOT NULL,
      phone VARCHAR(50),
      age INTEGER NOT NULL CHECK (age >= 18 AND age <= 65),
      subject VARCHAR(100),
      experience VARCHAR(50),
      message TEXT NOT NULL,
      instagram VARCHAR(255),
      partner_code VARCHAR(50),
      partner_name VARCHAR(255),
      status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      approved_at TIMESTAMP,
      approved_by VARCHAR(100)
    )
  `

  await sql`
    CREATE TABLE IF NOT EXISTS user_files (
      id SERIAL PRIMARY KEY,
      user_registration_id INTEGER NOT NULL REFERENCES user_registrations(id) ON DELETE CASCADE,
      filename VARCHAR(255) NOT NULL,
      original_name VARCHAR(255) NOT NULL,
      file_type VARCHAR(100) NOT NULL,
      file_size INTEGER NOT NULL,
      file_url TEXT NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `

  await sql`
    CREATE TABLE IF NOT EXISTS system_settings (
      id SERIAL PRIMARY KEY,
      setting_key VARCHAR(100) UNIQUE NOT NULL,
      setting_value TEXT,
      description TEXT,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `

  await sql`
    CREATE TABLE IF NOT EXISTS admin_users (
      id SERIAL PRIMARY KEY,
      username VARCHAR(100) UNIQUE NOT NULL,
      email VARCHAR(255) UNIQUE NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      role VARCHAR(50) DEFAULT 'admin',
      is_active BOOLEAN DEFAULT true,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      last_login TIMESTAMP
    )
  `

  // Criar índices importantes
  await sql`CREATE INDEX IF NOT EXISTS idx_user_registrations_status ON user_registrations(status)`
  await sql`CREATE INDEX IF NOT EXISTS idx_user_registrations_created_at ON user_registrations(created_at)`
  await sql`CREATE INDEX IF NOT EXISTS idx_user_registrations_email ON user_registrations(email)`

  console.log("✅ Tabelas criadas com sucesso")
}

// Inserir configurações padrão
async function insertDefaultSettings() {
  console.log("⚙️ Inserindo configurações padrão...")

  const settings = [
    ["database_version", "1.0", "Versão do banco de dados"],
    ["system_status", "online", "Status do sistema"],
    ["max_file_size", "5242880", "Tamanho máximo de arquivo (5MB)"],
    ["allowed_file_types", "image/jpeg,image/png,image/gif,image/webp,application/pdf", "Tipos permitidos"],
    [
      "welcome_message",
      "🌟 Obrigada por se cadastrar na Rubi Agency! Recebemos sua candidatura e nossa equipe irá analisá-la cuidadosamente.",
      "Mensagem de boas-vindas",
    ],
    ["notification_email", "admin@rubiagency.com", "Email para notificações"],
  ]

  for (const [key, value, description] of settings) {
    await sql`
      INSERT INTO system_settings (setting_key, setting_value, description) 
      VALUES (${key}, ${value}, ${description})
      ON CONFLICT (setting_key) DO NOTHING
    `
  }

  console.log("✅ Configurações inseridas")
}

// Criar usuário admin
async function createAdminUser() {
  console.log("👤 Criando usuário administrador...")

  // Hash da senha "admin123" (em produção, use uma senha forte!)
  const passwordHash = "$2b$10$rOzJqQZJqQZJqQZJqQZJqOzJqQZJqQZJqQZJqQZJqQZJqQZJqQZJq"

  await sql`
    INSERT INTO admin_users (username, email, password_hash, role, is_active) 
    VALUES ('admin', 'admin@rubiagency.com', ${passwordHash}, 'admin', true)
    ON CONFLICT (username) DO NOTHING
  `

  console.log("✅ Usuário admin criado")
}

// Função para obter estatísticas reais
export async function getRegistrationStats() {
  try {
    const stats = await sql`
      SELECT 
        COUNT(*) as total,
        COUNT(*) FILTER (WHERE status = 'pending') as pending,
        COUNT(*) FILTER (WHERE status = 'approved') as approved,
        COUNT(*) FILTER (WHERE status = 'rejected') as rejected
      FROM user_registrations
    `

    return {
      total: Number(stats[0].total),
      pending: Number(stats[0].pending),
      approved: Number(stats[0].approved),
      rejected: Number(stats[0].rejected),
    }
  } catch (error) {
    console.error("❌ Erro ao buscar estatísticas:", error)
    return { total: 0, pending: 0, approved: 0, rejected: 0 }
  }
}

// Função para buscar registros recentes
export async function getRecentRegistrations(limit = 5) {
  try {
    const registrations = await sql`
      SELECT id, name, email, phone, status, created_at, instagram, partner_name
      FROM user_registrations 
      ORDER BY created_at DESC 
      LIMIT ${limit}
    `

    return registrations
  } catch (error) {
    console.error("❌ Erro ao buscar registros:", error)
    return []
  }
}
