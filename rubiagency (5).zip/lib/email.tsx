import nodemailer from "nodemailer"

// Verificar configurações de email
const emailConfig = {
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: process.env.SMTP_SECURE,
  user: process.env.SMTP_USER,
  pass: process.env.SMTP_PASS,
  from: process.env.EMAIL_FROM,
}

// Função para verificar se o email está configurado
export function isEmailConfigured(): boolean {
  return !!(emailConfig.host && emailConfig.user && emailConfig.pass && emailConfig.from)
}

// Configuração do transporter com tratamento de erro
const createTransporter = () => {
  if (!isEmailConfigured()) {
    throw new Error("Email configuration is incomplete")
  }

  return nodemailer.createTransporter({
    host: emailConfig.host,
    port: Number.parseInt(emailConfig.port || "465"),
    secure: emailConfig.secure === "true",
    auth: {
      user: emailConfig.user,
      pass: emailConfig.pass,
    },
    tls: {
      rejectUnauthorized: false,
    },
  })
}

// Função para testar conexão de email
export async function testEmailConnection(): Promise<{ success: boolean; message: string }> {
  try {
    if (!isEmailConfigured()) {
      return {
        success: false,
        message: "Configurações de email não encontradas",
      }
    }

    const transporter = createTransporter()
    await transporter.verify()

    return {
      success: true,
      message: "Conexão de email estabelecida com sucesso",
    }
  } catch (error) {
    console.error("Erro na conexão de email:", error)
    return {
      success: false,
      message: `Erro na conexão: ${error instanceof Error ? error.message : "Erro desconhecido"}`,
    }
  }
}

// Função para obter status do serviço de email
export async function getEmailServiceStatus(): Promise<{
  configured: boolean
  connected: boolean
  message: string
  config?: any
}> {
  const configured = isEmailConfigured()

  if (!configured) {
    return {
      configured: false,
      connected: false,
      message: "Configurações de email não encontradas",
      config: {
        host: !!emailConfig.host,
        user: !!emailConfig.user,
        pass: !!emailConfig.pass,
        from: !!emailConfig.from,
      },
    }
  }

  try {
    const transporter = createTransporter()
    await transporter.verify()

    return {
      configured: true,
      connected: true,
      message: "Serviço de email funcionando corretamente",
    }
  } catch (error) {
    return {
      configured: true,
      connected: false,
      message: `Erro na conexão: ${error instanceof Error ? error.message : "Erro desconhecido"}`,
    }
  }
}

// Função base para enviar email
async function sendEmailBase(
  to: string,
  subject: string,
  html: string,
  text?: string,
): Promise<{ success: boolean; message: string }> {
  try {
    if (!isEmailConfigured()) {
      return {
        success: false,
        message: "Email não configurado",
      }
    }

    const transporter = createTransporter()

    const mailOptions = {
      from: emailConfig.from,
      to,
      subject,
      html,
      text: text || html.replace(/<[^>]*>/g, ""),
    }

    await transporter.sendMail(mailOptions)

    return {
      success: true,
      message: "Email enviado com sucesso",
    }
  } catch (error) {
    console.error("Erro ao enviar email:", error)
    return {
      success: false,
      message: `Erro ao enviar email: ${error instanceof Error ? error.message : "Erro desconhecido"}`,
    }
  }
}

// FUNÇÃO PRINCIPAL PARA ENVIAR EMAIL - EXPORTADA
export async function sendEmail(
  toOrOptions: string | { to: string; subject: string; html: string; text?: string },
  subject?: string,
  html?: string,
  text?: string,
): Promise<{ success: boolean; message: string }> {
  if (typeof toOrOptions === "object") {
    return sendEmailBase(toOrOptions.to, toOrOptions.subject, toOrOptions.html, toOrOptions.text)
  } else {
    return sendEmailBase(toOrOptions, subject!, html!, text)
  }
}

// Função para enviar email de aprovação
export async function sendApprovalEmail(email: string, name: string): Promise<{ success: boolean; message: string }> {
  const subject = "✅ Sua inscrição foi aprovada - Rubi Agency"
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #10b981;">Parabéns, ${name}!</h2>
      <p>Sua inscrição na Rubi Agency foi <strong>aprovada</strong>!</p>
      <p>Em breve entraremos em contato com mais informações sobre os próximos passos.</p>
      <p>Obrigado por escolher a Rubi Agency!</p>
      <hr>
      <p style="color: #666; font-size: 12px;">
        Rubi Agency - Transformando ideias em realidade<br>
        ${process.env.NEXT_PUBLIC_SITE_URL || "https://www.rubiagency.com"}
      </p>
    </div>
  `

  return sendEmailBase(email, subject, html)
}

// Função para enviar email de rejeição
export async function sendRejectionEmail(
  email: string,
  name: string,
  reason?: string,
): Promise<{ success: boolean; message: string }> {
  const subject = "Atualização sobre sua inscrição - Rubi Agency"
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #ef4444;">Olá, ${name}</h2>
      <p>Agradecemos seu interesse na Rubi Agency.</p>
      <p>Infelizmente, não poderemos prosseguir com sua inscrição neste momento.</p>
      ${reason ? `<p><strong>Motivo:</strong> ${reason}</p>` : ""}
      <p>Encorajamos você a se inscrever novamente no futuro.</p>
      <p>Obrigado pela compreensão.</p>
      <hr>
      <p style="color: #666; font-size: 12px;">
        Rubi Agency - Transformando ideias em realidade<br>
        ${process.env.NEXT_PUBLIC_SITE_URL || "https://www.rubiagency.com"}
      </p>
    </div>
  `

  return sendEmailBase(email, subject, html)
}

// Função para enviar notificação de contato
export async function sendContactNotification(data: {
  name: string
  email: string
  phone?: string
  instagram?: string
  message: string
  partner_code?: string
}): Promise<{ success: boolean; message: string }> {
  const adminEmail = emailConfig.from || "contato@rubiagency.com"
  const subject = "📩 Nova mensagem de contato - Rubi Agency"

  const adminHtml = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #3b82f6;">Nova Mensagem de Contato</h2>
      <p><strong>Nome:</strong> ${data.name}</p>
      <p><strong>Email:</strong> ${data.email}</p>
      ${data.phone ? `<p><strong>Telefone:</strong> ${data.phone}</p>` : ""}
      ${data.instagram ? `<p><strong>Instagram:</strong> ${data.instagram}</p>` : ""}
      ${data.partner_code ? `<p><strong>Código do Parceiro:</strong> ${data.partner_code}</p>` : ""}
      <p><strong>Mensagem:</strong></p>
      <div style="background: #f3f4f6; padding: 15px; border-radius: 5px;">
        ${data.message}
      </div>
      <hr>
      <p style="color: #666; font-size: 12px;">
        Recebido em: ${new Date().toLocaleString("pt-BR")}
      </p>
    </div>
  `

  // Enviar para admin
  const adminResult = await sendEmailBase(adminEmail, subject, adminHtml)

  if (!adminResult.success) {
    return adminResult
  }

  // Enviar confirmação para cliente
  const clientSubject = "✅ Mensagem recebida - Rubi Agency"
  const clientHtml = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #10b981;">Olá, ${data.name}!</h2>
      <p>Recebemos sua mensagem e agradecemos o contato!</p>
      <p>Nossa equipe analisará sua solicitação e retornará em breve.</p>
      <p>Obrigado por escolher a Rubi Agency!</p>
      <hr>
      <p style="color: #666; font-size: 12px;">
        Rubi Agency - Transformando ideias em realidade<br>
        ${process.env.NEXT_PUBLIC_SITE_URL || "https://www.rubiagency.com"}
      </p>
    </div>
  `

  return sendEmailBase(data.email, clientSubject, clientHtml)
}

// Função para enviar email de teste
export async function sendTestEmail(to?: string): Promise<{ success: boolean; message: string }> {
  const testEmail = to || emailConfig.from || "contato@rubiagency.com"
  const subject = "🧪 Teste de Email - Rubi Agency"
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #3b82f6;">Teste de Email</h2>
      <p>Este é um email de teste do sistema Rubi Agency.</p>
      <p><strong>Data/Hora:</strong> ${new Date().toLocaleString("pt-BR")}</p>
      <p><strong>Status:</strong> ✅ Sistema funcionando corretamente</p>
      <hr>
      <p style="color: #666; font-size: 12px;">
        Rubi Agency - Sistema de Email<br>
        ${process.env.NEXT_PUBLIC_SITE_URL || "https://www.rubiagency.com"}
      </p>
    </div>
  `

  return sendEmailBase(testEmail, subject, html)
}

// Log de inicialização apenas no servidor
if (typeof window === "undefined") {
  console.log("📧 Email configuration:")
  console.log("- Host:", !!emailConfig.host)
  console.log("- User:", !!emailConfig.user)
  console.log("- Pass:", !!emailConfig.pass)
  console.log("- From:", !!emailConfig.from)
  console.log("- Configured:", isEmailConfigured())
}
