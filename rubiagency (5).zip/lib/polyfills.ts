// Polyfills simplificados para resolver problemas de SSR

// Verificar se estamos no servidor
const isServer = typeof window === "undefined"

if (isServer) {
  // Definir self como undefined no servidor
  if (typeof globalThis.self === "undefined") {
    // @ts-ignore
    globalThis.self = undefined
  }

  // Definir window como undefined no servidor
  if (typeof globalThis.window === "undefined") {
    // @ts-ignore
    globalThis.window = undefined
  }

  // Definir document como undefined no servidor
  if (typeof globalThis.document === "undefined") {
    // @ts-ignore
    globalThis.document = undefined
  }

  // Definir navigator como undefined no servidor
  if (typeof globalThis.navigator === "undefined") {
    // @ts-ignore
    globalThis.navigator = undefined
  }

  // Definir location como undefined no servidor
  if (typeof globalThis.location === "undefined") {
    // @ts-ignore
    globalThis.location = undefined
  }
}

// Exportar uma função vazia para que o módulo possa ser importado
export function initPolyfills() {
  // Esta função não faz nada, mas permite que o módulo seja importado
  return true
}

// Log apenas no servidor para debug
if (isServer && process.env.NODE_ENV === "development") {
  console.log("🔧 Polyfills initialized for server-side rendering")
}
