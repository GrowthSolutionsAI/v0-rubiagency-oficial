import type { ComponentType } from "react"

// Re-export client components
export {
  LineChart,
  BarChart,
  PieChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Line,
  Bar,
  Cell,
  ResponsiveContainer,
  DatePicker,
  SketchPicker,
  ChromePicker,
  CompactPicker,
  MotionDiv,
  MotionSpan,
  AnimatePresence,
} from "./client-dynamic-components"

// Environment detection utilities
export const isServer = () => typeof window === "undefined"
export const isClient = () => typeof window !== "undefined"
export const isBrowser = () => typeof window !== "undefined" && typeof document !== "undefined"
export const isNode = () => typeof process !== "undefined" && process.versions && process.versions.node

// Safe access utilities - FIXED SYNTAX
export const safeAccess = (fn: () => any, fallback: any): any => {
  try {
    return isClient() ? fn() : fallback
  } catch (error) {
    console.warn("Safe access failed:", error)
    return fallback
  }
}

export const safeAsyncAccess = async (fn: () => Promise<any>, fallback: any): Promise<any> => {
  try {
    return isClient() ? await fn() : fallback
  } catch (error) {
    console.warn("Safe async access failed:", error)
    return fallback
  }
}

// Component creation utility
export const createClientComponent = (
  importFn: () => Promise<{ default: ComponentType<any> }>,
  fallback?: ComponentType<any>,
) => {
  if (isServer()) {
    return fallback || (() => null)
  }

  return importFn()
    .then((mod) => mod.default)
    .catch(() => fallback || (() => null))
}

// Environment checks
export const hasLocalStorage = () => safeAccess(() => !!window.localStorage, false)
export const hasSessionStorage = () => safeAccess(() => !!window.sessionStorage, false)
export const hasGeolocation = () => safeAccess(() => !!navigator.geolocation, false)
export const hasWebGL = () =>
  safeAccess(() => {
    const canvas = document.createElement("canvas")
    return !!(canvas.getContext("webgl") || canvas.getContext("experimental-webgl"))
  }, false)

// Device detection
export const isMobile = () =>
  safeAccess(() => {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
  }, false)

export const isTablet = () =>
  safeAccess(() => {
    return /iPad|Android(?!.*Mobile)/i.test(navigator.userAgent)
  }, false)

export const isDesktop = () =>
  safeAccess(() => {
    return !isMobile() && !isTablet()
  }, true)

// Browser detection
export const isSafari = () =>
  safeAccess(() => {
    return /^((?!chrome|android).)*safari/i.test(navigator.userAgent)
  }, false)

export const isChrome = () =>
  safeAccess(() => {
    return /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor)
  }, false)

export const isFirefox = () =>
  safeAccess(() => {
    return /Firefox/.test(navigator.userAgent)
  }, false)

export const isEdge = () =>
  safeAccess(() => {
    return /Edge/.test(navigator.userAgent)
  }, false)

// Network detection
export const isOnline = () => safeAccess(() => navigator.onLine, true)

export const getConnectionType = () =>
  safeAccess(() => {
    const connection =
      (navigator as any).connection || (navigator as any).mozConnection || (navigator as any).webkitConnection
    return connection ? connection.effectiveType : "unknown"
  }, "unknown")

// Pre-configured components
export const AnalyticsChart = () => safeAccess(() => "AnalyticsChart", "Loading...")
export const DatePickerForm = () => safeAccess(() => "DatePickerForm", "Loading...")
export const ColorPickerForm = () => safeAccess(() => "ColorPickerForm", "Loading...")
