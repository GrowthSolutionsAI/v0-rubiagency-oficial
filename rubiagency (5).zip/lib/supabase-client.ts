"use client"

import { createClient } from "@supabase/supabase-js"
import type { Database } from "./supabase"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

// ✅ CLIENTE SEGURO PARA COMPONENTES CLIENT-SIDE
// Apenas usa ANON KEY - nunca SERVICE ROLE KEY
export const supabaseClient = createClient<Database>(supabaseUrl, supabaseAnonKey)

// ✅ HOOK PARA USAR EM COMPONENTES REACT
export function useSupabase() {
  return supabaseClient
}

// ✅ VERIFICAR SE ESTÁ CONFIGURADO
export const isConfigured = !!(supabaseUrl && supabaseAnonKey)
