// Environment detection utilities

export function isServer(): boolean {
  return typeof window === "undefined"
}

export function isClient(): boolean {
  return typeof window !== "undefined"
}

export function isBrowser(): boolean {
  return typeof window !== "undefined" && typeof document !== "undefined"
}

export function isNode(): boolean {
  return typeof process !== "undefined" && process.versions && process.versions.node
}

export function isDevelopment(): boolean {
  return process.env.NODE_ENV === "development"
}

export function isProduction(): boolean {
  return process.env.NODE_ENV === "production"
}

export function isTest(): boolean {
  return process.env.NODE_ENV === "test"
}

// Feature detection
export function hasLocalStorage(): boolean {
  if (isServer()) return false

  try {
    const test = "__localStorage_test__"
    localStorage.setItem(test, test)
    localStorage.removeItem(test)
    return true
  } catch {
    return false
  }
}

export function hasSessionStorage(): boolean {
  if (isServer()) return false

  try {
    const test = "__sessionStorage_test__"
    sessionStorage.setItem(test, test)
    sessionStorage.removeItem(test)
    return true
  } catch {
    return false
  }
}

export function hasGeolocation(): boolean {
  return isBrowser() && "geolocation" in navigator
}

export function hasClipboard(): boolean {
  return isBrowser() && "clipboard" in navigator
}

export function hasNotifications(): boolean {
  return isBrowser() && "Notification" in window
}

export function hasServiceWorker(): boolean {
  return isBrowser() && "serviceWorker" in navigator
}

export function hasWebGL(): boolean {
  if (isServer()) return false

  try {
    const canvas = document.createElement("canvas")
    return !!(canvas.getContext("webgl") || canvas.getContext("experimental-webgl"))
  } catch {
    return false
  }
}

export function hasWebRTC(): boolean {
  return isBrowser() && ("RTCPeerConnection" in window || "webkitRTCPeerConnection" in window)
}

export function hasIndexedDB(): boolean {
  return isBrowser() && "indexedDB" in window
}

export function hasWebWorkers(): boolean {
  return isBrowser() && "Worker" in window
}

export function hasFileAPI(): boolean {
  return isBrowser() && "File" in window && "FileReader" in window && "FileList" in window && "Blob" in window
}

export function hasDragAndDrop(): boolean {
  return isBrowser() && "draggable" in document.createElement("div")
}

export function hasHistory(): boolean {
  return isBrowser() && "history" in window && "pushState" in window.history
}

export function hasWebSockets(): boolean {
  return isBrowser() && "WebSocket" in window
}

export function hasCanvas(): boolean {
  if (isServer()) return false

  try {
    const canvas = document.createElement("canvas")
    return !!(canvas.getContext && canvas.getContext("2d"))
  } catch {
    return false
  }
}

export function hasAudio(): boolean {
  if (isServer()) return false

  try {
    return !!document.createElement("audio").canPlayType
  } catch {
    return false
  }
}

export function hasVideo(): boolean {
  if (isServer()) return false

  try {
    return !!document.createElement("video").canPlayType
  } catch {
    return false
  }
}

// Device detection
export function isMobile(): boolean {
  if (isServer()) return false

  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
}

export function isTablet(): boolean {
  if (isServer()) return false

  return /iPad|Android(?!.*Mobile)/i.test(navigator.userAgent)
}

export function isDesktop(): boolean {
  return !isMobile() && !isTablet()
}

export function isIOS(): boolean {
  if (isServer()) return false

  return /iPad|iPhone|iPod/.test(navigator.userAgent)
}

export function isAndroid(): boolean {
  if (isServer()) return false

  return /Android/.test(navigator.userAgent)
}

export function isSafari(): boolean {
  if (isServer()) return false

  return /^((?!chrome|android).)*safari/i.test(navigator.userAgent)
}

export function isChrome(): boolean {
  if (isServer()) return false

  return /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor)
}

export function isFirefox(): boolean {
  if (isServer()) return false

  return /Firefox/.test(navigator.userAgent)
}

export function isEdge(): boolean {
  if (isServer()) return false

  return /Edge/.test(navigator.userAgent)
}

// Network detection
export function isOnline(): boolean {
  if (isServer()) return true

  return navigator.onLine
}

export function getConnectionType(): string {
  if (isServer()) return "unknown"

  const connection =
    (navigator as any).connection || (navigator as any).mozConnection || (navigator as any).webkitConnection
  return connection ? connection.effectiveType || connection.type || "unknown" : "unknown"
}

// Screen detection
export function getScreenSize(): { width: number; height: number } {
  if (isServer()) return { width: 0, height: 0 }

  return {
    width: window.screen.width,
    height: window.screen.height,
  }
}

export function getViewportSize(): { width: number; height: number } {
  if (isServer()) return { width: 0, height: 0 }

  return {
    width: window.innerWidth,
    height: window.innerHeight,
  }
}

export function getDevicePixelRatio(): number {
  if (isServer()) return 1

  return window.devicePixelRatio || 1
}

// Utility functions for safe access
export function safeAccess<T>(fn: () => T, fallback: T): T {
  try {
    return fn()
  } catch {
    return fallback
  }
}

export function safeAsyncAccess<T>(fn: () => Promise<T>, fallback: T): Promise<T> {
  return fn().catch(() => fallback)
}
