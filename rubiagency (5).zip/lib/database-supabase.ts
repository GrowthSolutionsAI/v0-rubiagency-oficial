import { supabaseAdmin, isSupabaseConfigured } from "./supabase"
import type { UserRegistration, Partner, SystemSetting } from "./supabase"

// =====================================================
// FUNÇÕES DE CADASTRO DE USUÁRIOS
// =====================================================

export async function createUserRegistration(data: {
  name: string
  email: string
  phone?: string | null
  instagram?: string | null
  age: number
  subject?: string | null
  experience?: string | null
  message: string
  status: "pending" | "approved" | "rejected"
  partner_code?: string | null
}): Promise<UserRegistration> {
  console.log("🔄 Creating user registration with Supabase:", data.name)

  if (!isSupabaseConfigured() || !supabaseAdmin) {
    throw new Error("Supabase não configurado")
  }

  try {
    // Buscar informações do parceiro se código fornecido
    let partner_id = null
    let partner_name = null

    if (data.partner_code) {
      const partner = await getPartnerByCode(data.partner_code)
      if (partner) {
        partner_id = partner.id
        partner_name = partner.name
        console.log("✅ Partner found:", partner.name)
      }
    }

    // Preparar dados para inserção
    const insertData = {
      name: data.name,
      email: data.email,
      phone: data.phone,
      instagram: data.instagram,
      age: data.age,
      subject: data.subject,
      experience: data.experience,
      message: data.message,
      status: data.status,
      partner_id,
      partner_code: data.partner_code,
      partner_name,
    }

    // Inserir no banco
    const { data: registration, error } = await supabaseAdmin
      .from("user_registrations")
      .insert([insertData])
      .select()
      .single()

    if (error) {
      console.error("❌ Error inserting registration:", error)
      throw error
    }

    // Atualizar contador do parceiro se aplicável
    if (partner_id) {
      await supabaseAdmin
        .from("partners")
        .update({ total_referrals: supabaseAdmin.raw("total_referrals + 1") })
        .eq("id", partner_id)
    }

    console.log("✅ Registration created successfully:", registration.id)
    return registration as UserRegistration
  } catch (error) {
    console.error("❌ Error in createUserRegistration:", error)
    throw error
  }
}

export async function getUserRegistrations(status?: string): Promise<UserRegistration[]> {
  console.log("📋 Getting user registrations:", { status, configured: isSupabaseConfigured() })

  if (!isSupabaseConfigured() || !supabaseAdmin) {
    console.warn("⚠️ Supabase not configured, returning empty array")
    return []
  }

  try {
    let query = supabaseAdmin.from("user_registrations").select("*").order("created_at", { ascending: false })

    if (status) {
      query = query.eq("status", status)
    }

    const { data, error } = await query

    if (error) {
      console.error("❌ Error fetching registrations:", error)
      throw error
    }

    console.log("📋 Registrations found:", data?.length || 0)
    return (data as UserRegistration[]) || []
  } catch (error) {
    console.error("❌ Error in getUserRegistrations:", error)
    return []
  }
}

export async function getUserRegistrationById(id: number): Promise<UserRegistration | undefined> {
  console.log("🔍 Getting registration by ID:", id)

  if (!isSupabaseConfigured() || !supabaseAdmin) {
    return undefined
  }

  try {
    const { data, error } = await supabaseAdmin.from("user_registrations").select("*").eq("id", id).single()

    if (error) {
      if (error.code === "PGRST116") return undefined // Not found
      throw error
    }

    return data as UserRegistration
  } catch (error) {
    console.error("❌ Error in getUserRegistrationById:", error)
    return undefined
  }
}

export async function updateUserRegistrationStatus(
  id: number,
  status: "approved" | "rejected",
  approvedBy: string,
): Promise<UserRegistration> {
  console.log("📝 Updating registration status:", { id, status, approvedBy })

  if (!isSupabaseConfigured() || !supabaseAdmin) {
    throw new Error("Supabase não configurado")
  }

  try {
    const updateData: any = {
      status,
      updated_at: new Date().toISOString(),
    }

    if (status === "approved") {
      updateData.approved_at = new Date().toISOString()
      updateData.approved_by = approvedBy
    }

    const { data, error } = await supabaseAdmin
      .from("user_registrations")
      .update(updateData)
      .eq("id", id)
      .select()
      .single()

    if (error) {
      console.error("❌ Error updating registration status:", error)
      throw error
    }

    console.log("✅ Registration status updated successfully")
    return data as UserRegistration
  } catch (error) {
    console.error("❌ Error in updateUserRegistrationStatus:", error)
    throw error
  }
}

// =====================================================
// FUNÇÕES DE PARCEIROS
// =====================================================

export async function getPartners(): Promise<Partner[]> {
  console.log("🤝 Getting partners")

  if (!isSupabaseConfigured() || !supabaseAdmin) {
    return []
  }

  try {
    const { data, error } = await supabaseAdmin.from("partners").select("*").order("created_at", { ascending: false })

    if (error) {
      console.error("❌ Error fetching partners:", error)
      throw error
    }

    return (data as Partner[]) || []
  } catch (error) {
    console.error("❌ Error in getPartners:", error)
    return []
  }
}

export async function getPartnerByCode(code: string): Promise<Partner | undefined> {
  console.log("🔍 Getting partner by code:", code)

  if (!isSupabaseConfigured() || !supabaseAdmin) {
    return undefined
  }

  try {
    const { data, error } = await supabaseAdmin
      .from("partners")
      .select("*")
      .eq("code", code)
      .eq("is_active", true)
      .single()

    if (error) {
      if (error.code === "PGRST116") return undefined // Not found
      throw error
    }

    return data as Partner
  } catch (error) {
    console.error("❌ Error in getPartnerByCode:", error)
    return undefined
  }
}

export async function getPartnerById(id: number): Promise<Partner | undefined> {
  console.log("🔍 Getting partner by ID:", id)

  if (!isSupabaseConfigured() || !supabaseAdmin) {
    return undefined
  }

  try {
    const { data, error } = await supabaseAdmin.from("partners").select("*").eq("id", id).single()

    if (error) {
      if (error.code === "PGRST116") return undefined // Not found
      throw error
    }

    return data as Partner
  } catch (error) {
    console.error("❌ Error in getPartnerById:", error)
    return undefined
  }
}

export async function createPartner(
  data: Omit<Partner, "id" | "created_at" | "updated_at" | "total_referrals">,
): Promise<Partner> {
  console.log("🤝 Creating partner:", data.name)

  if (!isSupabaseConfigured() || !supabaseAdmin) {
    throw new Error("Supabase não configurado")
  }

  try {
    const { data: partner, error } = await supabaseAdmin
      .from("partners")
      .insert([{ ...data, total_referrals: 0 }])
      .select()
      .single()

    if (error) {
      console.error("❌ Error creating partner:", error)
      throw error
    }

    console.log("✅ Partner created successfully:", partner.id)
    return partner as Partner
  } catch (error) {
    console.error("❌ Error in createPartner:", error)
    throw error
  }
}

export async function updatePartner(id: number, data: Partial<Partner>): Promise<Partner> {
  console.log("🤝 Updating partner:", id)

  if (!isSupabaseConfigured() || !supabaseAdmin) {
    throw new Error("Supabase não configurado")
  }

  try {
    const { data: partner, error } = await supabaseAdmin
      .from("partners")
      .update({ ...data, updated_at: new Date().toISOString() })
      .eq("id", id)
      .select()
      .single()

    if (error) {
      console.error("❌ Error updating partner:", error)
      throw error
    }

    console.log("✅ Partner updated successfully")
    return partner as Partner
  } catch (error) {
    console.error("❌ Error in updatePartner:", error)
    throw error
  }
}

// =====================================================
// FUNÇÕES DE CONFIGURAÇÕES DO SISTEMA
// =====================================================

export async function getSystemSetting(key: string): Promise<SystemSetting | undefined> {
  console.log("⚙️ Getting system setting:", key)

  if (!isSupabaseConfigured() || !supabaseAdmin) {
    return undefined
  }

  try {
    const { data, error } = await supabaseAdmin.from("system_settings").select("*").eq("setting_key", key).single()

    if (error) {
      if (error.code === "PGRST116") return undefined // Not found
      throw error
    }

    return data as SystemSetting
  } catch (error) {
    console.error("❌ Error in getSystemSetting:", error)
    return undefined
  }
}

export async function updateSystemSetting(key: string, value: string): Promise<SystemSetting> {
  console.log("⚙️ Updating system setting:", key)

  if (!isSupabaseConfigured() || !supabaseAdmin) {
    throw new Error("Supabase não configurado")
  }

  try {
    const { data, error } = await supabaseAdmin
      .from("system_settings")
      .upsert({
        setting_key: key,
        setting_value: value,
        updated_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (error) {
      console.error("❌ Error updating system setting:", error)
      throw error
    }

    console.log("✅ System setting updated successfully")
    return data as SystemSetting
  } catch (error) {
    console.error("❌ Error in updateSystemSetting:", error)
    throw error
  }
}

export async function getAllSystemSettings(): Promise<SystemSetting[]> {
  console.log("⚙️ Getting all system settings")

  if (!isSupabaseConfigured() || !supabaseAdmin) {
    return []
  }

  try {
    const { data, error } = await supabaseAdmin.from("system_settings").select("*").order("setting_key")

    if (error) {
      console.error("❌ Error fetching system settings:", error)
      throw error
    }

    return (data as SystemSetting[]) || []
  } catch (error) {
    console.error("❌ Error in getAllSystemSettings:", error)
    return []
  }
}

// =====================================================
// FUNÇÕES DE ESTATÍSTICAS
// =====================================================

export async function getRegistrationStats() {
  console.log("📊 Getting registration stats")

  if (!isSupabaseConfigured() || !supabaseAdmin) {
    return {
      total: 0,
      pending: 0,
      approved: 0,
      rejected: 0,
    }
  }

  try {
    const { data, error } = await supabaseAdmin.from("user_registrations").select("status")

    if (error) {
      console.error("❌ Error fetching registration stats:", error)
      throw error
    }

    const stats = {
      total: data?.length || 0,
      pending: data?.filter((r) => r.status === "pending").length || 0,
      approved: data?.filter((r) => r.status === "approved").length || 0,
      rejected: data?.filter((r) => r.status === "rejected").length || 0,
    }

    console.log("📊 Registration stats:", stats)
    return stats
  } catch (error) {
    console.error("❌ Error in getRegistrationStats:", error)
    return {
      total: 0,
      pending: 0,
      approved: 0,
      rejected: 0,
    }
  }
}

// =====================================================
// FUNÇÕES DE TESTE E DIAGNÓSTICO
// =====================================================

export async function testDatabaseConnection(): Promise<boolean> {
  console.log("🔍 Testing database connection")

  if (!isSupabaseConfigured() || !supabaseAdmin) {
    console.log("❌ Supabase not configured")
    return false
  }

  try {
    const { data, error } = await supabaseAdmin.from("system_settings").select("count", { count: "exact" }).limit(1)

    if (error) {
      console.error("❌ Database connection test failed:", error)
      return false
    }

    console.log("✅ Database connection test successful")
    return true
  } catch (error) {
    console.error("❌ Database connection test error:", error)
    return false
  }
}

// =====================================================
// FUNÇÕES DE COMPATIBILIDADE
// =====================================================

// Manter compatibilidade com código existente
export const getRegistrations = getUserRegistrations
export const getPartnerRegistrations = async (partnerId: number) => {
  const registrations = await getUserRegistrations()
  return registrations.filter((r) => r.partner_id === partnerId)
}

// Função para obter informações do banco
export function getDatabaseInfo() {
  return {
    type: "Supabase",
    configured: isSupabaseConfigured(),
    available: isSupabaseConfigured(),
    status: isSupabaseConfigured() ? "Conectado" : "Não configurado",
  }
}
