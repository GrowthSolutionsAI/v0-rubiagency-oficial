import { cookies } from "next/headers"
import { redirect } from "next/navigation"

// Admin credentials
const ADMIN_EMAIL = "contato@rubiagency.com"
const ADMIN_PASSWORD = "admin123"

// Cookie configuration
const AUTH_COOKIE_NAME = "admin-auth"
const AUTH_COOKIE_MAX_AGE = 24 * 60 * 60 // 24 hours

export interface AdminUser {
  email: string
  name: string
  role: string
}

// Validate admin credentials
export function validateAdminCredentials(email: string, password: string): boolean {
  return email === ADMIN_EMAIL && password === ADMIN_PASSWORD
}

// Create admin session
export async function createAdminSession(): Promise<void> {
  const cookieStore = await cookies()

  cookieStore.set(AUTH_COOKIE_NAME, "authenticated", {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: AUTH_COOKIE_MAX_AGE,
    path: "/",
  })
}

// Check if admin is authenticated
export async function isAdminAuthenticated(): Promise<boolean> {
  try {
    const cookieStore = await cookies()
    const authCookie = cookieStore.get(AUTH_COOKIE_NAME)

    return authCookie?.value === "authenticated"
  } catch (error) {
    console.error("Error checking admin authentication:", error)
    return false
  }
}

// Get current admin user
export async function getCurrentAdmin(): Promise<AdminUser | null> {
  const isAuthenticated = await isAdminAuthenticated()

  if (!isAuthenticated) {
    return null
  }

  return {
    email: ADMIN_EMAIL,
    name: "Administrador",
    role: "admin",
  }
}

// Require authentication (redirect if not authenticated)
export async function requireAuth(): Promise<AdminUser> {
  const admin = await getCurrentAdmin()

  if (!admin) {
    redirect("/admin/login")
  }

  return admin
}

// Logout admin
export async function logoutAdmin(): Promise<void> {
  const cookieStore = await cookies()

  cookieStore.delete(AUTH_COOKIE_NAME)
}

// Admin login action
export async function loginAdmin(email: string, password: string): Promise<{ success: boolean; message: string }> {
  try {
    if (!validateAdminCredentials(email, password)) {
      return {
        success: false,
        message: "Email ou senha incorretos",
      }
    }

    await createAdminSession()

    return {
      success: true,
      message: "Login realizado com sucesso!",
    }
  } catch (error) {
    console.error("Error during admin login:", error)
    return {
      success: false,
      message: "Erro interno do servidor",
    }
  }
}
