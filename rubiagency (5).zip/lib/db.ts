// =====================================================
// DATABASE CLIENT - SUPABASE ONLY
// =====================================================
// Este arquivo mantém compatibilidade com código legado
// Redireciona todas as operações para Supabase

import { getSupabaseClient, getSupabaseAdmin, testSupabaseConnection } from "./supabase"

// Cliente principal (redireciona para Supabase)
export const db = getSupabaseClient()

// Cliente admin (redireciona para Supabase)
export const dbAdmin = getSupabaseAdmin()

// Função de teste de conexão
export async function testConnection() {
  const result = await testSupabaseConnection()
  return result.success
}

// Função para executar queries (compatibilidade)
export async function executeQuery(query: string, params: any[] = []) {
  console.warn("⚠️ executeQuery is deprecated. Use Supabase client directly.")

  try {
    const client = getSupabaseClient()
    if (!client) {
      return { success: false, error: "Supabase not configured" }
    }

    // Esta função é mantida apenas para compatibilidade
    // Em produção, use as funções específicas do Supabase
    return { success: true, data: [] }
  } catch (error) {
    return { success: false, error: error.message }
  }
}

// Função para inicializar o banco
export async function initializeDatabase() {
  try {
    console.log("🔄 Initializing Supabase connection...")

    const result = await testSupabaseConnection()

    if (result.success) {
      console.log("✅ Supabase connection successful")
      return true
    } else {
      console.log("❌ Supabase connection failed:", result.message)
      return false
    }
  } catch (error) {
    console.error("❌ Database initialization error:", error)
    return false
  }
}

// Log de inicialização
console.log("🗄️ Database client configured for Supabase")
