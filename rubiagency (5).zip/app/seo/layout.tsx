import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Estratégia Digital | Rubi Agency",
  description:
    "Conheça nossa estratégia digital completa para criadoras de conteúdo. Marketing digital especializado, SEO otimizado e gestão de carreira profissional para maximizar seus resultados.",
}

export default function SEOLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return <>{children}</>
}
