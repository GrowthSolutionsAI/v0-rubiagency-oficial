import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import SEOOptimizedContent from "@/components/seo-optimized-content"
import WhatsAppButton from "@/components/whatsapp-button"
import AIChat from "@/components/ai-chat"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Estratégia Digital | Rubi Agency",
  description:
    "Conheça nossa estratégia digital completa para criadoras de conteúdo. Marketing digital especializado, SEO otimizado e gestão de carreira profissional para maximizar seus resultados.",
  keywords: [
    "estratégia digital",
    "marketing para criadoras",
    "SEO para modelos",
    "gestão de carreira digital",
    "marketing digital OnlyFans",
    "agência especializada",
  ],
  openGraph: {
    title: "Estratégia Digital para Criadoras de Conteúdo | Rubi Agency",
    description:
      "Estratégias avançadas de marketing digital e SEO desenvolvidas especificamente para criadoras de conteúdo adulto.",
    images: [
      {
        url: "/og-image-seo.jpg",
        width: 1200,
        height: 630,
        alt: "Estratégia Digital Rubi Agency",
      },
    ],
  },
}

export default function SEOPage() {
  return (
    <main className="min-h-screen bg-black text-white overflow-hidden">
      <Navbar />

      {/* Hero Section */}
      <section className="pt-32 pb-20 premium-gradient relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(220,38,38,0.1),transparent_50%)]"></div>
        </div>

        <div className="container mx-auto container-padding relative z-10">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-3 mb-6">
              <div className="h-px w-12 bg-gradient-to-r from-transparent to-gold"></div>
              <span className="text-overline text-gold">Estratégia Digital</span>
              <div className="h-px w-12 bg-gradient-to-l from-transparent to-gold"></div>
            </div>

            <h1 className="text-headline text-white mb-8">
              Marketing Digital e <span className="text-gradient">SEO Otimizado</span>
            </h1>

            <p className="text-body-large text-platinum/80 max-w-4xl mx-auto">
              Conheça nossa estratégia digital completa para criadoras de conteúdo. Desenvolvemos soluções
              personalizadas que maximizam sua visibilidade online e convertem seguidores em clientes fiéis.
            </p>
          </div>
        </div>
      </section>

      <SEOOptimizedContent />

      <Footer />
      <WhatsAppButton />
      <AIChat />
    </main>
  )
}
