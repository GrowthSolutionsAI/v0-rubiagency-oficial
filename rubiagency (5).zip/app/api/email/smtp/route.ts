import { type NextRequest, NextResponse } from "next/server"
import { sendEmail, testEmailConnection } from "@/lib/email"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, to, subject, html, text } = body

    if (action === "test") {
      const result = await testEmailConnection()
      return NextResponse.json(result)
    }

    if (action === "send") {
      if (!to || !subject || !html) {
        return NextResponse.json(
          { success: false, error: "Missing required fields: to, subject, html" },
          { status: 400 },
        )
      }

      const result = await sendEmail(to, subject, html, text)
      return NextResponse.json({ success: true, result })
    }

    return NextResponse.json({ success: false, error: 'Invalid action. Use "test" or "send"' }, { status: 400 })
  } catch (error) {
    console.error("Email API error:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function GET() {
  try {
    const { getEmailServiceStatus } = await import("@/lib/email")
    const status = await getEmailServiceStatus()
    return NextResponse.json(status)
  } catch (error) {
    console.error("Email status error:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
