import { NextResponse } from "next/server"
import { testContactSubmission } from "@/app/actions/contact"

export async function GET() {
  return NextResponse.json({
    message: "Test Form API",
    instructions: "Use POST to run a test form submission",
    endpoints: {
      "POST /api/test-form": "Execute test form submission",
    },
    testData: {
      name: "Maria Silva Teste",
      email: "maria.teste@email.com",
      phone: "+55 11 99999-8888",
      instagram: "@maria_teste_model",
      age: 25,
      experience: "intermediate",
      partner_code: "MODELO_SP",
    },
  })
}

export async function POST() {
  try {
    console.log("🧪 API: Running test form submission...")

    const result = await testContactSubmission()

    console.log("🧪 API: Test completed:", result)

    return NextResponse.json({
      success: true,
      message: "Test form submission completed",
      result: result,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("❌ API: Test form submission failed:", error)

    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
