import { type NextRequest, NextResponse } from "next/server"
import { getSupabaseAdmin } from "@/lib/supabase"

export async function GET(request: NextRequest) {
  try {
    const supabase = getSupabaseAdmin()

    // Verificar conexão com Supabase
    const { data: testData, error: testError } = await supabase.from("user_registrations").select("count(*)").limit(1)

    // Verificar variáveis de ambiente (sem expor valores)
    const envCheck = {
      supabase_url: !!process.env.NEXT_PUBLIC_SUPABASE_URL,
      supabase_anon_key: !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
      supabase_service_key: !!process.env.SUPABASE_SERVICE_ROLE_KEY,
      smtp_configured: !!(process.env.SMTP_HOST && process.env.SMTP_USER),
      admin_email: !!process.env.ADMIN_EMAIL,
      app_url: !!process.env.NEXT_PUBLIC_APP_URL,
    }

    // Estatísticas básicas
    const { data: registrations } = await supabase.from("user_registrations").select("status")

    const stats = {
      total_registrations: registrations?.length || 0,
      pending: registrations?.filter((r) => r.status === "pending").length || 0,
      approved: registrations?.filter((r) => r.status === "approved").length || 0,
      rejected: registrations?.filter((r) => r.status === "rejected").length || 0,
    }

    return NextResponse.json({
      success: true,
      timestamp: new Date().toISOString(),
      environment_check: envCheck,
      database_connection: !testError,
      statistics: stats,
      system_status: "operational",
    })
  } catch (error) {
    console.error("Debug stats error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch debug stats",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
