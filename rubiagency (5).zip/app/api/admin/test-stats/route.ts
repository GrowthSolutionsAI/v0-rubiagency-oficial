import { NextResponse } from "next/server"
import { getRegistrations } from "@/lib/database"

export async function GET() {
  try {
    console.log("🧪 TEST API: Testing stats calculation...")

    // Buscar todos os registros
    const allRegistrations = await getRegistrations()

    // Calcular estatísticas
    const stats = {
      total: allRegistrations.length,
      pending: allRegistrations.filter((r) => r.status === "pending").length,
      approved: allRegistrations.filter((r) => r.status === "approved").length,
      rejected: allRegistrations.filter((r) => r.status === "rejected").length,
    }

    // Dados de debug
    const debugData = {
      timestamp: new Date().toISOString(),
      registrationsFound: allRegistrations.length,
      calculatedStats: stats,
      sampleRegistrations: allRegistrations.slice(0, 5).map((r) => ({
        id: r.id,
        name: r.name,
        status: r.status,
        created_at: r.created_at,
      })),
      statusBreakdown: {
        pending: allRegistrations.filter((r) => r.status === "pending").map((r) => ({ id: r.id, name: r.name })),
        approved: allRegistrations.filter((r) => r.status === "approved").map((r) => ({ id: r.id, name: r.name })),
        rejected: allRegistrations.filter((r) => r.status === "rejected").map((r) => ({ id: r.id, name: r.name })),
      },
    }

    console.log("🧪 TEST API: Results:", debugData)

    return NextResponse.json({
      success: true,
      message: "Stats calculation test completed",
      data: debugData,
    })
  } catch (error) {
    console.error("🧪 TEST API: Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
