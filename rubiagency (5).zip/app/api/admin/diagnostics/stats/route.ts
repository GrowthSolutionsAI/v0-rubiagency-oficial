import { NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

export async function GET() {
  const startTime = Date.now()

  try {
    const url = process.env.DATABASE_URL || process.env.POSTGRES_URL || process.env.NEON_DATABASE_URL

    if (!url) {
      return NextResponse.json({
        success: false,
        message: "❌ URL do banco de dados não configurada",
        error: "DATABASE_URL não encontrada",
        duration: Date.now() - startTime,
      })
    }

    const sql = neon(url)

    // Verificar se a tabela user_registrations existe
    const tableExists = await sql`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'user_registrations'
      )
    `

    if (!tableExists[0].exists) {
      return NextResponse.json({
        success: false,
        message: "❌ Tabela user_registrations não existe",
        error: "Execute o script 001-create-tables.sql",
        duration: Date.now() - startTime,
      })
    }

    // Buscar estatísticas básicas
    const stats = await sql`
      SELECT 
        COUNT(*)::int as total,
        COUNT(CASE WHEN status = 'pending' THEN 1 END)::int as pending,
        COUNT(CASE WHEN status = 'approved' THEN 1 END)::int as approved,
        COUNT(CASE WHEN status = 'rejected' THEN 1 END)::int as rejected
      FROM user_registrations
    `

    // Buscar registros recentes
    const recentRegistrations = await sql`
      SELECT 
        id, 
        name, 
        email, 
        status, 
        created_at,
        partner_code
      FROM user_registrations 
      ORDER BY created_at DESC 
      LIMIT 5
    `

    // Estatísticas por período
    const periodStats = await sql`
      SELECT 
        DATE_TRUNC('day', created_at) as date,
        COUNT(*) as count
      FROM user_registrations 
      WHERE created_at >= NOW() - INTERVAL '7 days'
      GROUP BY DATE_TRUNC('day', created_at)
      ORDER BY date DESC
    `

    // Verificar outras tabelas
    const otherTables = await sql`
      SELECT 
        'system_settings' as table_name,
        (SELECT COUNT(*) FROM system_settings) as count
      UNION ALL
      SELECT 
        'admin_users' as table_name,
        (SELECT COUNT(*) FROM admin_users) as count
      UNION ALL
      SELECT 
        'partners' as table_name,
        (SELECT COUNT(*) FROM partners) as count
    `

    const duration = Date.now() - startTime

    return NextResponse.json({
      success: true,
      message: "✅ Estatísticas obtidas com sucesso",
      data: {
        registrationStats: stats[0],
        recentRegistrations,
        periodStats,
        otherTables,
        summary: {
          totalRegistrations: stats[0].total,
          hasData: stats[0].total > 0,
          lastRegistration: recentRegistrations[0]?.created_at || null,
        },
      },
      duration,
    })
  } catch (error) {
    return NextResponse.json({
      success: false,
      message: "❌ Erro ao obter estatísticas",
      error: error.message,
      duration: Date.now() - startTime,
    })
  }
}
