import { NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

export async function GET() {
  const startTime = Date.now()

  try {
    const url = process.env.DATABASE_URL || process.env.POSTGRES_URL || process.env.NEON_DATABASE_URL

    if (!url) {
      return NextResponse.json({
        success: false,
        message: "❌ URL do banco de dados não configurada",
        error: "DATABASE_URL não encontrada",
        duration: Date.now() - startTime,
      })
    }

    const sql = neon(url)

    // Verificar se as tabelas existem
    const tables = await sql`
      SELECT 
        table_name, 
        table_type,
        (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = t.table_name) as column_count
      FROM information_schema.tables t
      WHERE table_schema = 'public' 
      AND table_type = 'BASE TABLE'
      ORDER BY table_name
    `

    const expectedTables = ["user_registrations", "user_files", "system_settings", "admin_users", "partners"]
    const existingTables = tables.map((t) => t.table_name)
    const missingTables = expectedTables.filter((t) => !existingTables.includes(t))

    // Verificar estrutura específica da tabela user_registrations
    let userRegistrationsStructure = []
    if (existingTables.includes("user_registrations")) {
      userRegistrationsStructure = await sql`
        SELECT 
          column_name, 
          data_type, 
          is_nullable, 
          column_default,
          character_maximum_length
        FROM information_schema.columns 
        WHERE table_name = 'user_registrations'
        ORDER BY ordinal_position
      `
    }

    // Verificar índices
    const indexes = await sql`
      SELECT 
        indexname,
        tablename,
        indexdef
      FROM pg_indexes 
      WHERE schemaname = 'public'
      ORDER BY tablename, indexname
    `

    // Verificar constraints
    const constraints = await sql`
      SELECT 
        constraint_name,
        table_name,
        constraint_type
      FROM information_schema.table_constraints
      WHERE table_schema = 'public'
      ORDER BY table_name, constraint_name
    `

    const duration = Date.now() - startTime

    return NextResponse.json({
      success: missingTables.length === 0,
      message:
        missingTables.length === 0
          ? "✅ Estrutura do banco validada com sucesso"
          : `❌ Tabelas faltando: ${missingTables.join(", ")}`,
      data: {
        tables: tables.map((t) => ({
          name: t.table_name,
          type: t.table_type,
          columns: Number.parseInt(t.column_count),
          status: expectedTables.includes(t.table_name) ? "expected" : "extra",
        })),
        expectedTables,
        existingTables,
        missingTables,
        userRegistrationsStructure,
        indexes: indexes.map((i) => ({
          name: i.indexname,
          table: i.tablename,
          definition: i.indexdef,
        })),
        constraints: constraints.map((c) => ({
          name: c.constraint_name,
          table: c.table_name,
          type: c.constraint_type,
        })),
        recommendations:
          missingTables.length > 0
            ? [
                "Execute o script: scripts/001-create-tables.sql",
                "Execute o script: scripts/002-insert-default-settings.sql",
                "Execute o script: scripts/003-create-admin-user.sql",
                "Execute o script: scripts/010-create-partners-system.sql",
              ]
            : ["✅ Estrutura do banco está completa"],
      },
      duration,
    })
  } catch (error) {
    return NextResponse.json({
      success: false,
      message: "❌ Erro ao verificar estrutura do banco",
      error: error.message,
      duration: Date.now() - startTime,
    })
  }
}
