import { NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

export async function GET() {
  const startTime = Date.now()

  try {
    // Tentar diferentes URLs de conexão
    const urls = [
      process.env.DATABASE_URL,
      process.env.POSTGRES_URL,
      process.env.NEON_DATABASE_URL,
      process.env.POSTGRES_PRISMA_URL,
    ].filter(Boolean)

    if (urls.length === 0) {
      return NextResponse.json({
        success: false,
        message: "❌ Nenhuma URL de banco de dados configurada",
        error: "DATABASE_URL não encontrada",
        duration: Date.now() - startTime,
      })
    }

    const results = []

    for (const url of urls) {
      try {
        console.log(`🔄 Testando conexão com: ${url.substring(0, 30)}...`)

        const sql = neon(url)
        const result = await sql`
          SELECT 
            version() as postgres_version,
            current_database() as database_name,
            current_user as user_name,
            NOW() as current_time,
            pg_database_size(current_database()) as database_size
        `

        results.push({
          url: url.substring(0, 50) + "...",
          status: "success",
          data: result[0],
          message: "✅ Conexão estabelecida com sucesso",
        })

        console.log(`✅ Conexão bem-sucedida com: ${url.substring(0, 30)}...`)
        break // Se uma conexão funcionar, não precisa testar as outras
      } catch (error) {
        console.error(`❌ Erro na conexão com ${url.substring(0, 30)}...:`, error)
        results.push({
          url: url.substring(0, 50) + "...",
          status: "error",
          error: error.message,
          message: `❌ Falha na conexão: ${error.message}`,
        })
      }
    }

    const hasSuccessfulConnection = results.some((r) => r.status === "success")
    const duration = Date.now() - startTime

    return NextResponse.json({
      success: hasSuccessfulConnection,
      message: hasSuccessfulConnection
        ? "✅ Conexão com banco de dados estabelecida"
        : "❌ Falha em todas as tentativas de conexão",
      data: {
        results,
        totalUrls: urls.length,
        successfulConnections: results.filter((r) => r.status === "success").length,
      },
      duration,
    })
  } catch (error) {
    return NextResponse.json({
      success: false,
      message: "❌ Erro crítico no teste de conexão",
      error: error.message,
      duration: Date.now() - startTime,
    })
  }
}
