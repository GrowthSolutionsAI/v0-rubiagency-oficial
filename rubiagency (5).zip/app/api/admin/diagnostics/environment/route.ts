import { NextResponse } from "next/server"

export async function GET() {
  try {
    const startTime = Date.now()

    // Verificar variáveis de ambiente
    const envVars = {
      DATABASE_URL: process.env.DATABASE_URL,
      POSTGRES_URL: process.env.POSTGRES_URL,
      NEON_DATABASE_URL: process.env.NEON_DATABASE_URL,
      POSTGRES_PRISMA_URL: process.env.POSTGRES_PRISMA_URL,
      DATABASE_URL_UNPOOLED: process.env.DATABASE_URL_UNPOOLED,
      POSTGRES_URL_NON_POOLING: process.env.POSTGRES_URL_NON_POOLING,
      NODE_ENV: process.env.NODE_ENV,
    }

    // Encontrar a URL principal
    const mainUrl =
      envVars.DATABASE_URL || envVars.POSTGRES_URL || envVars.NEON_DATABASE_URL || envVars.POSTGRES_PRISMA_URL

    let databaseInfo = null
    if (mainUrl) {
      try {
        const url = new URL(mainUrl)
        databaseInfo = {
          url: mainUrl,
          host: url.hostname,
          database: url.pathname.substring(1),
          user: url.username,
          ssl: url.searchParams.get("sslmode") !== "disable",
          pooled: !mainUrl.includes("pooler=false"),
        }
      } catch (urlError) {
        console.error("Error parsing database URL:", urlError)
      }
    }

    const availableUrls = Object.entries(envVars)
      .filter(([key, value]) => value && key.includes("URL"))
      .map(([key, value]) => ({ key, value: value.substring(0, 50) + "..." }))

    const duration = Date.now() - startTime

    if (!mainUrl) {
      return NextResponse.json({
        success: false,
        message: "❌ Nenhuma URL de banco de dados encontrada nas variáveis de ambiente",
        error: "DATABASE_URL não configurada",
        data: {
          envVars: Object.fromEntries(
            Object.entries(envVars).map(([key, value]) => [key, value ? "✅ Configurada" : "❌ Não configurada"]),
          ),
          availableUrls,
          databaseInfo,
        },
        duration,
      })
    }

    return NextResponse.json({
      success: true,
      message: "✅ Variáveis de ambiente verificadas com sucesso",
      data: {
        envVars: Object.fromEntries(
          Object.entries(envVars).map(([key, value]) => [key, value ? "✅ Configurada" : "❌ Não configurada"]),
        ),
        availableUrls,
        databaseInfo,
        mainUrl: mainUrl.substring(0, 50) + "...",
      },
      duration,
    })
  } catch (error) {
    return NextResponse.json({
      success: false,
      message: "❌ Erro ao verificar variáveis de ambiente",
      error: error.message,
      duration: Date.now(),
    })
  }
}
