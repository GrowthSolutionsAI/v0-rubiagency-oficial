import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Set maxDuration for this API route
export const maxDuration = 30

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const offset = (page - 1) * limit

    const { data: partners, error } = await supabase
      .from("partners")
      .select("*")
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1)

    if (error) {
      console.error("Error fetching partners:", error)
      return NextResponse.json({ error: "Erro ao buscar parceiros" }, { status: 500 })
    }

    // Get total count for pagination
    const { count, error: countError } = await supabase.from("partners").select("*", { count: "exact", head: true })

    if (countError) {
      console.error("Error fetching count:", countError)
      return NextResponse.json({ error: "Erro ao contar parceiros" }, { status: 500 })
    }

    return NextResponse.json(
      {
        partners: partners || [],
        pagination: {
          page,
          limit,
          total: count || 0,
          totalPages: Math.ceil((count || 0) / limit),
        },
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("Partners API error:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, email, phone, company, description, status } = body

    // Validate required fields
    if (!name || !email) {
      return NextResponse.json({ error: "Nome e email são obrigatórios" }, { status: 400 })
    }

    // Insert partner
    const { data, error } = await supabase
      .from("partners")
      .insert([
        {
          name,
          email,
          phone: phone || null,
          company: company || null,
          description: description || null,
          status: status || "active",
          created_at: new Date().toISOString(),
        },
      ])
      .select()

    if (error) {
      console.error("Database error:", error)
      return NextResponse.json({ error: "Erro ao criar parceiro" }, { status: 500 })
    }

    return NextResponse.json(
      {
        message: "Parceiro criado com sucesso!",
        data: data[0],
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Create partner error:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
