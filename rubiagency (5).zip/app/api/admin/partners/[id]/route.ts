import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const { id } = params

    // Buscar parceiro no banco
    const { data: partner, error } = await supabase.from("partners").select("*").eq("id", id).single()

    if (error && error.code !== "PGRST116") {
      console.error("❌ Erro ao buscar parceiro:", error)
      return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
    }

    // Se não encontrou no banco, retornar dados demo
    if (!partner) {
      const demoPartner = {
        id: Number.parseInt(id),
        name: `Parceiro Demo ${id}`,
        email: `parceiro${id}@demo.com`,
        phone: `(11) 9${id.padStart(4, "0")}-${id.padStart(4, "0")}`,
        commission_rate: 10,
        status: "active",
        referral_code: `DEMO${id.padStart(3, "0")}`,
        total_referrals: Math.floor(Math.random() * 50),
        total_commission: Math.floor(Math.random() * 5000),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }

      return NextResponse.json(demoPartner)
    }

    // Buscar estatísticas do parceiro
    const { data: stats } = await supabase.from("registrations").select("id, status, created_at").eq("partner_id", id)

    const totalReferrals = stats?.length || 0
    const approvedReferrals = stats?.filter((r) => r.status === "approved").length || 0
    const totalCommission = approvedReferrals * (partner.commission_rate || 10)

    const partnerWithStats = {
      ...partner,
      total_referrals: totalReferrals,
      approved_referrals: approvedReferrals,
      total_commission: totalCommission,
      referral_link: `${process.env.NEXT_PUBLIC_APP_URL}/?ref=${partner.referral_code}`,
    }

    return NextResponse.json(partnerWithStats)
  } catch (error) {
    console.error("❌ Erro na API do parceiro:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const { id } = params
    const body = await request.json()

    const { data: partner, error } = await supabase
      .from("partners")
      .update({
        name: body.name,
        email: body.email,
        phone: body.phone,
        commission_rate: body.commission_rate,
        status: body.status,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()
      .single()

    if (error) {
      console.error("❌ Erro ao atualizar parceiro:", error)
      return NextResponse.json({ error: "Erro ao atualizar parceiro" }, { status: 500 })
    }

    return NextResponse.json(partner)
  } catch (error) {
    console.error("❌ Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const { id } = params

    const { error } = await supabase.from("partners").delete().eq("id", id)

    if (error) {
      console.error("❌ Erro ao deletar parceiro:", error)
      return NextResponse.json({ error: "Erro ao deletar parceiro" }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("❌ Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
