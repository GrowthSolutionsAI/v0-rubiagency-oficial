import { NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export async function GET() {
  try {
    // Get partners stats
    const partnersStats = await sql`
      SELECT 
        COUNT(*) as total_partners,
        COUNT(*) FILTER (WHERE is_active = true) as active_partners
      FROM partners
    `

    // Get referrals stats
    const referralsStats = await sql`
      SELECT 
        COUNT(*) as total_referrals,
        SUM(CASE WHEN p.commission_rate IS NOT NULL THEN p.commission_rate ELSE 0 END) as total_commissions
      FROM registrations r
      LEFT JOIN partners p ON r.partner_id = p.id
      WHERE r.partner_id IS NOT NULL
    `

    const stats = {
      totalPartners: Number.parseInt(partnersStats[0]?.total_partners || "0"),
      activePartners: Number.parseInt(partnersStats[0]?.active_partners || "0"),
      totalReferrals: Number.parseInt(referralsStats[0]?.total_referrals || "0"),
      totalCommissions: Number.parseFloat(referralsStats[0]?.total_commissions || "0"),
    }

    return NextResponse.json(stats)
  } catch (error) {
    console.error("Error fetching partner stats:", error)
    return NextResponse.json({ error: "Failed to fetch partner stats" }, { status: 500 })
  }
}
