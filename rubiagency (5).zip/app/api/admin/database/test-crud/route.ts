import { NextResponse } from "next/server"
import { sql } from "@/lib/neon-config"

export async function GET() {
  try {
    const startTime = Date.now()
    const testResults = {
      create: false,
      read: false,
      update: false,
      delete: false,
    }

    // Teste CREATE
    try {
      await sql`
        INSERT INTO user_registrations (
          name, email, phone, age, height, weight, city, state, 
          experience, instagram, status, created_at, updated_at
        ) VALUES (
          'Teste CRUD', 'teste.crud@sistema.com', '(11) 99999-9999', 
          25, 170, 60, 'São Paulo', 'SP', 'Teste', '@teste_crud', 
          'pending', NOW(), NOW()
        )
      `
      testResults.create = true
    } catch (error) {
      console.error("Erro no CREATE:", error)
    }

    // Teste READ
    try {
      const readResult = await sql`
        SELECT id, name, email, instagram 
        FROM user_registrations 
        WHERE email = 'teste.crud@sistema.com'
      `
      if (readResult.length > 0) {
        testResults.read = true
      }
    } catch (error) {
      console.error("Erro no READ:", error)
    }

    // Teste UPDATE
    try {
      await sql`
        UPDATE user_registrations 
        SET name = 'Teste CRUD Atualizado', updated_at = NOW()
        WHERE email = 'teste.crud@sistema.com'
      `
      testResults.update = true
    } catch (error) {
      console.error("Erro no UPDATE:", error)
    }

    // Teste DELETE
    try {
      await sql`
        DELETE FROM user_registrations 
        WHERE email = 'teste.crud@sistema.com'
      `
      testResults.delete = true
    } catch (error) {
      console.error("Erro no DELETE:", error)
    }

    const duration = Date.now() - startTime
    const allPassed = Object.values(testResults).every((result) => result)

    return NextResponse.json({
      success: allPassed,
      message: allPassed ? "Todas as operações CRUD funcionando" : "Algumas operações CRUD falharam",
      duration,
      data: testResults,
    })
  } catch (error) {
    console.error("Erro no teste CRUD:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Falha no teste CRUD",
        error: error.message,
      },
      { status: 500 },
    )
  }
}
