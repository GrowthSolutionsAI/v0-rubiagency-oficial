import { NextResponse } from "next/server"
import { sql } from "@/lib/neon-config"

export async function GET() {
  try {
    // Verificar tabelas
    const tables = await sql`
      SELECT 
        t.table_name,
        (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = t.table_name) as column_count,
        COALESCE(s.n_tup_ins, 0) as rows
      FROM information_schema.tables t
      LEFT JOIN pg_stat_user_tables s ON s.relname = t.table_name
      WHERE t.table_schema = 'public' 
      AND t.table_type = 'BASE TABLE'
      ORDER BY t.table_name
    `

    // Verificar índices
    const indexes = await sql`
      SELECT 
        indexname as name,
        tablename,
        indexdef
      FROM pg_indexes 
      WHERE schemaname = 'public'
      ORDER BY tablename, indexname
    `

    // Verificar constraints
    const constraints = await sql`
      SELECT 
        constraint_name,
        table_name,
        constraint_type
      FROM information_schema.table_constraints
      WHERE table_schema = 'public'
      ORDER BY table_name, constraint_name
    `

    // Verificar se campo Instagram existe
    const instagramField = await sql`
      SELECT column_name
      FROM information_schema.columns 
      WHERE table_name = 'user_registrations' 
      AND column_name = 'instagram'
    `

    const hasInstagram = instagramField.length > 0

    return NextResponse.json({
      success: true,
      message: `Integridade validada: ${tables.length} tabelas, ${indexes.length} índices, ${constraints.length} constraints`,
      data: {
        tables: tables.map((t) => ({
          name: t.table_name,
          columns: t.column_count,
          rows: t.rows,
        })),
        indexes: indexes.map((i) => ({
          name: i.name,
          table: i.tablename,
        })),
        constraints: constraints.length,
        hasInstagramField: hasInstagram,
      },
    })
  } catch (error) {
    console.error("Erro no teste de integridade:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Falha no teste de integridade",
        error: error.message,
      },
      { status: 500 },
    )
  }
}
