import { NextResponse } from "next/server"
import { sql } from "@/lib/neon-config"

export async function GET() {
  try {
    const performanceData = {
      simpleQuery: 0,
      complexQuery: 0,
      insertQuery: 0,
      rating: "good",
    }

    // Teste 1: Query simples
    const start1 = Date.now()
    await sql`SELECT 1 as test`
    performanceData.simpleQuery = Date.now() - start1

    // Teste 2: Query complexa
    const start2 = Date.now()
    await sql`
      SELECT 
        COUNT(*) as total_registrations,
        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
        COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved,
        AVG(age) as avg_age
      FROM user_registrations
    `
    performanceData.complexQuery = Date.now() - start2

    // Teste 3: Inserção
    const start3 = Date.now()
    await sql`
      INSERT INTO user_registrations (
        name, email, phone, age, height, weight, city, state, 
        experience, instagram, status, created_at, updated_at
      ) VALUES (
        'Performance Test', 'perf.test@sistema.com', '(11) 99999-9999', 
        25, 170, 60, 'São Paulo', 'SP', 'Teste', '@perf_test', 
        'pending', NOW(), NOW()
      )
    `
    performanceData.insertQuery = Date.now() - start3

    // Limpar teste
    await sql`DELETE FROM user_registrations WHERE email = 'perf.test@sistema.com'`

    // Avaliar performance
    const avgTime = (performanceData.simpleQuery + performanceData.complexQuery + performanceData.insertQuery) / 3

    if (avgTime < 100) {
      performanceData.rating = "excellent"
    } else if (avgTime < 500) {
      performanceData.rating = "good"
    } else {
      performanceData.rating = "slow"
    }

    return NextResponse.json({
      success: true,
      message: `Performance ${performanceData.rating === "excellent" ? "excelente" : performanceData.rating === "good" ? "boa" : "lenta"}`,
      data: performanceData,
    })
  } catch (error) {
    console.error("Erro no teste de performance:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Falha no teste de performance",
        error: error.message,
      },
      { status: 500 },
    )
  }
}
