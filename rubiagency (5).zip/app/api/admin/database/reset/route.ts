import { NextResponse } from "next/server"
import { sql } from "@/lib/neon-config"

export async function POST() {
  try {
    const startTime = Date.now()

    // Contar registros antes da limpeza
    const beforeCounts = await sql`
      SELECT 
        (SELECT COUNT(*) FROM user_registrations) as registrations,
        (SELECT COUNT(*) FROM user_files) as files
    `

    // Executar limpeza
    await sql`DELETE FROM user_files`
    await sql`DELETE FROM user_registrations`
    await sql`DELETE FROM system_settings`

    // Resetar sequências
    await sql`ALTER SEQUENCE user_registrations_id_seq RESTART WITH 1`
    await sql`ALTER SEQUENCE user_files_id_seq RESTART WITH 1`

    // Inserir configurações padrão
    await sql`
      INSERT INTO system_settings (setting_key, setting_value, description, updated_at) VALUES
      ('welcome_message', '🌟 Obrigada por se cadastrar na Rubi Agency! Recebemos sua candidatura e nossa equipe irá analisá-la cuidadosamente. Entraremos em contato em até 48 horas através do seu Instagram ou email.', 'Mensagem exibida após o cadastro', NOW()),
      ('site_title', 'Rubi Agency - Agência de Modelos', 'Título do site', NOW()),
      ('contact_email', 'contato@rubiagency.com', 'Email de contato principal', NOW()),
      ('registration_enabled', 'true', 'Se o cadastro está habilitado', NOW())
      ON CONFLICT (setting_key) DO UPDATE SET 
        setting_value = EXCLUDED.setting_value,
        updated_at = NOW()
    `

    // Verificar resultado
    const afterCounts = await sql`
      SELECT 
        (SELECT COUNT(*) FROM user_registrations) as registrations,
        (SELECT COUNT(*) FROM user_files) as files,
        (SELECT COUNT(*) FROM system_settings) as settings
    `

    const duration = Date.now() - startTime

    return NextResponse.json({
      success: true,
      message: "Reset do banco executado com sucesso",
      duration,
      data: {
        deletedRegistrations: beforeCounts[0].registrations,
        deletedFiles: beforeCounts[0].files,
        settingsCount: afterCounts[0].settings,
      },
    })
  } catch (error) {
    console.error("Erro no reset do banco:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Falha no reset do banco",
        error: error.message,
      },
      { status: 500 },
    )
  }
}
