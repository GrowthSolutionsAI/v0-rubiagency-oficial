import { NextResponse } from "next/server"
import { sql } from "@/lib/neon-config"

export async function GET() {
  try {
    const startTime = Date.now()

    const result = await sql`
      SELECT 
        version() as postgres_version,
        current_database() as database_name,
        current_user as user_name,
        NOW() as current_time
    `

    const duration = Date.now() - startTime

    return NextResponse.json({
      success: true,
      message: "Conexão estabelecida com sucesso",
      duration,
      data: {
        database: result[0].database_name,
        user: result[0].user_name,
        version: result[0].postgres_version.split(" ")[0],
        timestamp: result[0].current_time,
      },
    })
  } catch (error) {
    console.error("Erro na conexão:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Falha na conexão com o banco",
        error: error.message,
      },
      { status: 500 },
    )
  }
}
