import { type NextRequest, NextResponse } from "next/server"
import { updateRegistrationStatus, getRegistrationById } from "@/lib/database"
import { sendApprovalEmail, sendRejectionEmail } from "@/lib/email"

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params
    const { status } = await request.json()

    if (!id || !status) {
      return NextResponse.json({ success: false, message: "ID e status são obrigatórios" }, { status: 400 })
    }

    if (!["approved", "rejected", "pending"].includes(status)) {
      return NextResponse.json({ success: false, message: "Status inválido" }, { status: 400 })
    }

    // Get registration details
    const registration = await getRegistrationById(id)
    if (!registration) {
      return NextResponse.json({ success: false, message: "Registro não encontrado" }, { status: 404 })
    }

    // Update status
    const updated = await updateRegistrationStatus(id, status)
    if (!updated) {
      return NextResponse.json({ success: false, message: "Erro ao atualizar status" }, { status: 500 })
    }

    // Send email notification
    let emailSent = false
    try {
      if (status === "approved") {
        emailSent = await sendApprovalEmail(registration.email, registration.name)
      } else if (status === "rejected") {
        emailSent = await sendRejectionEmail(registration.email, registration.name)
      }
    } catch (emailError) {
      console.error("Email sending error:", emailError)
      // Don't fail the request if email fails
    }

    console.log(`✅ Registration ${id} status updated to ${status}, email sent: ${emailSent}`)

    return NextResponse.json({
      success: true,
      message: `Status atualizado para ${status}${emailSent ? " e email enviado" : ""}`,
      emailSent,
    })
  } catch (error) {
    console.error("Status update error:", error)
    return NextResponse.json({ success: false, message: "Erro interno do servidor" }, { status: 500 })
  }
}
