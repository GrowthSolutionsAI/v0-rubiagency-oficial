import { NextResponse } from "next/server"
import { getRegistrationById, updateRegistrationStatus } from "@/lib/database"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    console.log("🔍 Admin API: Getting registration by ID:", id)

    const registration = await getRegistrationById(id)

    if (!registration) {
      console.log("❌ Registration not found:", id)
      return NextResponse.json(
        {
          success: false,
          error: "Registration not found",
        },
        { status: 404 },
      )
    }

    console.log("✅ Registration found:", {
      id: registration.id,
      name: registration.name,
      status: registration.status,
    })

    return NextResponse.json({
      success: true,
      data: registration,
    })
  } catch (error) {
    console.error("❌ Admin API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Internal server error",
      },
      { status: 500 },
    )
  }
}

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const body = await request.json()
    console.log("🔄 Admin API: Updating registration:", { id, body })

    const success = await updateRegistrationStatus(id, body.status, body.notes)

    if (!success) {
      return NextResponse.json(
        {
          success: false,
          error: "Failed to update registration",
        },
        { status: 500 },
      )
    }

    console.log("✅ Registration updated successfully")
    return NextResponse.json({
      success: true,
      message: "Registration updated successfully",
    })
  } catch (error) {
    console.error("❌ Admin API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Internal server error",
      },
      { status: 500 },
    )
  }
}
