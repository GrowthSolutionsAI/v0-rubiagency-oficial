import { type NextRequest, NextResponse } from "next/server"
import { updateRegistrationStatus, createRegistration, getUserRegistrations } from "@/lib/database"
import { isSupabaseConfigured } from "@/lib/supabase"

// Set maxDuration for this API route
export const maxDuration = 30

export async function GET(request: NextRequest) {
  try {
    console.log("📋 API: Fetching registrations...")

    // Verificar se Supabase está configurado
    if (!isSupabaseConfigured()) {
      console.warn("⚠️ Supabase not configured")
      return NextResponse.json(
        {
          success: false,
          message: "Database not configured",
          registrations: [],
        },
        { status: 503 },
      )
    }

    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status") || undefined

    // Buscar registros
    const registrations = await getUserRegistrations(status)

    console.log(`✅ API: Returning ${registrations.length} registrations`)

    return NextResponse.json({
      success: true,
      data: registrations,
      count: registrations.length,
    })
  } catch (error) {
    console.error("❌ API Error fetching registrations:", error)

    return NextResponse.json(
      {
        success: false,
        message: error instanceof Error ? error.message : "Unknown error",
        registrations: [],
      },
      { status: 500 },
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    console.log("🔄 API: Updating registration...")

    if (!isSupabaseConfigured()) {
      return NextResponse.json({ error: "Database not configured" }, { status: 500 })
    }

    const body = await request.json()
    const { id, status, notes } = body

    if (!id || !status) {
      return NextResponse.json({ error: "ID e status são obrigatórios" }, { status: 400 })
    }

    const success = await updateRegistrationStatus(id, status, notes)

    if (!success) {
      return NextResponse.json({ error: "Erro ao atualizar registro" }, { status: 500 })
    }

    console.log("✅ API: Registration updated successfully")

    return NextResponse.json({
      success: true,
      message: "Registration updated successfully",
    })
  } catch (error) {
    console.error("❌ Update registration error:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    console.log("📝 API: Creating registration...")

    if (!isSupabaseConfigured()) {
      return NextResponse.json({ error: "Database not configured" }, { status: 500 })
    }

    const body = await request.json()
    const { name, email, phone, message, partner_id, age } = body

    // Validate required fields
    if (!name || !email || !message) {
      return NextResponse.json({ error: "Nome, email e mensagem são obrigatórios" }, { status: 400 })
    }

    // Create registration
    const registration = await createRegistration({
      name,
      email,
      phone: phone || null,
      instagram: null,
      age: age || 18,
      subject: null,
      experience: null,
      message,
      status: "pending",
      partner_id: partner_id || null,
      partner_code: null,
      partner_name: null,
      approved_at: null,
      approved_by: null,
      notes: null,
    })

    console.log("✅ API: Registration created successfully")

    return NextResponse.json(
      {
        success: true,
        message: "Registro criado com sucesso!",
        data: registration,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("❌ Create registration error:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
