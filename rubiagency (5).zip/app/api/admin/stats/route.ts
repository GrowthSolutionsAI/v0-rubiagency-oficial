import { type NextRequest, NextResponse } from "next/server"
import { getRegistrationStats, getPartners, getContactRegistrations } from "@/lib/database"

export async function GET(request: NextRequest) {
  try {
    // Buscar estatísticas em paralelo
    const [registrationStats, partners, contacts] = await Promise.all([
      getRegistrationStats(),
      getPartners(),
      getContactRegistrations(),
    ])

    const stats = {
      registrations: registrationStats,
      partners: {
        total: partners.length,
        active: partners.filter((p) => p.is_active).length,
        inactive: partners.filter((p) => !p.is_active).length,
      },
      contacts: {
        total: contacts.length,
        new: contacts.filter((c) => c.status === "new").length,
        contacted: contacts.filter((c) => c.status === "contacted").length,
        converted: contacts.filter((c) => c.status === "converted").length,
      },
    }

    return NextResponse.json({
      success: true,
      data: stats,
    })
  } catch (error) {
    console.error("Erro ao buscar estatísticas:", error)

    return NextResponse.json(
      {
        success: false,
        error: "Erro ao buscar estatísticas",
        data: {
          registrations: {
            total: 0,
            pending: 0,
            approved: 0,
            rejected: 0,
            thisMonth: 0,
            lastMonth: 0,
            growthRate: 0,
          },
          partners: {
            total: 0,
            active: 0,
            inactive: 0,
          },
          contacts: {
            total: 0,
            new: 0,
            contacted: 0,
            converted: 0,
          },
        },
      },
      { status: 500 },
    )
  }
}
