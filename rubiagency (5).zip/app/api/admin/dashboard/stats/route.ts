import { NextResponse } from "next/server"
import { getRegistrationStats, getRegistrations } from "@/lib/database"

export async function GET() {
  try {
    console.log("📊 API: Getting dashboard stats...")

    const [stats, registrations] = await Promise.all([getRegistrationStats(), getRegistrations()])

    console.log("📊 API: Stats fetched:", {
      stats,
      registrationsCount: registrations.length,
    })

    return NextResponse.json({
      success: true,
      data: {
        stats,
        registrations: registrations.slice(0, 10), // Últimos 10
        total: registrations.length,
      },
    })
  } catch (error) {
    console.error("❌ API: Error fetching dashboard stats:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Erro desconhecido",
      },
      { status: 500 },
    )
  }
}
