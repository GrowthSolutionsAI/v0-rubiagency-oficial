import { NextResponse } from "next/server"
import { cookies } from "next/headers"

export async function GET() {
  try {
    const cookieStore = await cookies()
    const authCookie = cookieStore.get("admin-auth")

    const authenticated = authCookie?.value === "authenticated"

    console.log("🔍 Auth check - Cookie present:", !!authCookie, "Value:", authCookie?.value)

    return NextResponse.json({
      authenticated,
      user: authenticated
        ? {
            email: "contato@rubiagency.com",
            name: "Administrador",
            role: "admin",
          }
        : null,
    })
  } catch (error) {
    console.error("Auth check error:", error)
    return NextResponse.json({ authenticated: false, user: null })
  }
}
