import { type NextRequest, NextResponse } from "next/server"
import { sendTestEmail } from "@/lib/email"

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json()

    if (!email) {
      return NextResponse.json({ success: false, message: "Email é obrigatório" }, { status: 400 })
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json({ success: false, message: "Formato de email inválido" }, { status: 400 })
    }

    console.log(`📧 Testing email to: ${email}`)

    const result = await sendTestEmail(email)

    return NextResponse.json(result)
  } catch (error) {
    console.error("Test email API error:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Erro interno do servidor",
        provider: "error",
      },
      { status: 500 },
    )
  }
}
