import { type NextRequest, NextResponse } from "next/server"
import { getEmailServiceStatus } from "@/lib/email"

export async function GET(request: NextRequest) {
  try {
    const status = await getEmailServiceStatus()

    return NextResponse.json({
      success: true,
      data: status,
    })
  } catch (error) {
    console.error("Erro ao verificar status do email:", error)

    return NextResponse.json(
      {
        success: false,
        error: "Erro ao verificar status do email",
        data: {
          configured: false,
          connected: false,
          message: "Erro interno",
        },
      },
      { status: 500 },
    )
  }
}
