import { type NextRequest, NextResponse } from "next/server"
import { createContactRegistration } from "@/lib/database"
import { sendContactNotification } from "@/lib/email"

export async function POST(request: NextRequest) {
  try {
    // Parse do corpo da requisição
    const body = await request.json()

    // Validação básica
    if (!body.name || !body.email || !body.message) {
      return NextResponse.json(
        {
          success: false,
          error: "Campos obrigatórios: name, email, message",
        },
        { status: 400 },
      )
    }

    // Validação de email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(body.email)) {
      return NextResponse.json(
        {
          success: false,
          error: "Email inválido",
        },
        { status: 400 },
      )
    }

    // Preparar dados para inserção
    const contactData = {
      name: body.name.trim(),
      email: body.email.trim().toLowerCase(),
      phone: body.phone?.trim() || null,
      instagram: body.instagram?.trim() || null,
      message: body.message.trim(),
      partner_code: body.partner_code?.trim() || null,
      status: "new" as const,
      attachments: body.attachments || [],
    }

    // Inserir no banco de dados
    const registration = await createContactRegistration(contactData)

    if (!registration) {
      return NextResponse.json(
        {
          success: false,
          error: "Erro ao salvar contato no banco de dados",
        },
        { status: 500 },
      )
    }

    // Tentar enviar notificação por email (não bloquear se falhar)
    try {
      await sendContactNotification({
        name: contactData.name,
        email: contactData.email,
        phone: contactData.phone || undefined,
        instagram: contactData.instagram || undefined,
        message: contactData.message,
        partner_code: contactData.partner_code || undefined,
      })
    } catch (emailError) {
      console.error("Erro ao enviar email de notificação:", emailError)
      // Não retornar erro, pois o contato foi salvo com sucesso
    }

    return NextResponse.json({
      success: true,
      message: "Contato recebido com sucesso!",
      data: {
        id: registration.id,
        name: registration.name,
        email: registration.email,
      },
    })
  } catch (error) {
    console.error("Erro na API de contato:", error)

    return NextResponse.json(
      {
        success: false,
        error: "Erro interno do servidor",
      },
      { status: 500 },
    )
  }
}

// Método OPTIONS para CORS
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  })
}
