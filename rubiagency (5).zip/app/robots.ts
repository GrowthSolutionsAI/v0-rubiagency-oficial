import type { MetadataRoute } from "next"

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/admin/", "/api/", "/private/", "/_next/", "/area-cliente/dashboard", "/*.json", "/*.xml"],
      },
      {
        userAgent: "Googlebot",
        allow: ["/", "/blog/", "/sobre", "/servicos", "/contato"],
        disallow: ["/admin/", "/api/", "/private/"],
      },
    ],
    sitemap: "https://rubiagency.com/sitemap.xml",
    host: "https://rubiagency.com",
  }
}
