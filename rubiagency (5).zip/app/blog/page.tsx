"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Calendar, Clock, User, Search, ArrowRight, TrendingUp, Star, BookOpen, Eye } from "lucide-react"
import { blogPosts } from "@/lib/blog-data"

export default function BlogPage() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("Todos")

  const categories = ["Todos", "Carreira", "Marketing", "Dicas", "Finanças", "Segurança", "Tendências"]

  const filteredPosts = blogPosts.filter((post) => {
    const matchesCategory = selectedCategory === "Todos" || post.category === selectedCategory
    const matchesSearch =
      post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))
    return matchesCategory && matchesSearch
  })

  const featuredPosts = blogPosts.filter((post) => post.featured).slice(0, 2)

  return (
    <div className="premium-gradient">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden section-padding">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(220,38,38,0.1),transparent_50%)]"></div>

        <div className="container mx-auto px-4 relative z-10 container-padding">
          <div className="text-center mb-16">
            <motion.div
              className="inline-flex items-center gap-3 mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="h-px w-12 bg-gradient-to-r from-transparent to-pink-500"></div>
              <span className="text-sm font-medium text-pink-400 tracking-wider uppercase">Blog Rubi Agency</span>
              <div className="h-px w-12 bg-gradient-to-l from-transparent to-pink-500"></div>
            </motion.div>

            <motion.h1
              className="text-5xl md:text-7xl font-bold text-white mb-8 text-headline"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              Conteúdo{" "}
              <span className="bg-gradient-to-r from-pink-400 to-red-400 bg-clip-text text-transparent">Exclusivo</span>
            </motion.h1>

            <motion.p
              className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed text-body"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              Dicas especializadas, estratégias comprovadas e insights exclusivos para criadoras que querem transformar
              sua paixão em um negócio próspero e sustentável.
            </motion.p>
          </div>

          {/* Search and Filters */}
          <motion.div
            ref={ref}
            className="glass-effect rounded-2xl p-8 premium-border premium-shadow"
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex flex-col lg:flex-row gap-6 items-center">
              <div className="relative flex-1 w-full">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="Buscar artigos, dicas, estratégias..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-12 glass-effect border-platinum focus:border-primary text-body text-white placeholder:text-gray-400 rounded-xl h-12"
                />
              </div>

              <div className="flex flex-wrap gap-2">
                {categories.map((category) => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(category)}
                    className={
                      selectedCategory === category ? "btn-primary rounded-full" : "btn-secondary rounded-full"
                    }
                  >
                    {category}
                  </Button>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Posts */}
      {featuredPosts.length > 0 && (
        <section className="py-20 section-padding">
          <div className="container mx-auto px-4 container-padding">
            <motion.h2
              className="text-3xl font-bold text-white mb-12 flex items-center gap-3 text-headline"
              initial={{ opacity: 0, x: -20 }}
              animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
              transition={{ duration: 0.6 }}
            >
              <Star className="h-8 w-8 text-pink-400" />
              Artigos em Destaque
            </motion.h2>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {featuredPosts.map((post, index) => (
                <motion.article
                  key={post.slug}
                  className="group glass-effect rounded-2xl overflow-hidden premium-border premium-shadow hover-lift"
                  initial={{ opacity: 0, y: 30 }}
                  animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <div className="relative h-64 overflow-hidden">
                    <Image
                      src={post.image || "/placeholder.svg"}
                      alt={post.title}
                      fill
                      className="object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                    <Badge className="absolute top-4 left-4 bg-pink-500/20 text-pink-300 border-pink-400/30">
                      {post.category}
                    </Badge>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-semibold text-white mb-2 line-clamp-2 group-hover:text-pink-300 transition-colors text-headline">
                        {post.title}
                      </h3>
                    </div>
                  </div>

                  <div className="p-6">
                    <p className="text-gray-300 mb-4 line-clamp-3 text-body">{post.excerpt}</p>

                    <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
                      <div className="flex items-center gap-4">
                        <span className="flex items-center gap-1">
                          <User className="h-4 w-4" />
                          {post.author}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          {new Date(post.date).toLocaleDateString("pt-BR")}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          {post.readTime}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex gap-2">
                        {post.tags.slice(0, 2).map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs border-white/20 text-gray-400">
                            #{tag}
                          </Badge>
                        ))}
                      </div>

                      <Button
                        asChild
                        variant="ghost"
                        className="text-pink-400 hover:text-pink-300 hover:bg-pink-500/10"
                      >
                        <Link href={`/blog/${post.slug}`} className="flex items-center gap-2">
                          Ler artigo
                          <ArrowRight className="h-4 w-4" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* All Posts Grid */}
      <section className="py-20 section-padding">
        <div className="container mx-auto px-4 container-padding">
          <motion.h2
            className="text-3xl font-bold text-white mb-12 flex items-center gap-3 text-headline"
            initial={{ opacity: 0, x: -20 }}
            animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
            transition={{ duration: 0.6 }}
          >
            <BookOpen className="h-8 w-8 text-pink-400" />
            Todos os Artigos
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post, index) => (
              <motion.article
                key={post.slug}
                className="group glass-effect rounded-2xl overflow-hidden premium-border premium-shadow hover-lift"
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <div className="relative h-48 overflow-hidden">
                  <Image
                    src={post.image || "/placeholder.svg"}
                    alt={post.title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <Badge className="absolute top-3 left-3 bg-pink-500/20 text-pink-300 border-pink-400/30 text-xs">
                    {post.category}
                  </Badge>
                </div>

                <div className="p-6">
                  <h3 className="text-lg font-semibold text-white mb-3 line-clamp-2 group-hover:text-pink-300 transition-colors text-headline">
                    {post.title}
                  </h3>

                  <p className="text-gray-300 text-sm mb-4 line-clamp-3 text-body">{post.excerpt}</p>

                  <div className="flex items-center justify-between text-xs text-gray-400 mb-4">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {new Date(post.date).toLocaleDateString("pt-BR")}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {post.readTime}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 text-xs text-gray-400">
                      <span className="flex items-center gap-1">
                        <Eye className="h-3 w-3" />
                        {post.views}
                      </span>
                      <span className="flex items-center gap-1">
                        <TrendingUp className="h-3 w-3" />
                        {post.likes}
                      </span>
                    </div>

                    <Button
                      asChild
                      variant="ghost"
                      size="sm"
                      className="text-pink-400 hover:text-pink-300 hover:bg-pink-500/10 text-xs"
                    >
                      <Link href={`/blog/${post.slug}`} className="flex items-center gap-1">
                        Ler
                        <ArrowRight className="h-3 w-3" />
                      </Link>
                    </Button>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>

          {filteredPosts.length === 0 && (
            <div className="text-center py-16">
              <div className="p-4 bg-gradient-to-br from-pink-500/20 to-red-500/20 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Search className="h-8 w-8 text-pink-400" />
              </div>
              <h3 className="text-2xl font-semibold text-white mb-2 text-headline">Nenhum artigo encontrado</h3>
              <p className="text-gray-400 text-body">Tente ajustar sua busca ou filtros.</p>
            </div>
          )}
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-20 section-padding">
        <div className="container mx-auto px-4 container-padding">
          <motion.div
            className="glass-effect rounded-2xl p-10 text-center premium-border premium-shadow"
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
            transition={{ duration: 0.6, delay: 0.8 }}
          >
            <h3 className="text-3xl font-bold text-white mb-4 text-headline">Receba Conteúdo Exclusivo</h3>
            <p className="text-gray-300 mb-8 max-w-2xl mx-auto text-body">
              Inscreva-se em nossa newsletter e receba dicas exclusivas, estratégias avançadas e novidades do mercado
              diretamente em seu email.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <Input
                placeholder="Seu melhor email"
                className="glass-effect border-platinum focus:border-primary text-white placeholder:text-gray-400 rounded-xl text-body"
              />
              <Button className="btn-primary">Inscrever-se</Button>
            </div>

            <p className="text-xs text-gray-400 mt-4 text-body">Sem spam. Cancele a qualquer momento.</p>
          </motion.div>
        </div>
      </section>
    </div>
  )
}
