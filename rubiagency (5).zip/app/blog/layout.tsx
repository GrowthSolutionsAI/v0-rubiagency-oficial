import type React from "react"
import type { Metadata } from "next"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export const metadata: Metadata = {
  title: "Blog | Rubi Agency - Dicas e Estratégias para Criadoras",
  description:
    "Conteúdo exclusivo para criadoras de conteúdo. Dicas, estratégias e insights para transformar sua paixão em um negócio próspero.",
}

export default function BlogLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <>
      <Navbar />
      <main>{children}</main>
      <Footer />
    </>
  )
}
