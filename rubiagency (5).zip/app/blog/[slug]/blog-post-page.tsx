"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, User, ArrowLeft, ArrowRight, Eye, TrendingUp, Share2 } from "lucide-react"
import type { BlogPost } from "@/lib/blog-data"

interface BlogPostPageProps {
  post: BlogPost
  relatedPosts: BlogPost[]
}

export default function BlogPostPage({ post, relatedPosts }: BlogPostPageProps) {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const formatContent = (content: string) => {
    return content.split("\n").map((paragraph, index) => {
      if (paragraph.startsWith("# ")) {
        return (
          <h1 key={index} className="text-4xl font-bold text-white mb-6 text-headline">
            {paragraph.replace("# ", "")}
          </h1>
        )
      }
      if (paragraph.startsWith("## ")) {
        return (
          <h2 key={index} className="text-2xl font-semibold text-white mb-4 mt-8 text-headline">
            {paragraph.replace("## ", "")}
          </h2>
        )
      }
      if (paragraph.startsWith("### ")) {
        return (
          <h3 key={index} className="text-xl font-semibold text-pink-300 mb-3 mt-6 text-headline">
            {paragraph.replace("### ", "")}
          </h3>
        )
      }
      if (paragraph.startsWith("> ")) {
        return (
          <blockquote key={index} className="border-l-4 border-pink-500 pl-6 py-4 my-6 bg-pink-500/10 rounded-r-lg">
            <p className="text-gray-300 italic text-body">{paragraph.replace("> ", "")}</p>
          </blockquote>
        )
      }
      if (paragraph.startsWith("- ")) {
        return (
          <li key={index} className="text-gray-300 mb-2 text-body">
            {paragraph.replace("- ", "")}
          </li>
        )
      }
      if (paragraph.trim() === "") {
        return <br key={index} />
      }
      return (
        <p key={index} className="text-gray-300 mb-4 leading-relaxed text-body">
          {paragraph}
        </p>
      )
    })
  }

  return (
    <div className="premium-gradient">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(220,38,38,0.1),transparent_50%)]"></div>

        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            className="max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Button asChild variant="ghost" className="text-pink-400 hover:text-pink-300 hover:bg-pink-500/10 mb-8">
              <Link href="/blog" className="flex items-center gap-2">
                <ArrowLeft className="h-4 w-4" />
                Voltar ao Blog
              </Link>
            </Button>

            <div className="mb-6">
              <Badge className="bg-pink-500/20 text-pink-300 border-pink-400/30 mb-4">{post.category}</Badge>
            </div>

            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 text-headline">{post.title}</h1>

            <p className="text-xl text-gray-300 mb-8 leading-relaxed text-body">{post.excerpt}</p>

            <div className="flex flex-wrap items-center gap-6 text-sm text-gray-400 mb-8">
              <span className="flex items-center gap-2">
                <User className="h-4 w-4" />
                {post.author}
              </span>
              <span className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                {new Date(post.date).toLocaleDateString("pt-BR")}
              </span>
              <span className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                {post.readTime}
              </span>
              <span className="flex items-center gap-2">
                <Eye className="h-4 w-4" />
                {post.views} visualizações
              </span>
              <span className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                {post.likes} curtidas
              </span>
            </div>

            <div className="flex gap-2 mb-8">
              {post.tags.map((tag) => (
                <Badge key={tag} variant="outline" className="border-white/20 text-gray-400">
                  #{tag}
                </Badge>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Image */}
      <section className="py-10">
        <div className="container mx-auto px-4">
          <motion.div
            className="max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="relative h-96 rounded-2xl overflow-hidden premium-shadow">
              <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Content */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <motion.article
            ref={ref}
            className="max-w-4xl mx-auto glass-effect rounded-2xl p-8 md:p-12 premium-border premium-shadow"
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
            transition={{ duration: 0.6 }}
          >
            <div className="prose prose-lg prose-invert max-w-none">{formatContent(post.content)}</div>

            <div className="flex items-center justify-between pt-8 mt-8 border-t border-white/10">
              <div className="flex gap-2">
                {post.tags.map((tag) => (
                  <Badge key={tag} variant="outline" className="border-white/20 text-gray-400">
                    #{tag}
                  </Badge>
                ))}
              </div>

              <Button variant="ghost" className="text-pink-400 hover:text-pink-300 hover:bg-pink-500/10">
                <Share2 className="h-4 w-4 mr-2" />
                Compartilhar
              </Button>
            </div>
          </motion.article>
        </div>
      </section>

      {/* Related Posts */}
      {relatedPosts.length > 0 && (
        <section className="py-20">
          <div className="container mx-auto px-4">
            <motion.h2
              className="text-3xl font-bold text-white mb-12 text-center text-headline"
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.6 }}
            >
              Artigos Relacionados
            </motion.h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {relatedPosts.map((relatedPost, index) => (
                <motion.article
                  key={relatedPost.slug}
                  className="group glass-effect rounded-2xl overflow-hidden premium-border premium-shadow hover-lift"
                  initial={{ opacity: 0, y: 30 }}
                  animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <div className="relative h-48 overflow-hidden">
                    <Image
                      src={relatedPost.image || "/placeholder.svg"}
                      alt={relatedPost.title}
                      fill
                      className="object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <Badge className="absolute top-3 left-3 bg-pink-500/20 text-pink-300 border-pink-400/30 text-xs">
                      {relatedPost.category}
                    </Badge>
                  </div>

                  <div className="p-6">
                    <h3 className="text-lg font-semibold text-white mb-3 line-clamp-2 group-hover:text-pink-300 transition-colors text-headline">
                      {relatedPost.title}
                    </h3>

                    <p className="text-gray-300 text-sm mb-4 line-clamp-3 text-body">{relatedPost.excerpt}</p>

                    <div className="flex items-center justify-between text-xs text-gray-400 mb-4">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {new Date(relatedPost.date).toLocaleDateString("pt-BR")}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {relatedPost.readTime}
                      </span>
                    </div>

                    <Button
                      asChild
                      variant="ghost"
                      size="sm"
                      className="text-pink-400 hover:text-pink-300 hover:bg-pink-500/10 text-xs w-full"
                    >
                      <Link href={`/blog/${relatedPost.slug}`} className="flex items-center justify-center gap-1">
                        Ler artigo
                        <ArrowRight className="h-3 w-3" />
                      </Link>
                    </Button>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  )
}
