"use server"

import { createRegistration } from "@/lib/database"
import { sendEmail } from "@/lib/email"
import { revalidatePath } from "next/cache"

export interface ContactFormData {
  name: string
  email: string
  phone?: string
  instagram?: string
  age: number
  subject?: string
  experience?: string
  message: string
  partnerCode?: string
}

export async function submitContactForm(formData: ContactFormData) {
  try {
    console.log("📝 Processing contact form submission for:", formData.name)

    // Validação de idade (18+)
    if (formData.age < 18) {
      return {
        success: false,
        message: "Você deve ter pelo menos 18 anos para se cadastrar.",
      }
    }

    // Validação de campos obrigatórios
    if (!formData.name || !formData.email || !formData.message) {
      return {
        success: false,
        message: "Por favor, preencha todos os campos obrigatórios.",
      }
    }

    // Criar registro no banco de dados
    const registration = await createRegistration({
      name: formData.name,
      email: formData.email,
      phone: formData.phone || null,
      instagram: formData.instagram || null,
      age: formData.age,
      subject: formData.subject || null,
      experience: formData.experience || null,
      message: formData.message,
      status: "pending",
      partner_id: null,
      partner_code: formData.partnerCode || null,
      partner_name: null,
      approved_at: null,
      approved_by: null,
      notes: null,
    })

    console.log(`✅ Registration created with ID: ${registration.id}`)

    // Enviar email de notificação para admin
    try {
      await sendEmail({
        to: process.env.ADMIN_EMAIL || "admin@rubiagency.com",
        subject: "Novo Cadastro - Rubi Agency",
        html: `
          <h2>Novo Cadastro Recebido</h2>
          <p><strong>Nome:</strong> ${formData.name}</p>
          <p><strong>Email:</strong> ${formData.email}</p>
          <p><strong>Telefone:</strong> ${formData.phone || "Não informado"}</p>
          <p><strong>Instagram:</strong> ${formData.instagram || "Não informado"}</p>
          <p><strong>Idade:</strong> ${formData.age} anos</p>
          <p><strong>Assunto:</strong> ${formData.subject || "Não informado"}</p>
          <p><strong>Experiência:</strong> ${formData.experience || "Não informado"}</p>
          <p><strong>Mensagem:</strong></p>
          <p>${formData.message}</p>
          ${formData.partnerCode ? `<p><strong>Código do Parceiro:</strong> ${formData.partnerCode}</p>` : ""}
          <p><strong>Data:</strong> ${new Date().toLocaleString("pt-BR")}</p>
          
          <hr>
          <p><a href="${process.env.NEXT_PUBLIC_APP_URL}/admin/registrations/details/${registration.id}">Ver detalhes no painel admin</a></p>
        `,
      })

      console.log("✅ Admin notification email sent")
    } catch (emailError) {
      console.error("⚠️ Failed to send admin notification email:", emailError)
    }

    // Enviar email de confirmação para o usuário
    try {
      await sendEmail({
        to: formData.email,
        subject: "Cadastro Recebido - Rubi Agency",
        html: `
          <h2>Olá ${formData.name}!</h2>
          <p>Recebemos seu cadastro na <strong>Rubi Agency</strong> e agradecemos seu interesse!</p>
          
          <p>Nosso time irá analisar suas informações e entraremos em contato em breve.</p>
          
          <p><strong>Resumo do seu cadastro:</strong></p>
          <ul>
            <li>Nome: ${formData.name}</li>
            <li>Email: ${formData.email}</li>
            <li>Idade: ${formData.age} anos</li>
            ${formData.instagram ? `<li>Instagram: ${formData.instagram}</li>` : ""}
          </ul>
          
          <p>Se você tiver alguma dúvida, pode responder este email ou entrar em contato conosco.</p>
          
          <p>Atenciosamente,<br>
          <strong>Equipe Rubi Agency</strong></p>
          
          <hr>
          <p style="font-size: 12px; color: #666;">
            Este é um email automático. Se você não se cadastrou em nosso site, pode ignorar esta mensagem.
          </p>
        `,
      })

      console.log("✅ User confirmation email sent")
    } catch (emailError) {
      console.error("⚠️ Failed to send user confirmation email:", emailError)
    }

    // Revalidar páginas relacionadas
    revalidatePath("/admin")
    revalidatePath("/admin/registrations")

    return {
      success: true,
      message: "Cadastro realizado com sucesso! Entraremos em contato em breve.",
      registrationId: registration.id,
    }
  } catch (error) {
    console.error("❌ Error in submitContactForm:", error)

    return {
      success: false,
      message: "Erro interno do servidor. Tente novamente mais tarde.",
    }
  }
}

// ✅ FUNÇÃO DE TESTE
export async function testContactSubmission() {
  const testData: ContactFormData = {
    name: "Maria Silva Teste",
    email: "maria.teste@email.com",
    phone: "+55 11 99999-8888",
    instagram: "@maria_teste_model",
    age: 25,
    subject: "Teste de formulário",
    experience: "intermediate",
    message: "Esta é uma mensagem de teste do sistema de cadastro.",
    partnerCode: "TESTE_SP",
  }

  console.log("🧪 Running test contact submission...")
  const result = await submitContactForm(testData)
  console.log("🧪 Test result:", result)

  return result
}
