import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { LanguageProvider } from "@/contexts/language-context"

// Importar polyfills apenas no servidor de forma segura
if (typeof window === "undefined") {
  import("@/lib/polyfills")
    .then(({ initPolyfills }) => {
      initPolyfills()
    })
    .catch(() => {
      // Ignorar erros de polyfills em produção
    })
}

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Rubi Agency - Transformando Ideias em Realidade",
  description:
    "Agência especializada em marketing digital, desenvolvimento web e soluções criativas para impulsionar seu negócio.",
  keywords: "marketing digital, desenvolvimento web, agência, soluções criativas, negócios",
  authors: [{ name: "Rubi Agency" }],
  creator: "Rubi Agency",
  publisher: "Rubi Agency",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "https://www.rubiagency.com"),
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "Rubi Agency - Transformando Ideias em Realidade",
    description:
      "Agência especializada em marketing digital, desenvolvimento web e soluções criativas para impulsionar seu negócio.",
    url: process.env.NEXT_PUBLIC_SITE_URL || "https://www.rubiagency.com",
    siteName: "Rubi Agency",
    images: [
      {
        url: "/rubi-agency-logo.png",
        width: 1200,
        height: 630,
        alt: "Rubi Agency Logo",
      },
    ],
    locale: "pt_BR",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Rubi Agency - Transformando Ideias em Realidade",
    description:
      "Agência especializada em marketing digital, desenvolvimento web e soluções criativas para impulsionar seu negócio.",
    images: ["/rubi-agency-logo.png"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  verification: {
    google: process.env.GOOGLE_SITE_VERIFICATION,
  },
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <head>
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#000000" />
      </head>
      <body className={inter.className} suppressHydrationWarning>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          <LanguageProvider>{children}</LanguageProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
