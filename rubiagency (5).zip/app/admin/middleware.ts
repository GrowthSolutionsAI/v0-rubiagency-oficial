import { type NextRequest, NextResponse } from "next/server"

export function middleware(request: NextRequest) {
  // Verificar se é a página de login
  if (request.nextUrl.pathname === "/admin/login") {
    return NextResponse.next()
  }

  // Verificar autenticação para outras rotas do admin
  const isAuthenticated = request.cookies.get("admin-auth")?.value === "authenticated"

  if (!isAuthenticated && request.nextUrl.pathname.startsWith("/admin")) {
    // Redirecionar para login
    return NextResponse.redirect(new URL("/admin/login", request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: "/admin/:path*",
}
