"use client"

import type React from "react"
import { AdminLayoutClient } from "./components/admin-layout-client"

interface AdminLayoutProps {
  children: React.ReactNode
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  return <AdminLayoutClient>{children}</AdminLayoutClient>
}
