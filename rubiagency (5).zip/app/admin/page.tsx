import { Suspense } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Users, CheckCircle, Clock, TrendingUp, Database, Globe, Mail } from "lucide-react"
import { getRegistrationStats, getRegistrations } from "@/lib/database"
import { AdminEmailTest } from "./components/admin-email-test"

// Stats Cards Component with real data
async function StatsCards() {
  try {
    const stats = await getRegistrationStats()

    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Registros</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600 flex items-center gap-1">
                <TrendingUp className="h-3 w-3" />+{stats.thisMonth} este mês
              </span>
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pendentes</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pending}</div>
            <p className="text-xs text-muted-foreground">Aguardando análise</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Aprovados</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.approved}</div>
            <p className="text-xs text-muted-foreground">
              {stats.total > 0 ? ((stats.approved / stats.total) * 100).toFixed(1) : 0}% do total
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Crescimento</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stats.growthRate > 0 ? "+" : ""}
              {stats.growthRate.toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground">vs. mês anterior</p>
          </CardContent>
        </Card>
      </div>
    )
  } catch (error) {
    console.error("Error loading stats:", error)
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-4 w-32" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-16 mb-2" />
              <Skeleton className="h-3 w-24" />
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }
}

// Recent Registrations with real data
async function RecentRegistrations() {
  try {
    const registrations = await getRegistrations()
    const recent = registrations.slice(0, 5)

    const getStatusBadge = (status: string) => {
      switch (status) {
        case "pending":
          return (
            <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
              Pendente
            </Badge>
          )
        case "approved":
          return (
            <Badge variant="default" className="bg-green-100 text-green-800">
              Aprovado
            </Badge>
          )
        case "rejected":
          return (
            <Badge variant="destructive" className="bg-red-100 text-red-800">
              Rejeitado
            </Badge>
          )
        default:
          return <Badge variant="outline">Desconhecido</Badge>
      }
    }

    const formatDate = (dateString: string) => {
      return new Date(dateString).toLocaleDateString("pt-BR", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      })
    }

    return (
      <Card>
        <CardHeader>
          <CardTitle>Registros Recentes</CardTitle>
          <CardDescription>Últimos {recent.length} registros recebidos</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recent.length > 0 ? (
              recent.map((registration) => (
                <div key={registration.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <p className="font-medium">{registration.name}</p>
                    <p className="text-sm text-muted-foreground">{registration.email}</p>
                    <p className="text-xs text-muted-foreground">{formatDate(registration.created_at)}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    {getStatusBadge(registration.status)}
                    <a
                      href={`/admin/registrations/details/${registration.id}`}
                      className="text-xs text-blue-600 hover:underline"
                    >
                      Ver detalhes
                    </a>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Nenhum registro encontrado</p>
                <p className="text-xs mt-2">Os registros aparecerão aqui quando forem enviados pelo formulário</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    )
  } catch (error) {
    console.error("Error loading recent registrations:", error)
    return (
      <Card>
        <CardHeader>
          <CardTitle>Registros Recentes</CardTitle>
          <CardDescription>Erro ao carregar registros</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-red-500">
            <p>Erro ao carregar registros recentes</p>
            <p className="text-xs mt-2">Verifique a conexão com o banco de dados</p>
          </div>
        </CardContent>
      </Card>
    )
  }
}

// System Status with real checks
async function SystemStatus() {
  try {
    const { isDatabaseAvailable } = await import("@/lib/database")
    const dbStatus = await isDatabaseAvailable()

    return (
      <Card>
        <CardHeader>
          <CardTitle>Status do Sistema</CardTitle>
          <CardDescription>Monitoramento em tempo real</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className={`h-4 w-4 ${dbStatus ? "text-green-600" : "text-red-600"}`} />
                <span className="text-sm">Database</span>
              </div>
              <Badge
                variant={dbStatus ? "default" : "destructive"}
                className={dbStatus ? "bg-green-100 text-green-800" : ""}
              >
                {dbStatus ? "Online" : "Offline"}
              </Badge>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Globe className="h-4 w-4 text-green-600" />
                <span className="text-sm">API</span>
              </div>
              <Badge variant="default" className="bg-green-100 text-green-800">
                Funcionando
              </Badge>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-green-600" />
                <span className="text-sm">Email</span>
              </div>
              <Badge variant="default" className="bg-green-100 text-green-800">
                Ativo
              </Badge>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-green-600" />
                <span className="text-sm">Formulário</span>
              </div>
              <Badge variant="default" className="bg-green-100 text-green-800">
                Recebendo
              </Badge>
            </div>

            <div className="pt-2 text-xs text-muted-foreground border-t">
              Última verificação: {new Date().toLocaleTimeString("pt-BR")}
            </div>
          </div>
        </CardContent>
      </Card>
    )
  } catch (error) {
    console.error("Error checking system status:", error)
    return (
      <Card>
        <CardHeader>
          <CardTitle>Status do Sistema</CardTitle>
          <CardDescription>Erro ao verificar status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4 text-red-500">
            <p className="text-sm">Erro ao verificar status do sistema</p>
          </div>
        </CardContent>
      </Card>
    )
  }
}

export default function AdminDashboard() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Visão geral do sistema e estatísticas de registros</p>
      </div>

      {/* Stats Cards */}
      <Suspense
        fallback={
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {[...Array(4)].map((_, i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-4 w-32" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-8 w-16 mb-2" />
                  <Skeleton className="h-3 w-24" />
                </CardContent>
              </Card>
            ))}
          </div>
        }
      >
        <StatsCards />
      </Suspense>

      {/* Main Content Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {/* Recent Registrations */}
        <div className="lg:col-span-2">
          <Suspense
            fallback={
              <Card>
                <CardHeader>
                  <Skeleton className="h-6 w-40" />
                  <Skeleton className="h-4 w-60" />
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[...Array(3)].map((_, i) => (
                      <Skeleton key={i} className="h-16 w-full" />
                    ))}
                  </div>
                </CardContent>
              </Card>
            }
          >
            <RecentRegistrations />
          </Suspense>
        </div>

        {/* System Status and Email Test */}
        <div className="space-y-6">
          <Suspense
            fallback={
              <Card>
                <CardHeader>
                  <Skeleton className="h-6 w-32" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-20 w-full" />
                </CardContent>
              </Card>
            }
          >
            <SystemStatus />
          </Suspense>

          <AdminEmailTest />
        </div>
      </div>
    </div>
  )
}
