"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Clock, CheckCircle, XCircle, User, Mail, Phone, RefreshCw, AlertCircle, Database } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

interface Registration {
  id: string
  name: string
  email: string
  phone?: string
  instagram?: string
  message: string
  status: "pending" | "approved" | "rejected"
  created_at: string
}

export function RecentRegistrations() {
  const [registrations, setRegistrations] = useState<Registration[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date())

  const fetchRegistrations = async () => {
    try {
      console.log("🔍 Fetching recent registrations...")
      setIsLoading(true)
      setError(null)

      const response = await fetch("/api/admin/registrations?limit=5")
      const result = await response.json()

      console.log("📊 Registrations API response:", result)

      if (result.success) {
        setRegistrations(result.data || [])
        console.log("✅ Recent registrations loaded:", result.data?.length || 0)
      } else {
        console.error("❌ API Error:", result.error)
        setError(result.error || "Erro ao carregar dados")

        // Se falhou, usar dados demo
        if (result.data) {
          setRegistrations(result.data)
        }
      }
    } catch (error) {
      console.error("❌ Error fetching registrations:", error)
      setError("Erro de conexão")

      // Dados demo em caso de erro
      setRegistrations([
        {
          id: "demo-1",
          name: "Demo User",
          email: "demo@example.com",
          phone: "(11) 99999-9999",
          instagram: "@demouser",
          message: "This is a demo registration",
          status: "pending",
          created_at: new Date().toISOString(),
        },
      ])
    } finally {
      setIsLoading(false)
      setLastRefresh(new Date())
    }
  }

  useEffect(() => {
    fetchRegistrations()
  }, [])

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="text-yellow-600 border-yellow-600">
            <Clock className="h-3 w-3 mr-1" />
            Pendente
          </Badge>
        )
      case "approved":
        return (
          <Badge variant="outline" className="text-green-600 border-green-600">
            <CheckCircle className="h-3 w-3 mr-1" />
            Aprovado
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="outline" className="text-red-600 border-red-600">
            <XCircle className="h-3 w-3 mr-1" />
            Reprovado
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const handleRefresh = () => {
    fetchRegistrations()
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <User className="h-4 w-4" />
          Cadastros Recentes
        </CardTitle>
        <div className="flex items-center gap-2">
          {error && (
            <div className="flex items-center gap-1 text-red-600 text-xs">
              <AlertCircle className="h-3 w-3" />
              Erro
            </div>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={isLoading}
            className="h-8 w-8 p-0 bg-transparent"
          >
            <RefreshCw className={`h-3 w-3 ${isLoading ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4 animate-pulse">
                <div className="h-10 w-10 bg-gray-200 rounded-full"></div>
                <div className="space-y-2 flex-1">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        ) : error && registrations.length === 0 ? (
          <div className="text-center py-6">
            <Database className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 mb-2">Erro ao carregar cadastros</p>
            <p className="text-xs text-gray-400 mb-4">{error}</p>
            <Button onClick={handleRefresh} variant="outline" size="sm">
              <RefreshCw className="h-4 w-4 mr-2" />
              Tentar Novamente
            </Button>
          </div>
        ) : registrations.length === 0 ? (
          <div className="text-center py-6">
            <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">Nenhum cadastro encontrado</p>
            <p className="text-xs text-gray-400 mt-2">Última atualização: {format(lastRefresh, "HH:mm:ss")}</p>
          </div>
        ) : (
          <div className="space-y-4">
            {registrations.slice(0, 5).map((registration) => (
              <div
                key={registration.id}
                className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center space-x-3">
                  <div className="h-10 w-10 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center">
                    <User className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{registration.name}</p>
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <Mail className="h-3 w-3" />
                        {registration.email}
                      </span>
                      {registration.phone && (
                        <span className="flex items-center gap-1">
                          <Phone className="h-3 w-3" />
                          {registration.phone}
                        </span>
                      )}
                      <span>{format(new Date(registration.created_at), "dd/MM/yyyy", { locale: ptBR })}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {getStatusBadge(registration.status)}
                  <Button asChild variant="outline" size="sm">
                    <Link href={`/admin/registrations/details/${registration.id}`}>Ver</Link>
                  </Button>
                </div>
              </div>
            ))}

            {registrations.length > 5 && (
              <div className="text-center pt-4 border-t">
                <Button asChild variant="outline">
                  <Link href="/admin/registrations">Ver Todos os Cadastros ({registrations.length})</Link>
                </Button>
              </div>
            )}

            <div className="text-xs text-gray-400 text-center pt-2">
              Última atualização: {format(lastRefresh, "dd/MM/yyyy 'às' HH:mm:ss", { locale: ptBR })}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
