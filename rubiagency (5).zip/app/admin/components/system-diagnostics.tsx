"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Activity,
  Database,
  Server,
  Wifi,
  HardDrive,
  Clock,
  CheckCircle,
  AlertCircle,
  XCircle,
  RefreshCw,
} from "lucide-react"

interface SystemStatus {
  database: "online" | "offline" | "slow"
  server: "healthy" | "warning" | "error"
  storage: "normal" | "warning" | "full"
  network: "fast" | "slow" | "offline"
}

interface SystemMetrics {
  uptime: string
  responseTime: number
  memoryUsage: number
  diskUsage: number
  activeConnections: number
  totalRequests: number
}

export function SystemDiagnostics() {
  const [status, setStatus] = useState<SystemStatus>({
    database: "online",
    server: "healthy",
    storage: "normal",
    network: "fast",
  })

  const [metrics, setMetrics] = useState<SystemMetrics>({
    uptime: "7d 14h 32m",
    responseTime: 145,
    memoryUsage: 68,
    diskUsage: 34,
    activeConnections: 23,
    totalRequests: 15420,
  })

  const [isLoading, setIsLoading] = useState(false)
  const [lastUpdate, setLastUpdate] = useState(new Date())

  const runDiagnostics = async () => {
    setIsLoading(true)

    // Simular testes de diagnóstico
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Simular resultados aleatórios para demonstração
    const newStatus: SystemStatus = {
      database: Math.random() > 0.1 ? "online" : "slow",
      server: Math.random() > 0.05 ? "healthy" : "warning",
      storage: Math.random() > 0.02 ? "normal" : "warning",
      network: Math.random() > 0.1 ? "fast" : "slow",
    }

    const newMetrics: SystemMetrics = {
      uptime: "7d 14h 35m",
      responseTime: Math.floor(Math.random() * 200) + 100,
      memoryUsage: Math.floor(Math.random() * 30) + 60,
      diskUsage: Math.floor(Math.random() * 20) + 30,
      activeConnections: Math.floor(Math.random() * 20) + 15,
      totalRequests: metrics.totalRequests + Math.floor(Math.random() * 100),
    }

    setStatus(newStatus)
    setMetrics(newMetrics)
    setLastUpdate(new Date())
    setIsLoading(false)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "online":
      case "healthy":
      case "normal":
      case "fast":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "slow":
      case "warning":
        return <AlertCircle className="h-4 w-4 text-yellow-500" />
      case "offline":
      case "error":
      case "full":
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online":
      case "healthy":
      case "normal":
      case "fast":
        return "default"
      case "slow":
      case "warning":
        return "secondary"
      case "offline":
      case "error":
      case "full":
        return "destructive"
      default:
        return "outline"
    }
  }

  useEffect(() => {
    // Auto-refresh a cada 30 segundos
    const interval = setInterval(() => {
      if (!isLoading) {
        runDiagnostics()
      }
    }, 30000)

    return () => clearInterval(interval)
  }, [isLoading])

  return (
    <div className="space-y-6">
      {/* Header com botão de refresh */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Status do Sistema</h3>
          <p className="text-sm text-muted-foreground">Última atualização: {lastUpdate.toLocaleTimeString()}</p>
        </div>
        <Button onClick={runDiagnostics} disabled={isLoading} variant="outline" size="sm">
          <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`} />
          {isLoading ? "Verificando..." : "Atualizar"}
        </Button>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Banco de Dados</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              {getStatusIcon(status.database)}
              <Badge variant={getStatusColor(status.database) as any}>{status.database}</Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-2">{metrics.activeConnections} conexões ativas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Servidor</CardTitle>
            <Server className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              {getStatusIcon(status.server)}
              <Badge variant={getStatusColor(status.server) as any}>{status.server}</Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-2">Uptime: {metrics.uptime}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Armazenamento</CardTitle>
            <HardDrive className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              {getStatusIcon(status.storage)}
              <Badge variant={getStatusColor(status.storage) as any}>{status.storage}</Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-2">{metrics.diskUsage}% usado</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Rede</CardTitle>
            <Wifi className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              {getStatusIcon(status.network)}
              <Badge variant={getStatusColor(status.network) as any}>{status.network}</Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-2">{metrics.responseTime}ms resposta</p>
          </CardContent>
        </Card>
      </div>

      {/* Métricas detalhadas */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Performance
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Uso de Memória</span>
                <span>{metrics.memoryUsage}%</span>
              </div>
              <Progress value={metrics.memoryUsage} className="h-2" />
            </div>

            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Uso de Disco</span>
                <span>{metrics.diskUsage}%</span>
              </div>
              <Progress value={metrics.diskUsage} className="h-2" />
            </div>

            <div className="pt-2 border-t">
              <div className="flex justify-between text-sm">
                <span>Tempo de Resposta</span>
                <span className={metrics.responseTime > 200 ? "text-yellow-600" : "text-green-600"}>
                  {metrics.responseTime}ms
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Estatísticas
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Total de Requisições</p>
                <p className="text-2xl font-bold">{metrics.totalRequests.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Conexões Ativas</p>
                <p className="text-2xl font-bold">{metrics.activeConnections}</p>
              </div>
            </div>

            <div className="pt-2 border-t">
              <p className="text-sm text-muted-foreground">Tempo Online</p>
              <p className="text-lg font-semibold">{metrics.uptime}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alertas do sistema */}
      <div className="space-y-4">
        {status.database === "slow" && (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <strong>Atenção:</strong> O banco de dados está respondendo lentamente. Considere otimizar consultas ou
              verificar a conectividade.
            </AlertDescription>
          </Alert>
        )}

        {metrics.memoryUsage > 80 && (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <strong>Aviso:</strong> Uso de memória alto ({metrics.memoryUsage}%). Monitore o desempenho do sistema.
            </AlertDescription>
          </Alert>
        )}

        {metrics.responseTime > 300 && (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <strong>Performance:</strong> Tempo de resposta elevado ({metrics.responseTime}ms). Verifique a carga do
              servidor.
            </AlertDescription>
          </Alert>
        )}
      </div>
    </div>
  )
}
