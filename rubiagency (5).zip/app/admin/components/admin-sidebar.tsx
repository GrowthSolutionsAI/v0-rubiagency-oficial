"use client"

import { useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { LayoutDashboard, Users, Settings, FileText, BarChart3, LogOut, CheckCircle, AlertCircle } from "lucide-react"

const menuItems = [
  {
    title: "Dashboard",
    url: "/admin",
    icon: LayoutDashboard,
  },
  {
    title: "Registros",
    url: "/admin/registrations",
    icon: Users,
  },
  {
    title: "Parceiros",
    url: "/admin/partners",
    icon: FileText,
  },
  {
    title: "Analytics",
    url: "/admin/analytics",
    icon: BarChart3,
  },
  {
    title: "Configurações",
    url: "/admin/settings",
    icon: Settings,
  },
]

export function AdminSidebar() {
  const router = useRouter()
  const pathname = usePathname()
  const [isLoggingOut, setIsLoggingOut] = useState(false)
  const [logoutMessage, setLogoutMessage] = useState("")

  const handleLogout = async () => {
    setIsLoggingOut(true)
    setLogoutMessage("")

    try {
      // Clear client-side auth
      localStorage.removeItem("admin-auth")
      sessionStorage.removeItem("admin-auth")

      // Call logout API
      await fetch("/api/admin/logout", {
        method: "POST",
      })

      setLogoutMessage("Logout realizado com sucesso!")

      // Redirect after a short delay
      setTimeout(() => {
        router.push("/admin/login")
        router.refresh()
      }, 1000)
    } catch (error) {
      console.error("Logout error:", error)
      setLogoutMessage("Erro ao fazer logout")
      setIsLoggingOut(false)
    }
  }

  return (
    <Sidebar>
      <SidebarHeader>
        <div className="flex items-center gap-2 px-4 py-2">
          <div className="w-8 h-8 bg-gradient-to-br from-red-600 to-red-700 rounded-lg flex items-center justify-center">
            <LayoutDashboard className="h-4 w-4 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-semibold">Rubi Agency</h2>
            <p className="text-xs text-gray-500">Admin Dashboard</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Menu Principal</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={pathname === item.url}>
                    <a href={item.url}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter>
        <div className="p-4 space-y-3">
          {logoutMessage && (
            <Alert
              className={
                logoutMessage.includes("sucesso") ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"
              }
            >
              {logoutMessage.includes("sucesso") ? (
                <CheckCircle className="h-4 w-4 text-green-600" />
              ) : (
                <AlertCircle className="h-4 w-4 text-red-600" />
              )}
              <AlertDescription className={logoutMessage.includes("sucesso") ? "text-green-800" : "text-red-800"}>
                {logoutMessage}
              </AlertDescription>
            </Alert>
          )}

          <Button variant="outline" className="w-full bg-transparent" onClick={handleLogout} disabled={isLoggingOut}>
            {isLoggingOut ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-gray-400 border-t-transparent rounded-full animate-spin" />
                Saindo...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <LogOut className="h-4 w-4" />
                Sair
              </div>
            )}
          </Button>

          <div className="text-center">
            <p className="text-xs text-gray-500">
              Logado como: <strong>Admin</strong>
            </p>
          </div>
        </div>
      </SidebarFooter>

      <SidebarRail />
    </Sidebar>
  )
}
