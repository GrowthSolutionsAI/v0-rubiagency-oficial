"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ExternalLink, Save, CheckCircle, AlertCircle, BarChart3 } from "lucide-react"
import { updateSystemSetting } from "../actions"
import type { SystemSetting } from "@/lib/database"

interface AnalyticsSettingsProps {
  settings: SystemSetting[]
}

export function AnalyticsSettings({ settings }: AnalyticsSettingsProps) {
  const [formData, setFormData] = useState({
    google_analytics_id: settings.find((s) => s.setting_key === "google_analytics_id")?.setting_value || "",
    google_search_console_property:
      settings.find((s) => s.setting_key === "google_search_console_property")?.setting_value || "",
    facebook_pixel_id: settings.find((s) => s.setting_key === "facebook_pixel_id")?.setting_value || "",
    google_tag_manager_id: settings.find((s) => s.setting_key === "google_tag_manager_id")?.setting_value || "",
  })

  const [isSaving, setIsSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  const handleChange = (key: string, value: string) => {
    setFormData((prev) => ({ ...prev, [key]: value }))
  }

  const handleSave = async () => {
    setIsSaving(true)
    try {
      // Save each setting
      await Promise.all([
        updateSystemSetting("google_analytics_id", formData.google_analytics_id),
        updateSystemSetting("google_search_console_property", formData.google_search_console_property),
        updateSystemSetting("facebook_pixel_id", formData.facebook_pixel_id),
        updateSystemSetting("google_tag_manager_id", formData.google_tag_manager_id),
      ])

      setSaved(true)
      setTimeout(() => setSaved(false), 3000)
    } catch (error) {
      console.error("Erro ao salvar configurações:", error)
    } finally {
      setIsSaving(false)
    }
  }

  const isConfigured = (value: string) => value && value.trim() !== ""

  return (
    <div className="space-y-6">
      {/* Google Analytics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-blue-600" />
            Google Analytics 4
            {isConfigured(formData.google_analytics_id) ? (
              <Badge variant="outline" className="text-green-600 border-green-600">
                <CheckCircle className="h-3 w-3 mr-1" />
                Configurado
              </Badge>
            ) : (
              <Badge variant="outline" className="text-yellow-600 border-yellow-600">
                <AlertCircle className="h-3 w-3 mr-1" />
                Não configurado
              </Badge>
            )}
          </CardTitle>
          <CardDescription>
            Configure o Google Analytics para rastrear visitantes e comportamento do site
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="google_analytics_id">Measurement ID</Label>
            <Input
              id="google_analytics_id"
              value={formData.google_analytics_id}
              onChange={(e) => handleChange("google_analytics_id", e.target.value)}
              placeholder="G-XXXXXXXXXX"
              className="font-mono"
            />
            <p className="text-sm text-gray-600">Encontre em: Google Analytics → Admin → Data Streams → Web Stream</p>
          </div>
        </CardContent>
      </Card>

      {/* Google Search Console */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ExternalLink className="h-5 w-5 text-green-600" />
            Google Search Console
            {isConfigured(formData.google_search_console_property) ? (
              <Badge variant="outline" className="text-green-600 border-green-600">
                <CheckCircle className="h-3 w-3 mr-1" />
                Configurado
              </Badge>
            ) : (
              <Badge variant="outline" className="text-yellow-600 border-yellow-600">
                <AlertCircle className="h-3 w-3 mr-1" />
                Não configurado
              </Badge>
            )}
          </CardTitle>
          <CardDescription>Configure o Search Console para monitorar performance de SEO</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="google_search_console_property">URL da Propriedade</Label>
            <Input
              id="google_search_console_property"
              value={formData.google_search_console_property}
              onChange={(e) => handleChange("google_search_console_property", e.target.value)}
              placeholder="https://rubiagency.com"
            />
            <p className="text-sm text-gray-600">URL da propriedade verificada no Google Search Console</p>
          </div>
        </CardContent>
      </Card>

      {/* Facebook Pixel */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="h-5 w-5 bg-blue-600 rounded flex items-center justify-center">
              <span className="text-white text-xs font-bold">f</span>
            </div>
            Facebook Pixel
            {isConfigured(formData.facebook_pixel_id) ? (
              <Badge variant="outline" className="text-green-600 border-green-600">
                <CheckCircle className="h-3 w-3 mr-1" />
                Configurado
              </Badge>
            ) : (
              <Badge variant="outline" className="text-yellow-600 border-yellow-600">
                <AlertCircle className="h-3 w-3 mr-1" />
                Não configurado
              </Badge>
            )}
          </CardTitle>
          <CardDescription>Configure o Facebook Pixel para rastrear conversões e criar audiências</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="facebook_pixel_id">Pixel ID</Label>
            <Input
              id="facebook_pixel_id"
              value={formData.facebook_pixel_id}
              onChange={(e) => handleChange("facebook_pixel_id", e.target.value)}
              placeholder="XXXXXXXXXXXXXXX"
              className="font-mono"
            />
            <p className="text-sm text-gray-600">Encontre em: Meta Business → Eventos → Pixels → Configurações</p>
          </div>
        </CardContent>
      </Card>

      {/* Google Tag Manager */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="h-5 w-5 bg-orange-600 rounded flex items-center justify-center">
              <span className="text-white text-xs font-bold">G</span>
            </div>
            Google Tag Manager
            {isConfigured(formData.google_tag_manager_id) ? (
              <Badge variant="outline" className="text-green-600 border-green-600">
                <CheckCircle className="h-3 w-3 mr-1" />
                Configurado
              </Badge>
            ) : (
              <Badge variant="outline" className="text-yellow-600 border-yellow-600">
                <AlertCircle className="h-3 w-3 mr-1" />
                Não configurado
              </Badge>
            )}
          </CardTitle>
          <CardDescription>Configure o GTM para gerenciar todas as tags de rastreamento</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="google_tag_manager_id">Container ID</Label>
            <Input
              id="google_tag_manager_id"
              value={formData.google_tag_manager_id}
              onChange={(e) => handleChange("google_tag_manager_id", e.target.value)}
              placeholder="GTM-XXXXXXX"
              className="font-mono"
            />
            <p className="text-sm text-gray-600">Encontre em: Google Tag Manager → Workspace → Container ID</p>
          </div>
        </CardContent>
      </Card>

      <Separator />

      {/* Save Button */}
      <div className="flex items-center gap-4">
        <Button onClick={handleSave} disabled={isSaving} className="flex items-center gap-2">
          {saved ? <CheckCircle className="h-4 w-4" /> : <Save className="h-4 w-4" />}
          {isSaving ? "Salvando..." : saved ? "Salvo!" : "Salvar Configurações"}
        </Button>
        {saved && (
          <Badge variant="outline" className="text-green-600 border-green-600">
            Configurações salvas com sucesso!
          </Badge>
        )}
      </div>

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle>Instruções de Configuração</CardTitle>
          <CardDescription>Como configurar cada ferramenta</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <h4 className="font-semibold text-blue-900 mb-2">Google Analytics 4</h4>
              <ol className="text-sm text-blue-800 space-y-1 list-decimal list-inside">
                <li>Acesse analytics.google.com</li>
                <li>Crie uma propriedade GA4</li>
                <li>Configure um Data Stream para Web</li>
                <li>Copie o Measurement ID (G-XXXXXXXXXX)</li>
              </ol>
            </div>

            <div className="p-4 bg-green-50 rounded-lg">
              <h4 className="font-semibold text-green-900 mb-2">Google Search Console</h4>
              <ol className="text-sm text-green-800 space-y-1 list-decimal list-inside">
                <li>Acesse search.google.com/search-console</li>
                <li>Adicione sua propriedade (URL do site)</li>
                <li>Verifique a propriedade via HTML tag ou DNS</li>
                <li>Aguarde a indexação dos dados</li>
              </ol>
            </div>

            <div className="p-4 bg-purple-50 rounded-lg">
              <h4 className="font-semibold text-purple-900 mb-2">Facebook Pixel</h4>
              <ol className="text-sm text-purple-800 space-y-1 list-decimal list-inside">
                <li>Acesse business.facebook.com</li>
                <li>Vá em Eventos → Pixels</li>
                <li>Crie um novo pixel ou use existente</li>
                <li>Copie o Pixel ID (números apenas)</li>
              </ol>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
