"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { updateEmailSettings, testEmailConfiguration } from "../actions"
import { toast } from "sonner"
import { Mail, Send, Settings, TestTube, CheckCircle, AlertCircle, Info } from "lucide-react"

interface SystemSetting {
  id: number
  setting_key: string
  setting_value: string
  description?: string
  updated_at: string
}

interface EmailSettingsProps {
  settings: SystemSetting[]
}

export function EmailSettings({ settings }: EmailSettingsProps) {
  const [loading, setLoading] = useState(false)
  const [testLoading, setTestLoading] = useState(false)
  const [testEmail, setTestEmail] = useState("")

  // Helper function to get setting value
  const getSetting = (key: string) => {
    return settings.find((s) => s.setting_key === key)?.setting_value || ""
  }

  // Form state
  const [formData, setFormData] = useState({
    smtp_enabled: getSetting("smtp_enabled") === "true",
    smtp_provider: getSetting("smtp_provider") || "resend",
    smtp_from_name: getSetting("smtp_from_name") || "Rubi Agency",
    smtp_from_email: getSetting("smtp_from_email") || "",
    resend_api_key: getSetting("resend_api_key") || "",
    sendgrid_api_key: getSetting("sendgrid_api_key") || "",
    smtp_host: getSetting("smtp_host") || "",
    smtp_port: getSetting("smtp_port") || "587",
    smtp_secure: getSetting("smtp_secure") === "true",
    smtp_user: getSetting("smtp_user") || "",
    smtp_password: getSetting("smtp_password") || "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const settingsToUpdate = {
        smtp_enabled: formData.smtp_enabled.toString(),
        smtp_provider: formData.smtp_provider,
        smtp_from_name: formData.smtp_from_name,
        smtp_from_email: formData.smtp_from_email,
        resend_api_key: formData.resend_api_key,
        sendgrid_api_key: formData.sendgrid_api_key,
        smtp_host: formData.smtp_host,
        smtp_port: formData.smtp_port,
        smtp_secure: formData.smtp_secure.toString(),
        smtp_user: formData.smtp_user,
        smtp_password: formData.smtp_password,
      }

      const result = await updateEmailSettings(settingsToUpdate)

      if (result.success) {
        toast.success(result.message)
      } else {
        toast.error(result.message)
      }
    } catch (error) {
      toast.error("Erro ao salvar configurações")
    } finally {
      setLoading(false)
    }
  }

  const handleTestEmail = async () => {
    if (!testEmail) {
      toast.error("Digite um email para teste")
      return
    }

    setTestLoading(true)
    try {
      const result = await testEmailConfiguration(testEmail)
      if (result.success) {
        toast.success("Email de teste enviado com sucesso!")
      } else {
        toast.error(result.message)
      }
    } catch (error) {
      toast.error("Erro ao enviar email de teste")
    } finally {
      setTestLoading(false)
    }
  }

  const updateFormData = (key: string, value: any) => {
    setFormData((prev) => ({ ...prev, [key]: value }))
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Status Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Status do Sistema de Email
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="smtp_enabled">Envio de Email Automático</Label>
              <p className="text-sm text-muted-foreground">Ativar/desativar o envio automático de emails</p>
            </div>
            <Switch
              id="smtp_enabled"
              checked={formData.smtp_enabled}
              onCheckedChange={(checked) => updateFormData("smtp_enabled", checked)}
            />
          </div>

          <div className="flex items-center gap-2">
            <Badge variant={formData.smtp_enabled ? "default" : "secondary"}>
              {formData.smtp_enabled ? (
                <>
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Ativo
                </>
              ) : (
                <>
                  <AlertCircle className="h-3 w-3 mr-1" />
                  Inativo
                </>
              )}
            </Badge>
            {formData.smtp_enabled && <Badge variant="outline">{formData.smtp_provider.toUpperCase()}</Badge>}
          </div>
        </CardContent>
      </Card>

      {/* Configuration Tabs */}
      <Tabs value={formData.smtp_provider} onValueChange={(value) => updateFormData("smtp_provider", value)}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="resend">Resend (Recomendado)</TabsTrigger>
          <TabsTrigger value="sendgrid">SendGrid</TabsTrigger>
          <TabsTrigger value="smtp">SMTP Personalizado</TabsTrigger>
        </TabsList>

        {/* Resend Configuration */}
        <TabsContent value="resend" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configuração Resend</CardTitle>
              <CardDescription>
                Resend é um serviço moderno e confiável para envio de emails transacionais
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  <strong>Como configurar:</strong>
                  <ol className="list-decimal list-inside mt-2 space-y-1">
                    <li>
                      Acesse{" "}
                      <a
                        href="https://resend.com"
                        target="_blank"
                        className="text-blue-600 hover:underline"
                        rel="noreferrer"
                      >
                        resend.com
                      </a>{" "}
                      e crie uma conta
                    </li>
                    <li>Vá em "API Keys" e crie uma nova chave</li>
                    <li>Cole a chave no campo abaixo</li>
                    <li>Configure um domínio verificado ou use o domínio de teste</li>
                  </ol>
                </AlertDescription>
              </Alert>

              <div className="space-y-2">
                <Label htmlFor="resend_api_key">API Key do Resend *</Label>
                <Input
                  id="resend_api_key"
                  type="password"
                  placeholder="re_xxxxxxxxxx"
                  value={formData.resend_api_key}
                  onChange={(e) => updateFormData("resend_api_key", e.target.value)}
                />
                <p className="text-sm text-muted-foreground">Sua chave API do Resend (começa com "re_")</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* SendGrid Configuration */}
        <TabsContent value="sendgrid" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configuração SendGrid</CardTitle>
              <CardDescription>SendGrid é uma plataforma robusta para envio de emails em escala</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  <strong>Como configurar:</strong>
                  <ol className="list-decimal list-inside mt-2 space-y-1">
                    <li>
                      Acesse{" "}
                      <a
                        href="https://sendgrid.com"
                        target="_blank"
                        className="text-blue-600 hover:underline"
                        rel="noreferrer"
                      >
                        sendgrid.com
                      </a>{" "}
                      e crie uma conta
                    </li>
                    <li>Vá em "Settings" → "API Keys"</li>
                    <li>Crie uma nova API Key com permissões de envio</li>
                    <li>Cole a chave no campo abaixo</li>
                  </ol>
                </AlertDescription>
              </Alert>

              <div className="space-y-2">
                <Label htmlFor="sendgrid_api_key">API Key do SendGrid *</Label>
                <Input
                  id="sendgrid_api_key"
                  type="password"
                  placeholder="SG.xxxxxxxxxx"
                  value={formData.sendgrid_api_key}
                  onChange={(e) => updateFormData("sendgrid_api_key", e.target.value)}
                />
                <p className="text-sm text-muted-foreground">Sua chave API do SendGrid (começa com "SG.")</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* SMTP Configuration */}
        <TabsContent value="smtp" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configuração SMTP</CardTitle>
              <CardDescription>Configure um servidor SMTP personalizado (Gmail, Outlook, etc.)</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  <strong>Configurações populares:</strong>
                  <div className="mt-2 space-y-2">
                    <div>
                      <strong>Gmail:</strong> smtp.gmail.com:587 (use App Password)
                    </div>
                    <div>
                      <strong>Outlook:</strong> smtp-mail.outlook.com:587
                    </div>
                    <div>
                      <strong>Yahoo:</strong> smtp.mail.yahoo.com:587
                    </div>
                  </div>
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="smtp_host">Servidor SMTP *</Label>
                  <Input
                    id="smtp_host"
                    placeholder="smtp.gmail.com"
                    value={formData.smtp_host}
                    onChange={(e) => updateFormData("smtp_host", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="smtp_port">Porta *</Label>
                  <Input
                    id="smtp_port"
                    placeholder="587"
                    value={formData.smtp_port}
                    onChange={(e) => updateFormData("smtp_port", e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="smtp_user">Usuário/Email *</Label>
                  <Input
                    id="smtp_user"
                    type="email"
                    placeholder="seu@email.com"
                    value={formData.smtp_user}
                    onChange={(e) => updateFormData("smtp_user", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="smtp_password">Senha *</Label>
                  <Input
                    id="smtp_password"
                    type="password"
                    placeholder="sua senha ou app password"
                    value={formData.smtp_password}
                    onChange={(e) => updateFormData("smtp_password", e.target.value)}
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="smtp_secure"
                  checked={formData.smtp_secure}
                  onCheckedChange={(checked) => updateFormData("smtp_secure", checked)}
                />
                <Label htmlFor="smtp_secure">Usar SSL/TLS</Label>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Sender Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Configurações do Remetente
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="smtp_from_name">Nome do Remetente *</Label>
              <Input
                id="smtp_from_name"
                placeholder="Rubi Agency"
                value={formData.smtp_from_name}
                onChange={(e) => updateFormData("smtp_from_name", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="smtp_from_email">Email do Remetente *</Label>
              <Input
                id="smtp_from_email"
                type="email"
                placeholder="noreply@rubiagency.com"
                value={formData.smtp_from_email}
                onChange={(e) => updateFormData("smtp_from_email", e.target.value)}
              />
            </div>
          </div>
          <p className="text-sm text-muted-foreground">
            Este será o nome e email que aparecerão como remetente dos emails automáticos
          </p>
        </CardContent>
      </Card>

      {/* Test Email */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TestTube className="h-5 w-5" />
            Testar Configuração
          </CardTitle>
          <CardDescription>
            Envie um email de teste para verificar se as configurações estão funcionando
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Digite um email para teste"
              value={testEmail}
              onChange={(e) => setTestEmail(e.target.value)}
              className="flex-1"
            />
            <Button
              type="button"
              variant="outline"
              onClick={handleTestEmail}
              disabled={testLoading || !formData.smtp_enabled}
            >
              {testLoading ? (
                "Enviando..."
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Testar
                </>
              )}
            </Button>
          </div>
          {!formData.smtp_enabled && (
            <p className="text-sm text-muted-foreground">Ative o sistema de email para poder testar</p>
          )}
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button type="submit" disabled={loading}>
          {loading ? "Salvando..." : "Salvar Configurações"}
        </Button>
      </div>
    </form>
  )
}
