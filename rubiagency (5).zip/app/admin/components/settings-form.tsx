"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { updateSetting } from "../actions"
import { useState } from "react"
import { Save, Mail, MessageSquare } from "lucide-react"

interface SystemSetting {
  id: number
  setting_key: string
  setting_value: string
  description?: string
}

interface SettingsFormProps {
  settings: SystemSetting[]
}

export function SettingsForm({ settings }: SettingsFormProps) {
  const [formData, setFormData] = useState(() => {
    const data: Record<string, string> = {}
    settings.forEach((setting) => {
      data[setting.setting_key] = setting.setting_value
    })
    return data
  })

  const [isLoading, setIsLoading] = useState(false)
  const [savedSettings, setSavedSettings] = useState<Set<string>>(new Set())

  const handleChange = (key: string, value: string) => {
    setFormData((prev) => ({ ...prev, [key]: value }))
    setSavedSettings((prev) => {
      const newSet = new Set(prev)
      newSet.delete(key)
      return newSet
    })
  }

  const handleSave = async (key: string) => {
    setIsLoading(true)
    try {
      await updateSetting(key, formData[key])
      setSavedSettings((prev) => new Set(prev).add(key))
    } catch (error) {
      console.error("Error saving setting:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const settingGroups = [
    {
      title: "Mensagem de Boas-vindas",
      icon: MessageSquare,
      settings: settings.filter((s) => s.setting_key === "welcome_message"),
    },
    {
      title: "Email de Aprovação",
      icon: Mail,
      settings: settings.filter((s) => s.setting_key.startsWith("approval_email")),
    },
    {
      title: "Email de Reprovação",
      icon: Mail,
      settings: settings.filter((s) => s.setting_key.startsWith("rejection_email")),
    },
    {
      title: "Configurações Gerais",
      icon: Mail,
      settings: settings.filter((s) => s.setting_key === "admin_email"),
    },
  ]

  const getFieldLabel = (key: string) => {
    const labels: Record<string, string> = {
      welcome_message: "Mensagem de Boas-vindas",
      approval_email_subject: "Assunto do Email",
      approval_email_body: "Corpo do Email",
      rejection_email_subject: "Assunto do Email",
      rejection_email_body: "Corpo do Email",
      admin_email: "Email do Administrador",
    }
    return labels[key] || key
  }

  return (
    <div className="space-y-6">
      {settingGroups.map((group) => (
        <Card key={group.title}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <group.icon className="h-5 w-5" />
              {group.title}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {group.settings.map((setting) => (
              <div key={setting.setting_key} className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor={setting.setting_key}>{getFieldLabel(setting.setting_key)}</Label>
                  <Button
                    onClick={() => handleSave(setting.setting_key)}
                    disabled={isLoading || savedSettings.has(setting.setting_key)}
                    size="sm"
                    variant={savedSettings.has(setting.setting_key) ? "outline" : "default"}
                  >
                    <Save className="h-4 w-4 mr-2" />
                    {savedSettings.has(setting.setting_key) ? "Salvo" : "Salvar"}
                  </Button>
                </div>

                {setting.description && <p className="text-sm text-gray-600">{setting.description}</p>}

                {setting.setting_key.includes("body") ? (
                  <Textarea
                    id={setting.setting_key}
                    value={formData[setting.setting_key] || ""}
                    onChange={(e) => handleChange(setting.setting_key, e.target.value)}
                    rows={6}
                    className="font-mono text-sm"
                    placeholder="Digite o conteúdo do email..."
                  />
                ) : (
                  <Input
                    id={setting.setting_key}
                    value={formData[setting.setting_key] || ""}
                    onChange={(e) => handleChange(setting.setting_key, e.target.value)}
                    placeholder={`Digite ${getFieldLabel(setting.setting_key).toLowerCase()}...`}
                  />
                )}

                {setting.setting_key.includes("email_body") && (
                  <div className="text-xs text-gray-500 bg-gray-50 p-2 rounded">
                    <strong>Variáveis disponíveis:</strong> {"{name}"} - Nome do usuário
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
