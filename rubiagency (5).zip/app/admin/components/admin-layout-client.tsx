"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import { AdminSidebar } from "./admin-sidebar"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"

interface AdminLayoutClientProps {
  children: React.ReactNode
}

export function AdminLayoutClient({ children }: AdminLayoutClientProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    const checkAuth = async () => {
      console.log("🔐 Checking authentication for path:", pathname)

      // Se estiver na página de login, não verificar auth
      if (pathname === "/admin/login") {
        console.log("📍 On login page - skipping auth check")
        setIsAuthenticated(false)
        setIsLoading(false)
        return
      }

      try {
        // Verificar cookie de autenticação via API
        const response = await fetch("/api/admin/auth/check", {
          method: "GET",
          credentials: "include",
        })

        const result = await response.json()
        console.log("🔍 Auth check result:", result)

        if (result.authenticated) {
          setIsAuthenticated(true)
          console.log("✅ User is authenticated")
        } else {
          console.log("❌ User not authenticated - redirecting to login")
          router.replace("/admin/login")
        }
      } catch (error) {
        console.error("❌ Auth check error:", error)
        router.replace("/admin/login")
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [pathname, router])

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Verificando autenticação...</p>
        </div>
      </div>
    )
  }

  // Login page - render without sidebar
  if (pathname === "/admin/login") {
    return <>{children}</>
  }

  // Not authenticated - show loading while redirecting
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Redirecionando para login...</p>
        </div>
      </div>
    )
  }

  // Authenticated - render admin layout
  return (
    <SidebarProvider>
      <AdminSidebar />
      <SidebarInset>
        <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">{children}</div>
      </SidebarInset>
    </SidebarProvider>
  )
}
