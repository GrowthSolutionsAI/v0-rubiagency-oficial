"use client"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  CheckCircle,
  XCircle,
  Clock,
  Mail,
  Phone,
  User,
  Calendar,
  FileText,
  ArrowLeft,
  ExternalLink,
  Instagram,
  Users,
} from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { approveRegistration, rejectRegistration } from "../actions"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"

interface Registration {
  id: string
  name: string
  email: string
  phone?: string
  whatsapp?: string
  instagram?: string
  age?: number
  subject?: string
  experience?: string
  message: string
  status: "pending" | "approved" | "rejected"
  partner_id?: number
  partner_code?: string
  partner_name?: string
  created_at: string
  updated_at?: string
  approved_at?: string
  approved_by?: string
}

interface UserFile {
  id: number
  filename: string
  original_name: string
  file_type: string
  file_size: number
  file_url: string
  created_at: string
}

interface RegistrationDetailsProps {
  registration: Registration
  files: UserFile[]
}

export function RegistrationDetails({ registration, files }: RegistrationDetailsProps) {
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleApprove = async () => {
    setIsLoading(true)
    try {
      const result = await approveRegistration(registration.id)
      if (result.success) {
        toast.success("Cadastro aprovado com sucesso!")
        router.refresh()
      } else {
        toast.error(result.message || "Erro ao aprovar cadastro")
      }
    } catch (error) {
      console.error("Error approving registration:", error)
      toast.error("Erro ao aprovar cadastro")
    } finally {
      setIsLoading(false)
    }
  }

  const handleReject = async () => {
    setIsLoading(true)
    try {
      const result = await rejectRegistration(registration.id)
      if (result.success) {
        toast.success("Cadastro rejeitado")
        router.refresh()
      } else {
        toast.error(result.message || "Erro ao rejeitar cadastro")
      }
    } catch (error) {
      console.error("Error rejecting registration:", error)
      toast.error("Erro ao rejeitar cadastro")
    } finally {
      setIsLoading(false)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="text-yellow-600 border-yellow-600 bg-yellow-50">
            <Clock className="h-3 w-3 mr-1" />
            Pendente
          </Badge>
        )
      case "approved":
        return (
          <Badge variant="outline" className="text-green-600 border-green-600 bg-green-50">
            <CheckCircle className="h-3 w-3 mr-1" />
            Aprovado
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="outline" className="text-red-600 border-red-600 bg-red-50">
            <XCircle className="h-3 w-3 mr-1" />
            Rejeitado
          </Badge>
        )
      default:
        return (
          <Badge variant="outline" className="text-gray-600 border-gray-600">
            Desconhecido
          </Badge>
        )
    }
  }

  const formatWhatsApp = (phone: string) => {
    const cleaned = phone.replace(/\D/g, "")
    if (cleaned.length >= 10) {
      return `+55${cleaned}`
    }
    return phone
  }

  const getInstagramUrl = (username: string) => {
    const cleanUsername = username.replace("@", "")
    return `https://instagram.com/${cleanUsername}`
  }

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "dd 'de' MMMM 'de' yyyy 'às' HH:mm", { locale: ptBR })
    } catch {
      return dateString
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button asChild variant="outline" size="sm">
            <Link href="/admin/registrations">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar
            </Link>
          </Button>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Detalhes do Cadastro</h2>
            <p className="text-gray-600">ID: #{registration.id}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {getStatusBadge(registration.status)}
          {/* Tag do Parceiro */}
          {registration.partner_code && (
            <Badge variant="outline" className="text-blue-600 border-blue-600 bg-blue-50">
              <Users className="h-3 w-3 mr-1" />
              Parceiro: {registration.partner_name || registration.partner_code}
            </Badge>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Informações Principais */}
        <div className="lg:col-span-2 space-y-6">
          {/* Informação do Parceiro (se houver) */}
          {registration.partner_code && (
            <Card className="border-blue-200 bg-blue-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-800">
                  <Users className="h-5 w-5" />
                  Indicação de Parceiro
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-blue-700">Nome do Parceiro:</span>
                    <span className="text-blue-800 font-medium">
                      {registration.partner_name || "Nome não encontrado"}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-blue-700">Código:</span>
                    <code className="text-blue-800 bg-blue-100 px-2 py-1 rounded text-sm">
                      {registration.partner_code}
                    </code>
                  </div>
                  <div className="pt-2 border-t border-blue-200">
                    <p className="text-sm text-blue-700">
                      💡 <strong>Cadastro via indicação:</strong> Este cadastro foi realizado através do link de
                      afiliado do parceiro acima.
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      asChild
                      variant="outline"
                      size="sm"
                      className="border-blue-300 text-blue-700 bg-transparent"
                    >
                      <Link href={`/admin/partners/${registration.partner_id}`}>
                        <Users className="h-4 w-4 mr-2" />
                        Ver Parceiro
                      </Link>
                    </Button>
                    <Button
                      asChild
                      variant="outline"
                      size="sm"
                      className="border-blue-300 text-blue-700 bg-transparent"
                    >
                      <Link href={`/admin/registrations?partner=${registration.partner_code}`}>
                        <FileText className="h-4 w-4 mr-2" />
                        Ver Todas Indicações
                      </Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Informações Pessoais
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-700">Nome Completo</label>
                  <p className="text-gray-900 font-medium">{registration.name}</p>
                </div>
                {registration.age && (
                  <div>
                    <label className="text-sm font-medium text-gray-700">Idade</label>
                    <p className="text-gray-900">{registration.age} anos</p>
                  </div>
                )}
                <div>
                  <label className="text-sm font-medium text-gray-700">Email</label>
                  <p className="text-gray-900 flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    <a href={`mailto:${registration.email}`} className="text-blue-600 hover:underline">
                      {registration.email}
                    </a>
                  </p>
                </div>
                {(registration.whatsapp || registration.phone) && (
                  <div>
                    <label className="text-sm font-medium text-gray-700">Telefone/WhatsApp</label>
                    <p className="text-gray-900 flex items-center gap-2">
                      <Phone className="h-4 w-4" />
                      <a
                        href={`https://wa.me/${formatWhatsApp(registration.whatsapp || registration.phone || "").replace(/\D/g, "")}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-green-600 hover:underline"
                      >
                        {registration.whatsapp || registration.phone}
                      </a>
                    </p>
                  </div>
                )}
                {registration.instagram && (
                  <div className="md:col-span-2">
                    <label className="text-sm font-medium text-gray-700">Instagram</label>
                    <div className="flex items-center gap-3 mt-1">
                      <div className="flex items-center gap-2">
                        <Instagram className="h-5 w-5 text-pink-500" />
                        <span className="text-gray-900 font-medium">{registration.instagram}</span>
                      </div>
                      <Button asChild variant="outline" size="sm">
                        <a
                          href={getInstagramUrl(registration.instagram)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2"
                        >
                          <ExternalLink className="h-4 w-4" />
                          Ver Perfil
                        </a>
                      </Button>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Clique para visualizar o portfólio no Instagram</p>
                  </div>
                )}
                {registration.subject && (
                  <div>
                    <label className="text-sm font-medium text-gray-700">Assunto</label>
                    <p className="text-gray-900">{registration.subject}</p>
                  </div>
                )}
                {registration.experience && (
                  <div>
                    <label className="text-sm font-medium text-gray-700">Experiência</label>
                    <p className="text-gray-900">{registration.experience}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Mensagem
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-50 p-4 rounded-lg border">
                <p className="text-gray-900 whitespace-pre-wrap leading-relaxed">{registration.message}</p>
              </div>
            </CardContent>
          </Card>

          {/* Informações sobre Instagram */}
          {registration.instagram && (
            <Card className="border-pink-200 bg-pink-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-pink-800">
                  <Instagram className="h-5 w-5" />
                  Portfólio Instagram
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-pink-700">Username:</span>
                    <span className="text-pink-800 font-medium">{registration.instagram}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-pink-700">Link direto:</span>
                    <a
                      href={getInstagramUrl(registration.instagram)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-pink-600 hover:text-pink-800 underline text-sm"
                    >
                      {getInstagramUrl(registration.instagram)}
                    </a>
                  </div>
                  <div className="pt-2 border-t border-pink-200">
                    <p className="text-sm text-pink-700">
                      💡 <strong>Dica:</strong> Analise as fotos recentes, stories em destaque e a estética geral do
                      perfil para avaliar o potencial da candidata.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar com Ações */}
        <div className="space-y-6">
          {/* Ações */}
          {registration.status === "pending" && (
            <Card>
              <CardHeader>
                <CardTitle>Ações</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  onClick={handleApprove}
                  disabled={isLoading}
                  className="w-full bg-green-600 hover:bg-green-700 text-white"
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  {isLoading ? "Aprovando..." : "Aprovar Cadastro"}
                </Button>
                <Button onClick={handleReject} disabled={isLoading} variant="destructive" className="w-full">
                  <XCircle className="h-4 w-4 mr-2" />
                  {isLoading ? "Rejeitando..." : "Rejeitar Cadastro"}
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Status do Cadastro */}
          {registration.status !== "pending" && (
            <Card>
              <CardHeader>
                <CardTitle>Status do Cadastro</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-4">
                  {getStatusBadge(registration.status)}
                  <p className="text-sm text-gray-600 mt-2">
                    {registration.status === "approved"
                      ? "Este cadastro foi aprovado e o candidato foi notificado por email."
                      : "Este cadastro foi rejeitado e o candidato foi notificado por email."}
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Links Rápidos */}
          <Card>
            <CardHeader>
              <CardTitle>Links Rápidos</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {registration.instagram && (
                <Button asChild variant="outline" className="w-full bg-transparent">
                  <a href={getInstagramUrl(registration.instagram)} target="_blank" rel="noopener noreferrer">
                    <Instagram className="h-4 w-4 mr-2 text-pink-500" />
                    Ver Instagram
                  </a>
                </Button>
              )}
              <Button asChild variant="outline" className="w-full bg-transparent">
                <a href={`mailto:${registration.email}`}>
                  <Mail className="h-4 w-4 mr-2" />
                  Enviar Email
                </a>
              </Button>
              {(registration.whatsapp || registration.phone) && (
                <Button asChild variant="outline" className="w-full bg-transparent">
                  <a
                    href={`https://wa.me/${formatWhatsApp(registration.whatsapp || registration.phone || "").replace(/\D/g, "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Phone className="h-4 w-4 mr-2" />
                    WhatsApp
                  </a>
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Informações do Sistema */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Informações do Sistema
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <label className="text-sm font-medium text-gray-700">Data de Cadastro</label>
                <p className="text-gray-900 text-sm">{formatDate(registration.created_at)}</p>
              </div>

              {registration.updated_at && registration.updated_at !== registration.created_at && (
                <div>
                  <label className="text-sm font-medium text-gray-700">Última Atualização</label>
                  <p className="text-gray-900 text-sm">{formatDate(registration.updated_at)}</p>
                </div>
              )}

              {registration.approved_at && (
                <div>
                  <label className="text-sm font-medium text-gray-700">
                    Data de {registration.status === "approved" ? "Aprovação" : "Rejeição"}
                  </label>
                  <p className="text-gray-900 text-sm">{formatDate(registration.approved_at)}</p>
                </div>
              )}

              {registration.approved_by && (
                <div>
                  <label className="text-sm font-medium text-gray-700">
                    {registration.status === "approved" ? "Aprovado por" : "Rejeitado por"}
                  </label>
                  <p className="text-gray-900 text-sm">{registration.approved_by}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
