"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import {
  Database,
  CheckCircle,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Server,
  Table,
  Settings,
  Users,
  Activity,
  Zap,
  Clock,
  Instagram,
  Mail,
} from "lucide-react"
import { toast } from "sonner"

interface DiagnosticResult {
  success: boolean
  message: string
  data?: any
  error?: string
}

export function NeonDiagnostics() {
  const [isLoading, setIsLoading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [connectionStatus, setConnectionStatus] = useState<any>(null)
  const [structureStatus, setStructureStatus] = useState<DiagnosticResult | null>(null)
  const [statsData, setStatsData] = useState<any>(null)
  const [envValidation, setEnvValidation] = useState<any>(null)

  const runDiagnostics = async () => {
    setIsLoading(true)
    setProgress(0)

    try {
      // Etapa 1: Validar variáveis de ambiente
      setProgress(20)
      const envResponse = await fetch("/api/admin/diagnostics/environment")
      const envResult = await envResponse.json()
      setEnvValidation(envResult)

      // Etapa 2: Testar conexão
      setProgress(40)
      const connectionResponse = await fetch("/api/admin/diagnostics/connection")
      const connectionResult = await connectionResponse.json()
      setConnectionStatus(connectionResult)

      if (connectionResult.summary?.success) {
        // Etapa 3: Validar estrutura
        setProgress(60)
        const structureResponse = await fetch("/api/admin/diagnostics/structure")
        const structureResult = await structureResponse.json()
        setStructureStatus(structureResult)

        // Etapa 4: Obter estatísticas
        setProgress(80)
        const statsResponse = await fetch("/api/admin/diagnostics/stats")
        const statsResult = await statsResponse.json()
        if (statsResult.success) {
          setStatsData(statsResult.data)
        }
      }

      setProgress(100)
      toast.success("Diagnóstico concluído!")
    } catch (error) {
      toast.error("Erro ao executar diagnóstico")
      console.error(error)
    } finally {
      setIsLoading(false)
      setTimeout(() => setProgress(0), 1000)
    }
  }

  const getStatusIcon = (status: boolean | null) => {
    if (status === null) return <AlertTriangle className="h-4 w-4 text-yellow-500" />
    return status ? <CheckCircle className="h-4 w-4 text-green-500" /> : <XCircle className="h-4 w-4 text-red-500" />
  }

  const getStatusBadge = (status: boolean | null, labels = ["Erro", "Sucesso", "Pendente"]) => {
    if (status === null)
      return (
        <Badge variant="outline" className="text-yellow-600">
          {labels[2]}
        </Badge>
      )
    return status ? (
      <Badge variant="outline" className="text-green-600 border-green-600">
        {labels[1]}
      </Badge>
    ) : (
      <Badge variant="outline" className="text-red-600 border-red-600">
        {labels[0]}
      </Badge>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header com botão de diagnóstico */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Diagnóstico Completo Neon Database
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button onClick={runDiagnostics} disabled={isLoading} className="w-full">
            {isLoading ? <RefreshCw className="h-4 w-4 animate-spin mr-2" /> : <Activity className="h-4 w-4 mr-2" />}
            {isLoading ? "Executando Diagnóstico..." : "Executar Diagnóstico Completo"}
          </Button>

          {isLoading && (
            <div className="space-y-2">
              <Progress value={progress} className="w-full" />
              <p className="text-sm text-center text-gray-600">
                {progress < 20 && "Iniciando diagnóstico..."}
                {progress >= 20 && progress < 40 && "Validando variáveis de ambiente..."}
                {progress >= 40 && progress < 60 && "Testando conexões..."}
                {progress >= 60 && progress < 80 && "Validando estrutura do banco..."}
                {progress >= 80 && progress < 100 && "Coletando estatísticas..."}
                {progress >= 100 && "Concluído!"}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Validação de Variáveis de Ambiente */}
      {envValidation && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Variáveis de Ambiente
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Database URLs */}
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">URLs do Banco</h4>
                {Object.entries(envValidation.envVars.database).map(([key, value]) => (
                  <div key={key} className="flex items-center gap-2">
                    {getStatusIcon(value as boolean)}
                    <code className="text-xs">{key}</code>
                  </div>
                ))}
                <p className="text-xs text-gray-600">{envValidation.summary.database}/4 configuradas</p>
              </div>

              {/* Auth Variables */}
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Neon Auth</h4>
                {Object.entries(envValidation.envVars.auth).map(([key, value]) => (
                  <div key={key} className="flex items-center gap-2">
                    {getStatusIcon(value as boolean)}
                    <code className="text-xs">{key}</code>
                  </div>
                ))}
                <p className="text-xs text-gray-600">{envValidation.summary.auth}/3 configuradas</p>
              </div>

              {/* PostgreSQL Parameters */}
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Parâmetros PG</h4>
                {Object.entries(envValidation.envVars.postgres).map(([key, value]) => (
                  <div key={key} className="flex items-center gap-2">
                    {getStatusIcon(value as boolean)}
                    <code className="text-xs">{key}</code>
                  </div>
                ))}
                <p className="text-xs text-gray-600">{envValidation.summary.postgres}/4 configuradas</p>
              </div>
            </div>

            {envValidation.recommendations.length > 0 && (
              <Alert className="mt-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Recomendações:</strong>
                  <ul className="list-disc list-inside mt-1">
                    {envValidation.recommendations.map((rec: string, idx: number) => (
                      <li key={idx} className="text-sm">
                        {rec}
                      </li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      )}

      {/* Status das Conexões */}
      {connectionStatus && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Server className="h-5 w-5" />
              Status das Conexões
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Resumo Geral */}
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-2">
                  {getStatusIcon(connectionStatus.summary?.success)}
                  <span className="font-semibold">Status Geral:</span>
                </div>
                {getStatusBadge(connectionStatus.summary?.success, ["Falha", "Conectado", "Testando"])}
              </div>

              <p className="text-sm">{connectionStatus.summary?.message}</p>

              {/* Detalhes das Conexões */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Conexão com Pooling */}
                {connectionStatus.pooled && (
                  <div className="border rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <Zap className="h-4 w-4" />
                      <span className="font-semibold text-sm">Com Pooling</span>
                      {getStatusBadge(connectionStatus.pooled.success)}
                    </div>
                    {connectionStatus.pooled.success && connectionStatus.pooled.data && (
                      <div className="text-xs space-y-1 text-gray-600">
                        <p>
                          <strong>Database:</strong> {connectionStatus.pooled.data.database_name}
                        </p>
                        <p>
                          <strong>Usuário:</strong> {connectionStatus.pooled.data.user_name}
                        </p>
                        <p>
                          <strong>Versão:</strong> {connectionStatus.pooled.data.postgres_version?.split(" ")[0]}
                        </p>
                      </div>
                    )}
                    {connectionStatus.pooled.error && (
                      <p className="text-xs text-red-600">{connectionStatus.pooled.error}</p>
                    )}
                  </div>
                )}

                {/* Conexão sem Pooling */}
                {connectionStatus.unpooled && (
                  <div className="border rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <Database className="h-4 w-4" />
                      <span className="font-semibold text-sm">Sem Pooling</span>
                      {getStatusBadge(connectionStatus.unpooled.success)}
                    </div>
                    {connectionStatus.unpooled.success && connectionStatus.unpooled.data && (
                      <div className="text-xs space-y-1 text-gray-600">
                        <p>
                          <strong>Database:</strong> {connectionStatus.unpooled.data.database_name}
                        </p>
                        <p>
                          <strong>Usuário:</strong> {connectionStatus.unpooled.data.user_name}
                        </p>
                        <p>
                          <strong>Versão:</strong> {connectionStatus.unpooled.data.postgres_version?.split(" ")[0]}
                        </p>
                      </div>
                    )}
                    {connectionStatus.unpooled.error && (
                      <p className="text-xs text-red-600">{connectionStatus.unpooled.error}</p>
                    )}
                  </div>
                )}
              </div>

              {connectionStatus.summary?.errors?.length > 0 && (
                <Alert>
                  <XCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Erros encontrados:</strong>
                    <ul className="list-disc list-inside mt-1">
                      {connectionStatus.summary.errors.map((error: string, idx: number) => (
                        <li key={idx} className="text-sm">
                          {error}
                        </li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Estrutura do Banco */}
      {structureStatus && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Table className="h-5 w-5" />
              Estrutura do Banco
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {getStatusIcon(structureStatus.success)}
                  <span>Estrutura das Tabelas:</span>
                </div>
                {getStatusBadge(structureStatus.success, ["Incompleta", "Completa", "Verificando"])}
              </div>

              <p className="text-sm">{structureStatus.message}</p>

              {structureStatus.tables && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {["user_registrations", "user_files", "system_settings", "admin_users"].map((table) => (
                    <div key={table} className="flex items-center gap-2 p-2 border rounded">
                      {getStatusIcon(structureStatus.tables.includes(table))}
                      <span className="text-xs">{table}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Campo Instagram */}
              {structureStatus.hasInstagramField !== undefined && (
                <div className="flex items-center gap-2 p-3 bg-blue-50 rounded-lg">
                  <Instagram className="h-4 w-4 text-blue-600" />
                  <span className="text-sm">Campo Instagram:</span>
                  {getStatusBadge(structureStatus.hasInstagramField, ["Ausente", "Presente", "Verificando"])}
                </div>
              )}

              {structureStatus.recommendations?.length > 0 && (
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Ações recomendadas:</strong>
                    <ul className="list-disc list-inside mt-1">
                      {structureStatus.recommendations.map((rec: string, idx: number) => (
                        <li key={idx} className="text-sm">
                          {rec}
                        </li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Estatísticas */}
      {statsData && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Estatísticas do Sistema
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Estatísticas Principais */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{statsData.total_registrations}</div>
                  <div className="text-sm text-gray-600">Total de Registros</div>
                </div>
                <div className="text-center p-3 bg-yellow-50 rounded-lg">
                  <div className="text-2xl font-bold text-yellow-600">{statsData.pending_registrations}</div>
                  <div className="text-sm text-gray-600">Pendentes</div>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">{statsData.approved_registrations}</div>
                  <div className="text-sm text-gray-600">Aprovados</div>
                </div>
                <div className="text-center p-3 bg-red-50 rounded-lg">
                  <div className="text-2xl font-bold text-red-600">{statsData.rejected_registrations}</div>
                  <div className="text-sm text-gray-600">Rejeitados</div>
                </div>
                <div className="text-center p-3 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">{statsData.total_settings}</div>
                  <div className="text-sm text-gray-600">Configurações</div>
                </div>
                <div className="text-center p-3 bg-indigo-50 rounded-lg">
                  <div className="text-2xl font-bold text-indigo-600">{statsData.total_admin_users}</div>
                  <div className="text-sm text-gray-600">Admins</div>
                </div>
              </div>

              {/* Últimos Registros */}
              {statsData.recentRegistrations?.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Últimos Registros
                  </h4>
                  <div className="space-y-2">
                    {statsData.recentRegistrations.map((reg: any) => (
                      <div key={reg.id} className="flex items-center justify-between p-2 border rounded">
                        <div className="flex items-center gap-3">
                          <div>
                            <p className="font-medium text-sm">{reg.name}</p>
                            <div className="flex items-center gap-2 text-xs text-gray-600">
                              <Mail className="h-3 w-3" />
                              {reg.email}
                              {reg.instagram && (
                                <>
                                  <Instagram className="h-3 w-3" />
                                  {reg.instagram}
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          {getStatusBadge(reg.status === "approved" ? true : reg.status === "rejected" ? false : null, [
                            "Rejeitado",
                            "Aprovado",
                            "Pendente",
                          ])}
                          <p className="text-xs text-gray-500 mt-1">
                            {new Date(reg.created_at).toLocaleDateString("pt-BR")}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
