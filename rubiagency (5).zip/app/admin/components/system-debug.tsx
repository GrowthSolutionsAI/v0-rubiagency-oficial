"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { testDatabase, forceRevalidate } from "@/app/admin/actions"
import { Database, RefreshCw, CheckCircle, XCircle, AlertCircle } from "lucide-react"
import { toast } from "sonner"

export function SystemDebug() {
  const [isTestingDb, setIsTestingDb] = useState(false)
  const [isRevalidating, setIsRevalidating] = useState(false)
  const [dbStatus, setDbStatus] = useState<"unknown" | "connected" | "disconnected">("unknown")

  const handleTestDatabase = async () => {
    setIsTestingDb(true)
    try {
      const result = await testDatabase()
      setDbStatus(result.success ? "connected" : "disconnected")
      toast(result.success ? "✅ Banco conectado!" : "❌ Banco desconectado!", {
        description: result.message,
      })
    } catch (error) {
      setDbStatus("disconnected")
      toast.error("Erro ao testar banco de dados")
    } finally {
      setIsTestingDb(false)
    }
  }

  const handleForceRevalidate = async () => {
    setIsRevalidating(true)
    try {
      const result = await forceRevalidate()
      toast(result.success ? "✅ Páginas atualizadas!" : "❌ Erro ao atualizar!", {
        description: result.message,
      })
    } catch (error) {
      toast.error("Erro ao atualizar páginas")
    } finally {
      setIsRevalidating(false)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "connected":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "disconnected":
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <AlertCircle className="h-4 w-4 text-yellow-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "connected":
        return (
          <Badge variant="outline" className="text-green-600 border-green-600">
            Conectado
          </Badge>
        )
      case "disconnected":
        return (
          <Badge variant="outline" className="text-red-600 border-red-600">
            Desconectado
          </Badge>
        )
      default:
        return (
          <Badge variant="outline" className="text-yellow-600 border-yellow-600">
            Desconhecido
          </Badge>
        )
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" />
          Debug do Sistema
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {getStatusIcon(dbStatus)}
            <span>Status do Banco de Dados:</span>
            {getStatusBadge(dbStatus)}
          </div>
          <Button onClick={handleTestDatabase} disabled={isTestingDb} variant="outline" size="sm">
            {isTestingDb ? <RefreshCw className="h-4 w-4 animate-spin mr-2" /> : <Database className="h-4 w-4 mr-2" />}
            Testar Conexão
          </Button>
        </div>

        <div className="flex items-center justify-between">
          <span>Forçar Atualização das Páginas:</span>
          <Button onClick={handleForceRevalidate} disabled={isRevalidating} variant="outline" size="sm">
            {isRevalidating ? (
              <RefreshCw className="h-4 w-4 animate-spin mr-2" />
            ) : (
              <RefreshCw className="h-4 w-4 mr-2" />
            )}
            Atualizar
          </Button>
        </div>

        <div className="text-sm text-gray-600 space-y-1">
          <p>
            <strong>Ambiente:</strong> {process.env.NODE_ENV || "development"}
          </p>
          <p>
            <strong>Timestamp:</strong> {new Date().toLocaleString("pt-BR")}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
