"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Mail, CheckCircle, AlertCircle, Send, RefreshCw } from "lucide-react"

interface EmailStatus {
  configured: boolean
  provider: string
  message: string
  status: "ready" | "demo" | "error"
  details?: any
}

export function EmailStatusCard() {
  const [emailStatus, setEmailStatus] = useState<EmailStatus | null>(null)
  const [testEmail, setTestEmail] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isTesting, setIsTesting] = useState(false)
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null)

  // Carregar status do email
  const loadEmailStatus = async () => {
    try {
      setIsLoading(true)
      const response = await fetch("/api/admin/email/status")
      const data = await response.json()
      setEmailStatus(data)
    } catch (error) {
      console.error("Erro ao carregar status do email:", error)
      setEmailStatus({
        configured: false,
        provider: "Error",
        message: "Erro ao verificar configuração",
        status: "error",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Testar envio de email
  const testEmailSending = async () => {
    if (!testEmail) {
      setTestResult({ success: false, message: "Digite um email para teste" })
      return
    }

    try {
      setIsTesting(true)
      setTestResult(null)

      const response = await fetch("/api/admin/email/test", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email: testEmail }),
      })

      const data = await response.json()
      setTestResult({
        success: data.success,
        message: data.message,
      })

      if (data.success) {
        setTestEmail("")
      }
    } catch (error) {
      console.error("Erro no teste de email:", error)
      setTestResult({
        success: false,
        message: "Erro ao testar email",
      })
    } finally {
      setIsTesting(false)
    }
  }

  useEffect(() => {
    loadEmailStatus()
  }, [])

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Status do Email
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        </CardContent>
      </Card>
    )
  }

  const getStatusBadge = () => {
    if (!emailStatus) return null

    switch (emailStatus.status) {
      case "ready":
        return (
          <Badge className="bg-green-500">
            <CheckCircle className="h-3 w-3 mr-1" />
            Configurado
          </Badge>
        )
      case "demo":
        return (
          <Badge variant="secondary">
            <AlertCircle className="h-3 w-3 mr-1" />
            Modo Demo
          </Badge>
        )
      case "error":
        return (
          <Badge variant="destructive">
            <AlertCircle className="h-3 w-3 mr-1" />
            Erro
          </Badge>
        )
      default:
        return <Badge variant="outline">Desconhecido</Badge>
    }
  }

  const getStatusColor = () => {
    if (!emailStatus) return "text-gray-500"

    switch (emailStatus.status) {
      case "ready":
        return "text-green-600"
      case "demo":
        return "text-yellow-600"
      case "error":
        return "text-red-600"
      default:
        return "text-gray-500"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Status do Email
          </div>
          <Button variant="ghost" size="sm" onClick={loadEmailStatus} disabled={isLoading}>
            <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
          </Button>
        </CardTitle>
        <CardDescription>Configuração e teste do sistema de email</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {emailStatus && (
          <>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Provedor: {emailStatus.provider}</p>
                <p className={`text-sm ${getStatusColor()}`}>{emailStatus.message}</p>
              </div>
              {getStatusBadge()}
            </div>

            {emailStatus.details && (
              <div className="text-xs text-gray-500 space-y-1">
                <p>Resend: {emailStatus.details.hasResend ? "✅" : "❌"}</p>
                <p>SendGrid: {emailStatus.details.hasSendGrid ? "✅" : "❌"}</p>
                <p>Email From: {emailStatus.details.emailFrom}</p>
              </div>
            )}

            <div className="border-t pt-4">
              <Label htmlFor="test-email" className="text-sm font-medium">
                Testar Envio de Email
              </Label>
              <div className="flex gap-2 mt-2">
                <Input
                  id="test-email"
                  type="email"
                  placeholder="Digite um email para teste"
                  value={testEmail}
                  onChange={(e) => setTestEmail(e.target.value)}
                  disabled={isTesting}
                />
                <Button onClick={testEmailSending} disabled={isTesting || !testEmail} size="sm">
                  {isTesting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            {testResult && (
              <Alert variant={testResult.success ? "default" : "destructive"}>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{testResult.message}</AlertDescription>
              </Alert>
            )}
          </>
        )}
      </CardContent>
    </Card>
  )
}
