"use client"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Eye, CheckCircle, XCircle, Clock, Mail, Phone, User, Users } from "lucide-react"
import Link from "next/link"
import { formatDistanceToNow } from "date-fns"
import { ptBR } from "date-fns/locale"

interface Registration {
  id: number
  name: string
  email: string
  phone?: string
  age: number
  subject?: string
  experience?: string
  message: string
  status: "pending" | "approved" | "rejected"
  partner_id?: number
  partner_code?: string
  partner_name?: string
  created_at: string
  approved_at?: string
  approved_by?: string
}

interface RegistrationsListProps {
  registrations: Registration[]
}

export function RegistrationsList({ registrations }: RegistrationsListProps) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="text-yellow-600 border-yellow-600">
            <Clock className="h-3 w-3 mr-1" />
            Pendente
          </Badge>
        )
      case "approved":
        return (
          <Badge variant="outline" className="text-green-600 border-green-600">
            <CheckCircle className="h-3 w-3 mr-1" />
            Aprovado
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="outline" className="text-red-600 border-red-600">
            <XCircle className="h-3 w-3 mr-1" />
            Reprovado
          </Badge>
        )
      default:
        return <Badge variant="outline">Desconhecido</Badge>
    }
  }

  if (registrations.length === 0) {
    return (
      <Card>
        <CardContent className="text-center py-12">
          <div className="text-gray-500">
            <User className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-medium mb-2">Nenhum cadastro encontrado</h3>
            <p>Não há cadastros para exibir no momento.</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="grid gap-6">
      {registrations.map((registration) => (
        <Card key={registration.id} className="hover:shadow-md transition-shadow">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <CardTitle className="text-lg">{registration.name}</CardTitle>
                  {/* Tag do Parceiro */}
                  {registration.partner_code && (
                    <Badge variant="outline" className="text-blue-600 border-blue-600 bg-blue-50">
                      <Users className="h-3 w-3 mr-1" />
                      {registration.partner_name || registration.partner_code}
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <Mail className="h-4 w-4" />
                    {registration.email}
                  </div>
                  {registration.phone && (
                    <div className="flex items-center gap-1">
                      <Phone className="h-4 w-4" />
                      {registration.phone}
                    </div>
                  )}
                  <div className="flex items-center gap-1">
                    <User className="h-4 w-4" />
                    {registration.age} anos
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {getStatusBadge(registration.status)}
                <Button asChild variant="outline" size="sm">
                  <Link href={`/admin/registrations/details/${registration.id}`}>
                    <Eye className="h-4 w-4 mr-2" />
                    Ver Detalhes
                  </Link>
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {registration.subject && (
                <div>
                  <span className="text-sm font-medium text-gray-700">Assunto: </span>
                  <span className="text-sm text-gray-600">{registration.subject}</span>
                </div>
              )}
              {registration.experience && (
                <div>
                  <span className="text-sm font-medium text-gray-700">Experiência: </span>
                  <span className="text-sm text-gray-600">{registration.experience}</span>
                </div>
              )}
              <div>
                <span className="text-sm font-medium text-gray-700">Mensagem: </span>
                <p className="text-sm text-gray-600 mt-1 line-clamp-2">{registration.message}</p>
              </div>
              {/* Informação do Parceiro */}
              {registration.partner_code && (
                <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="h-4 w-4 text-blue-600" />
                    <span className="text-blue-800 font-medium">
                      Indicado por: {registration.partner_name || registration.partner_code}
                    </span>
                  </div>
                  <p className="text-xs text-blue-600 mt-1">Cadastro via link de parceiro</p>
                </div>
              )}
              <div className="flex items-center justify-between text-xs text-gray-500 pt-2 border-t">
                <span>
                  Enviado{" "}
                  {formatDistanceToNow(new Date(registration.created_at), {
                    addSuffix: true,
                    locale: ptBR,
                  })}
                </span>
                {registration.approved_at && (
                  <span>
                    {registration.status === "approved" ? "Aprovado" : "Reprovado"}{" "}
                    {formatDistanceToNow(new Date(registration.approved_at), {
                      addSuffix: true,
                      locale: ptBR,
                    })}
                  </span>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
