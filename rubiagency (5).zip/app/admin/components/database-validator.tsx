"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import {
  Database,
  CheckCircle,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Trash2,
  TestTube,
  Activity,
  Zap,
  FileText,
  Settings,
  Plus,
  Edit,
  Search,
} from "lucide-react"
import { toast } from "sonner"

interface TestResult {
  success: boolean
  message: string
  data?: any
  error?: string
  duration?: number
}

export function DatabaseValidator() {
  const [isLoading, setIsLoading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [testResults, setTestResults] = useState<{
    reset: TestResult | null
    connection: TestResult | null
    crud: TestResult | null
    performance: TestResult | null
    integrity: TestResult | null
  }>({
    reset: null,
    connection: null,
    crud: null,
    performance: null,
    integrity: null,
  })

  const runCompleteValidation = async () => {
    setIsLoading(true)
    setProgress(0)
    setTestResults({
      reset: null,
      connection: null,
      crud: null,
      performance: null,
      integrity: null,
    })

    try {
      // Etapa 1: Reset do banco
      setProgress(10)
      toast.info("Executando reset do banco...")
      const resetResponse = await fetch("/api/admin/database/reset", {
        method: "POST",
      })
      const resetResult = await resetResponse.json()
      setTestResults((prev) => ({ ...prev, reset: resetResult }))

      if (!resetResult.success) {
        toast.error("Falha no reset do banco")
        return
      }

      // Etapa 2: Teste de conexão
      setProgress(30)
      toast.info("Testando conexão...")
      const connectionResponse = await fetch("/api/admin/database/test-connection")
      const connectionResult = await connectionResponse.json()
      setTestResults((prev) => ({ ...prev, connection: connectionResult }))

      // Etapa 3: Teste CRUD
      setProgress(50)
      toast.info("Testando operações CRUD...")
      const crudResponse = await fetch("/api/admin/database/test-crud")
      const crudResult = await crudResponse.json()
      setTestResults((prev) => ({ ...prev, crud: crudResult }))

      // Etapa 4: Teste de performance
      setProgress(70)
      toast.info("Testando performance...")
      const performanceResponse = await fetch("/api/admin/database/test-performance")
      const performanceResult = await performanceResponse.json()
      setTestResults((prev) => ({ ...prev, performance: performanceResult }))

      // Etapa 5: Teste de integridade
      setProgress(90)
      toast.info("Validando integridade...")
      const integrityResponse = await fetch("/api/admin/database/test-integrity")
      const integrityResult = await integrityResponse.json()
      setTestResults((prev) => ({ ...prev, integrity: integrityResult }))

      setProgress(100)
      toast.success("Validação completa concluída!")
    } catch (error) {
      toast.error("Erro durante a validação")
      console.error(error)
    } finally {
      setIsLoading(false)
      setTimeout(() => setProgress(0), 1000)
    }
  }

  const getStatusIcon = (result: TestResult | null) => {
    if (!result) return <AlertTriangle className="h-4 w-4 text-yellow-500" />
    return result.success ? (
      <CheckCircle className="h-4 w-4 text-green-500" />
    ) : (
      <XCircle className="h-4 w-4 text-red-500" />
    )
  }

  const getStatusBadge = (result: TestResult | null) => {
    if (!result)
      return (
        <Badge variant="outline" className="text-yellow-600">
          Pendente
        </Badge>
      )
    return result.success ? (
      <Badge variant="outline" className="text-green-600 border-green-600">
        Sucesso
      </Badge>
    ) : (
      <Badge variant="outline" className="text-red-600 border-red-600">
        Falha
      </Badge>
    )
  }

  const formatDuration = (duration?: number) => {
    if (!duration) return ""
    return duration < 1000 ? `${duration}ms` : `${(duration / 1000).toFixed(2)}s`
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Validação Completa do Banco de Dados
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>⚠️ ATENÇÃO:</strong> Este processo irá remover TODOS os dados de cadastros existentes no banco de
              dados. Esta ação não pode ser desfeita.
            </AlertDescription>
          </Alert>

          <Button onClick={runCompleteValidation} disabled={isLoading} className="w-full" variant="destructive">
            {isLoading ? <RefreshCw className="h-4 w-4 animate-spin mr-2" /> : <Trash2 className="h-4 w-4 mr-2" />}
            {isLoading ? "Executando Validação..." : "Reset Completo + Validação"}
          </Button>

          {isLoading && (
            <div className="space-y-2">
              <Progress value={progress} className="w-full" />
              <p className="text-sm text-center text-gray-600">
                {progress < 20 && "Resetando banco de dados..."}
                {progress >= 20 && progress < 40 && "Testando conexão..."}
                {progress >= 40 && progress < 60 && "Testando operações CRUD..."}
                {progress >= 60 && progress < 80 && "Testando performance..."}
                {progress >= 80 && progress < 100 && "Validando integridade..."}
                {progress >= 100 && "Concluído!"}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Resultados dos Testes */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Reset do Banco */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-sm">
              <Trash2 className="h-4 w-4" />
              Reset do Banco
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                {getStatusIcon(testResults.reset)}
                {getStatusBadge(testResults.reset)}
              </div>

              {testResults.reset && (
                <div className="space-y-2">
                  <p className="text-sm">{testResults.reset.message}</p>
                  {testResults.reset.duration && (
                    <p className="text-xs text-gray-500">Tempo: {formatDuration(testResults.reset.duration)}</p>
                  )}
                  {testResults.reset.data && (
                    <div className="text-xs bg-gray-50 p-2 rounded">
                      <p>Registros removidos: {testResults.reset.data.deletedRegistrations || 0}</p>
                      <p>Arquivos removidos: {testResults.reset.data.deletedFiles || 0}</p>
                      <p>Configurações: {testResults.reset.data.settingsCount || 0}</p>
                    </div>
                  )}
                  {testResults.reset.error && <p className="text-xs text-red-600">{testResults.reset.error}</p>}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Teste de Conexão */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-sm">
              <Zap className="h-4 w-4" />
              Conexão
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                {getStatusIcon(testResults.connection)}
                {getStatusBadge(testResults.connection)}
              </div>

              {testResults.connection && (
                <div className="space-y-2">
                  <p className="text-sm">{testResults.connection.message}</p>
                  {testResults.connection.duration && (
                    <p className="text-xs text-gray-500">Latência: {formatDuration(testResults.connection.duration)}</p>
                  )}
                  {testResults.connection.data && (
                    <div className="text-xs bg-gray-50 p-2 rounded">
                      <p>Database: {testResults.connection.data.database}</p>
                      <p>Usuário: {testResults.connection.data.user}</p>
                      <p>Versão: {testResults.connection.data.version}</p>
                    </div>
                  )}
                  {testResults.connection.error && (
                    <p className="text-xs text-red-600">{testResults.connection.error}</p>
                  )}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Teste CRUD */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-sm">
              <TestTube className="h-4 w-4" />
              Operações CRUD
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                {getStatusIcon(testResults.crud)}
                {getStatusBadge(testResults.crud)}
              </div>

              {testResults.crud && (
                <div className="space-y-2">
                  <p className="text-sm">{testResults.crud.message}</p>
                  {testResults.crud.duration && (
                    <p className="text-xs text-gray-500">Tempo total: {formatDuration(testResults.crud.duration)}</p>
                  )}
                  {testResults.crud.data && (
                    <div className="text-xs bg-gray-50 p-2 rounded space-y-1">
                      <div className="flex items-center gap-1">
                        <Plus className="h-3 w-3 text-green-600" />
                        <span>Create: {testResults.crud.data.create ? "✓" : "✗"}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Search className="h-3 w-3 text-blue-600" />
                        <span>Read: {testResults.crud.data.read ? "✓" : "✗"}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Edit className="h-3 w-3 text-yellow-600" />
                        <span>Update: {testResults.crud.data.update ? "✓" : "✗"}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Trash2 className="h-3 w-3 text-red-600" />
                        <span>Delete: {testResults.crud.data.delete ? "✓" : "✗"}</span>
                      </div>
                    </div>
                  )}
                  {testResults.crud.error && <p className="text-xs text-red-600">{testResults.crud.error}</p>}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Teste de Performance */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-sm">
              <Activity className="h-4 w-4" />
              Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                {getStatusIcon(testResults.performance)}
                {getStatusBadge(testResults.performance)}
              </div>

              {testResults.performance && (
                <div className="space-y-2">
                  <p className="text-sm">{testResults.performance.message}</p>
                  {testResults.performance.data && (
                    <div className="text-xs bg-gray-50 p-2 rounded space-y-1">
                      <p>Query simples: {formatDuration(testResults.performance.data.simpleQuery)}</p>
                      <p>Query complexa: {formatDuration(testResults.performance.data.complexQuery)}</p>
                      <p>Inserção: {formatDuration(testResults.performance.data.insertQuery)}</p>
                      <p>
                        Performance:{" "}
                        {testResults.performance.data.rating === "excellent"
                          ? "🟢 Excelente"
                          : testResults.performance.data.rating === "good"
                            ? "🟡 Boa"
                            : "🔴 Lenta"}
                      </p>
                    </div>
                  )}
                  {testResults.performance.error && (
                    <p className="text-xs text-red-600">{testResults.performance.error}</p>
                  )}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Teste de Integridade */}
      {testResults.integrity && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Integridade do Banco
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {getStatusIcon(testResults.integrity)}
                  <span>Validação de Integridade:</span>
                </div>
                {getStatusBadge(testResults.integrity)}
              </div>

              <p className="text-sm">{testResults.integrity.message}</p>

              {testResults.integrity.data && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm">Tabelas</h4>
                    {testResults.integrity.data.tables?.map((table: any) => (
                      <div key={table.name} className="flex items-center gap-2 text-xs">
                        <CheckCircle className="h-3 w-3 text-green-500" />
                        <span>{table.name}</span>
                        <span className="text-gray-500">({table.rows} registros)</span>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm">Índices</h4>
                    {testResults.integrity.data.indexes?.map((index: any) => (
                      <div key={index.name} className="flex items-center gap-2 text-xs">
                        <CheckCircle className="h-3 w-3 text-green-500" />
                        <span>{index.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {testResults.integrity.error && (
                <Alert>
                  <XCircle className="h-4 w-4" />
                  <AlertDescription>{testResults.integrity.error}</AlertDescription>
                </Alert>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Resumo Final */}
      {Object.values(testResults).some((result) => result !== null) && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Resumo da Validação
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {Object.entries(testResults).map(([key, result]) => {
                if (!result) return null
                return (
                  <div key={key} className="flex items-center justify-between p-2 border rounded">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(result)}
                      <span className="capitalize text-sm">{key.replace(/([A-Z])/g, " $1")}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {result.duration && (
                        <span className="text-xs text-gray-500">{formatDuration(result.duration)}</span>
                      )}
                      {getStatusBadge(result)}
                    </div>
                  </div>
                )
              })}

              {Object.values(testResults).every((result) => result?.success) && (
                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>🎉 Parabéns!</strong> Todos os testes passaram com sucesso. O banco de dados está
                    funcionando perfeitamente e pronto para uso em produção.
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
