"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { Database, CheckCircle, XCircle, AlertCircle, RefreshCw, Eye, EyeOff, Copy, Server, Clock } from "lucide-react"

interface DiagnosticResult {
  test: string
  status: "success" | "error" | "warning"
  message: string
  details?: any
  duration?: number
}

interface DatabaseInfo {
  url: string
  host: string
  database: string
  user: string
  ssl: boolean
  pooled: boolean
}

export function DatabaseDiagnostics() {
  const [results, setResults] = useState<DiagnosticResult[]>([])
  const [isRunning, setIsRunning] = useState(false)
  const [progress, setProgress] = useState(0)
  const [showEnvVars, setShowEnvVars] = useState(false)
  const [databaseInfo, setDatabaseInfo] = useState<DatabaseInfo | null>(null)
  const [lastRun, setLastRun] = useState<Date | null>(null)

  const runDiagnostics = async () => {
    setIsRunning(true)
    setProgress(0)
    setResults([])

    const tests = [
      { name: "environment", label: "Variáveis de Ambiente" },
      { name: "connection", label: "Teste de Conexão" },
      { name: "structure", label: "Estrutura do Banco" },
      { name: "stats", label: "Estatísticas" },
    ]

    for (let i = 0; i < tests.length; i++) {
      const test = tests[i]
      setProgress(((i + 1) / tests.length) * 100)

      try {
        const response = await fetch(`/api/admin/diagnostics/${test.name}`)
        const data = await response.json()

        setResults((prev) => [
          ...prev,
          {
            test: test.label,
            status: data.success ? "success" : "error",
            message: data.message || data.error || "Teste concluído",
            details: data.data,
            duration: data.duration,
          },
        ])

        if (test.name === "environment" && data.data) {
          setDatabaseInfo(data.data.databaseInfo)
        }
      } catch (error) {
        setResults((prev) => [
          ...prev,
          {
            test: test.label,
            status: "error",
            message: `Erro ao executar teste: ${error.message}`,
          },
        ])
      }

      // Pequena pausa para mostrar o progresso
      await new Promise((resolve) => setTimeout(resolve, 500))
    }

    setLastRun(new Date())
    setIsRunning(false)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "warning":
        return <AlertCircle className="h-4 w-4 text-yellow-500" />
      case "error":
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "success":
        return "bg-green-100 text-green-800 border-green-200"
      case "warning":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "error":
        return "bg-red-100 text-red-800 border-red-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const maskUrl = (url: string) => {
    if (!url) return "Não configurada"
    const parts = url.split("@")
    if (parts.length === 2) {
      const [credentials, hostAndDb] = parts
      const maskedCredentials = credentials.replace(/:[^:]*$/, ":****")
      return `${maskedCredentials}@${hostAndDb}`
    }
    return url.substring(0, 30) + "..."
  }

  useEffect(() => {
    runDiagnostics()
  }, [])

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Database className="h-5 w-5" />
            Diagnóstico do Banco de Dados
          </h3>
          {lastRun && <p className="text-sm text-muted-foreground">Última execução: {lastRun.toLocaleTimeString()}</p>}
        </div>
        <Button onClick={runDiagnostics} disabled={isRunning} variant="outline">
          <RefreshCw className={`h-4 w-4 mr-2 ${isRunning ? "animate-spin" : ""}`} />
          {isRunning ? "Executando..." : "Executar Diagnóstico"}
        </Button>
      </div>

      {/* Progress */}
      {isRunning && (
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Executando diagnósticos...</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Database Info */}
      {databaseInfo && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Server className="h-4 w-4" />
              Informações da Conexão
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700">Host</label>
                <div className="flex items-center gap-2 mt-1">
                  <code className="text-sm bg-gray-100 px-2 py-1 rounded">{databaseInfo.host}</code>
                  <Button size="sm" variant="ghost" onClick={() => copyToClipboard(databaseInfo.host)}>
                    <Copy className="h-3 w-3" />
                  </Button>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700">Database</label>
                <div className="flex items-center gap-2 mt-1">
                  <code className="text-sm bg-gray-100 px-2 py-1 rounded">{databaseInfo.database}</code>
                  <Button size="sm" variant="ghost" onClick={() => copyToClipboard(databaseInfo.database)}>
                    <Copy className="h-3 w-3" />
                  </Button>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700">Usuário</label>
                <div className="flex items-center gap-2 mt-1">
                  <code className="text-sm bg-gray-100 px-2 py-1 rounded">{databaseInfo.user}</code>
                  <Button size="sm" variant="ghost" onClick={() => copyToClipboard(databaseInfo.user)}>
                    <Copy className="h-3 w-3" />
                  </Button>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700">SSL</label>
                <div className="mt-1">
                  <Badge variant={databaseInfo.ssl ? "default" : "secondary"}>
                    {databaseInfo.ssl ? "Habilitado" : "Desabilitado"}
                  </Badge>
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2 mb-2">
                <label className="text-sm font-medium text-gray-700">URL de Conexão</label>
                <Button size="sm" variant="ghost" onClick={() => setShowEnvVars(!showEnvVars)}>
                  {showEnvVars ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                </Button>
              </div>
              <div className="flex items-center gap-2">
                <code className="text-sm bg-gray-100 px-2 py-1 rounded flex-1">
                  {showEnvVars ? databaseInfo.url : maskUrl(databaseInfo.url)}
                </code>
                <Button size="sm" variant="ghost" onClick={() => copyToClipboard(databaseInfo.url)}>
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Results */}
      <div className="space-y-4">
        {results.map((result, index) => (
          <Card key={index} className={`border-l-4 ${getStatusColor(result.status)}`}>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center justify-between text-base">
                <div className="flex items-center gap-2">
                  {getStatusIcon(result.status)}
                  {result.test}
                </div>
                {result.duration && (
                  <Badge variant="outline" className="text-xs">
                    <Clock className="h-3 w-3 mr-1" />
                    {result.duration}ms
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-sm mb-3">{result.message}</p>

              {result.details && (
                <div className="bg-gray-50 p-3 rounded-lg">
                  <details className="text-xs">
                    <summary className="cursor-pointer font-medium mb-2">Ver detalhes</summary>
                    <pre className="whitespace-pre-wrap overflow-x-auto">{JSON.stringify(result.details, null, 2)}</pre>
                  </details>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recommendations */}
      {results.some((r) => r.status === "error") && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <strong>Problemas detectados!</strong> Siga estas recomendações:
            <ul className="list-disc list-inside mt-2 space-y-1">
              <li>Verifique se a variável DATABASE_URL está configurada corretamente</li>
              <li>Execute os scripts SQL na ordem: 001, 002, 003</li>
              <li>Confirme se o banco Neon está ativo e acessível</li>
              <li>Verifique as permissões do usuário no banco</li>
            </ul>
          </AlertDescription>
        </Alert>
      )}
    </div>
  )
}
