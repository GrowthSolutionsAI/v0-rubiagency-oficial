"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  User,
  Mail,
  Phone,
  Percent,
  Users,
  DollarSign,
  Link,
  Copy,
  RefreshCw,
  AlertCircle,
  CheckCircle,
} from "lucide-react"

interface Partner {
  id: number
  name: string
  email: string
  phone: string
  commission_rate: number
  status: string
  referral_code: string
  total_referrals: number
  total_commission: number
  approved_referrals?: number
  referral_link?: string
  created_at: string
  updated_at: string
}

export default function PartnerDetailsPage() {
  const params = useParams()
  const [partner, setPartner] = useState<Partner | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)

  const loadPartner = async () => {
    try {
      setLoading(true)
      setError(null)

      const response = await fetch(`/api/admin/partners/${params.id}`)

      if (!response.ok) {
        throw new Error(`Erro ${response.status}: ${response.statusText}`)
      }

      const data = await response.json()

      if (data.error) {
        throw new Error(data.error)
      }

      setPartner(data)
    } catch (err) {
      console.error("❌ Erro ao carregar parceiro:", err)
      setError(err instanceof Error ? err.message : "Erro desconhecido")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (params.id) {
      loadPartner()
    }
  }, [params.id])

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error("Erro ao copiar:", err)
    }
  }

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="mb-6">
          <Skeleton className="h-8 w-64 mb-2" />
          <Skeleton className="h-4 w-96" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-4 w-20 mb-2" />
                <Skeleton className="h-8 w-16" />
              </CardContent>
            </Card>
          ))}
        </div>

        <Card>
          <CardContent className="p-6">
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center space-x-4">
                  <Skeleton className="h-5 w-5" />
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-4 w-48" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (error) {
    return (
      <div className="container mx-auto p-6">
        <Alert className="border-red-200 bg-red-50">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-700">
            <div className="mb-2">
              <strong>Erro ao carregar parceiro:</strong>
            </div>
            <div className="mb-4">{error}</div>
            <Button
              onClick={loadPartner}
              size="sm"
              variant="outline"
              className="border-red-200 text-red-700 hover:bg-red-100 bg-transparent"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Tentar Novamente
            </Button>
          </AlertDescription>
        </Alert>
      </div>
    )
  }

  if (!partner) {
    return (
      <div className="container mx-auto p-6">
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>Parceiro não encontrado.</AlertDescription>
        </Alert>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{partner.name}</h1>
            <p className="text-gray-600">Detalhes do parceiro #{partner.id}</p>
          </div>
          <Badge
            variant={partner.status === "active" ? "default" : "secondary"}
            className={partner.status === "active" ? "bg-green-100 text-green-800" : ""}
          >
            {partner.status === "active" ? "Ativo" : "Inativo"}
          </Badge>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Users className="h-8 w-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total de Indicações</p>
                <p className="text-2xl font-bold text-gray-900">{partner.total_referrals}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <CheckCircle className="h-8 w-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Aprovadas</p>
                <p className="text-2xl font-bold text-gray-900">{partner.approved_referrals || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <DollarSign className="h-8 w-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Comissão</p>
                <p className="text-2xl font-bold text-gray-900">R$ {partner.total_commission.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Percent className="h-8 w-8 text-purple-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Taxa de Comissão</p>
                <p className="text-2xl font-bold text-gray-900">{partner.commission_rate}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Partner Details */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <User className="w-5 h-5 mr-2" />
            Informações do Parceiro
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-center space-x-3">
                <User className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600">Nome</p>
                  <p className="font-medium">{partner.name}</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600">Email</p>
                  <p className="font-medium">{partner.email}</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600">Telefone</p>
                  <p className="font-medium">{partner.phone}</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Link className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600">Código de Referência</p>
                  <p className="font-medium font-mono">{partner.referral_code}</p>
                </div>
              </div>
            </div>

            {partner.referral_link && (
              <div className="border-t pt-6">
                <p className="text-sm text-gray-600 mb-2">Link de Indicação</p>
                <div className="flex items-center space-x-2">
                  <div className="flex-1 bg-gray-50 p-3 rounded-md border">
                    <p className="font-mono text-sm text-gray-700 break-all">{partner.referral_link}</p>
                  </div>
                  <Button
                    onClick={() => copyToClipboard(partner.referral_link!)}
                    size="sm"
                    variant="outline"
                    className={copied ? "bg-green-50 border-green-200 text-green-700" : ""}
                  >
                    <Copy className="w-4 h-4 mr-1" />
                    {copied ? "Copiado!" : "Copiar"}
                  </Button>
                </div>
              </div>
            )}

            <div className="border-t pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                <div>
                  <span className="font-medium">Criado em:</span> {new Date(partner.created_at).toLocaleString("pt-BR")}
                </div>
                <div>
                  <span className="font-medium">Atualizado em:</span>{" "}
                  {new Date(partner.updated_at).toLocaleString("pt-BR")}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
