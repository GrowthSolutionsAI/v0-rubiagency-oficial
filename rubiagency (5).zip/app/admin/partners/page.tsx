"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Users, UserCheck, UserX, DollarSign, Search, Plus, Eye, RefreshCw, AlertCircle } from "lucide-react"

interface Partner {
  id: number
  name: string
  email: string
  phone: string
  commission_rate: number
  status: string
  referral_code: string
  total_referrals: number
  total_commission: number
  created_at: string
}

interface PartnerStats {
  total: number
  active: number
  inactive: number
  totalCommission: number
  totalReferrals: number
}

export default function PartnersPage() {
  const [partners, setPartners] = useState<Partner[]>([])
  const [stats, setStats] = useState<PartnerStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState("")

  const loadPartners = async () => {
    try {
      setLoading(true)
      setError(null)

      const response = await fetch("/api/admin/partners")

      if (!response.ok) {
        throw new Error(`Erro ${response.status}: ${response.statusText}`)
      }

      const data = await response.json()

      if (data.error) {
        throw new Error(data.error)
      }

      setPartners(data.partners || [])
      setStats(
        data.stats || {
          total: 0,
          active: 0,
          inactive: 0,
          totalCommission: 0,
          totalReferrals: 0,
        },
      )
    } catch (err) {
      console.error("❌ Erro ao carregar parceiros:", err)
      setError(err instanceof Error ? err.message : "Erro desconhecido")
      // Set default empty state
      setPartners([])
      setStats({
        total: 0,
        active: 0,
        inactive: 0,
        totalCommission: 0,
        totalReferrals: 0,
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadPartners()
  }, [])

  const filteredPartners = partners.filter(
    (partner) =>
      partner.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      partner.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      partner.referral_code?.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Safe number formatting function
  const formatNumber = (value: number | undefined | null): string => {
    if (value === undefined || value === null || isNaN(value)) {
      return "0"
    }
    return value.toLocaleString()
  }

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="mb-6">
          <Skeleton className="h-8 w-64 mb-2" />
          <Skeleton className="h-4 w-96" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-4 w-20 mb-2" />
                <Skeleton className="h-8 w-16" />
              </CardContent>
            </Card>
          ))}
        </div>

        <Card>
          <CardContent className="p-6">
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center justify-between p-4 border rounded">
                  <div className="flex items-center space-x-4">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div>
                      <Skeleton className="h-4 w-32 mb-2" />
                      <Skeleton className="h-3 w-48" />
                    </div>
                  </div>
                  <Skeleton className="h-6 w-16" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (error) {
    return (
      <div className="container mx-auto p-6">
        <Alert className="border-red-200 bg-red-50">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-700">
            <div className="mb-2">
              <strong>Erro ao carregar parceiros:</strong>
            </div>
            <div className="mb-4">{error}</div>
            <Button
              onClick={loadPartners}
              size="sm"
              variant="outline"
              className="border-red-200 text-red-700 hover:bg-red-100 bg-transparent"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Tentar Novamente
            </Button>
          </AlertDescription>
        </Alert>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Sistema de Parceiros</h1>
          <p className="text-gray-600">Gerencie parceiros e acompanhe suas indicações</p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Novo Parceiro
        </Button>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Users className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total de Parceiros</p>
                  <p className="text-2xl font-bold text-gray-900">{formatNumber(stats.total)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <UserCheck className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Parceiros Ativos</p>
                  <p className="text-2xl font-bold text-gray-900">{formatNumber(stats.active)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <UserX className="h-8 w-8 text-gray-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Parceiros Inativos</p>
                  <p className="text-2xl font-bold text-gray-900">{formatNumber(stats.inactive)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <DollarSign className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Comissões</p>
                  <p className="text-2xl font-bold text-gray-900">R$ {formatNumber(stats.totalCommission)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Search */}
      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Buscar por nome, email ou código..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Partners List */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Parceiros ({filteredPartners.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredPartners.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              {searchTerm ? "Nenhum parceiro encontrado" : "Nenhum parceiro cadastrado"}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredPartners.map((partner) => (
                <div
                  key={partner.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-gradient-to-r from-red-500 to-red-600 rounded-full flex items-center justify-center text-white font-medium">
                      {partner.name?.charAt(0)?.toUpperCase() || "?"}
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">{partner.name || "Nome não informado"}</h3>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <span>{partner.email || "Email não informado"}</span>
                        <span>•</span>
                        <span>Código: {partner.referral_code || "N/A"}</span>
                        <span>•</span>
                        <span>{formatNumber(partner.total_referrals)} indicações</span>
                        <span>•</span>
                        <span>R$ {formatNumber(partner.total_commission)}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <Badge
                      variant={partner.status === "active" ? "default" : "secondary"}
                      className={partner.status === "active" ? "bg-green-100 text-green-800" : ""}
                    >
                      {partner.status === "active" ? "Ativo" : "Inativo"}
                    </Badge>
                    <Link href={`/admin/partners/${partner.id}`}>
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4 mr-1" />
                        Ver Detalhes
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
