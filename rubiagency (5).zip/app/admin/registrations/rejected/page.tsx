import { Suspense } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { XCircle } from "lucide-react"
import { RegistrationsList } from "../../components/registrations-list"
import { getUserRegistrations, getRegistrationStats } from "@/lib/database"

async function RejectedRegistrationsContent() {
  const [rejectedRegistrations, stats] = await Promise.all([getUserRegistrations("rejected"), getRegistrationStats()])

  return (
    <div className="space-y-6">
      {/* Stats Card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div>
            <CardTitle className="flex items-center gap-2">
              <XCircle className="h-5 w-5 text-red-600" />
              Cadastros Reprovados
            </CardTitle>
            <CardDescription>Candidatos que não foram aceitos na agência</CardDescription>
          </div>
          <div className="text-3xl font-bold text-red-600">{stats.rejected}</div>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-muted-foreground">
            {stats.rejected === 0
              ? "Nenhum cadastro reprovado"
              : `${stats.rejected} ${stats.rejected === 1 ? "candidato reprovado" : "candidatos reprovados"}`}
          </div>
        </CardContent>
      </Card>

      {/* Registrations List */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Cadastros Reprovados</CardTitle>
          <CardDescription>Candidatos que não atenderam aos critérios da agência</CardDescription>
        </CardHeader>
        <CardContent>
          {rejectedRegistrations.length > 0 ? (
            <RegistrationsList registrations={rejectedRegistrations} />
          ) : (
            <div className="text-center py-8">
              <XCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhum cadastro reprovado</h3>
              <p className="text-gray-600">Ainda não há candidatos reprovados.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default function RejectedRegistrationsPage() {
  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Cadastros Reprovados</h2>
      </div>

      <Suspense
        fallback={
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600"></div>
          </div>
        }
      >
        <RejectedRegistrationsContent />
      </Suspense>
    </div>
  )
}
