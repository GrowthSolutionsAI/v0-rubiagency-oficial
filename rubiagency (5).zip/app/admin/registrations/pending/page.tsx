import { Suspense } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Clock } from "lucide-react"
import { RegistrationsList } from "../../components/registrations-list"
import { getUserRegistrations, getRegistrationStats } from "@/lib/database"

async function PendingRegistrationsContent() {
  const [pendingRegistrations, stats] = await Promise.all([getUserRegistrations("pending"), getRegistrationStats()])

  return (
    <div className="space-y-6">
      {/* Stats Card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-yellow-600" />
              Cadastros Pendentes
            </CardTitle>
            <CardDescription>Candidatos aguardando análise e aprovação</CardDescription>
          </div>
          <div className="text-3xl font-bold text-yellow-600">{stats.pending}</div>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-muted-foreground">
            {stats.pending === 0
              ? "Nenhum cadastro pendente no momento"
              : `${stats.pending} ${stats.pending === 1 ? "cadastro aguardando" : "cadastros aguardando"} sua análise`}
          </div>
        </CardContent>
      </Card>

      {/* Registrations List */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Cadastros Pendentes</CardTitle>
          <CardDescription>Analise e tome uma decisão sobre cada candidato</CardDescription>
        </CardHeader>
        <CardContent>
          {pendingRegistrations.length > 0 ? (
            <RegistrationsList registrations={pendingRegistrations} />
          ) : (
            <div className="text-center py-8">
              <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhum cadastro pendente</h3>
              <p className="text-gray-600">Todos os cadastros foram analisados.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default function PendingRegistrationsPage() {
  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Cadastros Pendentes</h2>
      </div>

      <Suspense
        fallback={
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-600"></div>
          </div>
        }
      >
        <PendingRegistrationsContent />
      </Suspense>
    </div>
  )
}
