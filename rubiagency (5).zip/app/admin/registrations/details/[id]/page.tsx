import { Suspense } from "react"
import { notFound } from "next/navigation"
import { getRegistrationByIdAction } from "@/app/admin/actions"
import { RegistrationDetails } from "@/app/admin/components/registration-details"

interface RegistrationDetailsPageProps {
  params: {
    id: string
  }
}

async function RegistrationDetailsContent({ id }: { id: string }) {
  const registration = await getRegistrationByIdAction(id)

  if (!registration) {
    notFound()
  }

  return <RegistrationDetails registration={registration} files={[]} />
}

export default function RegistrationDetailsPage({ params }: RegistrationDetailsPageProps) {
  return (
    <div className="container mx-auto py-6">
      <Suspense
        fallback={
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Carregando detalhes do cadastro...</p>
            </div>
          </div>
        }
      >
        <RegistrationDetailsContent id={params.id} />
      </Suspense>
    </div>
  )
}

export async function generateMetadata({ params }: RegistrationDetailsPageProps) {
  const registration = await getRegistrationByIdAction(params.id)

  if (!registration) {
    return {
      title: "Cadastro não encontrado - Rubi Agency Admin",
    }
  }

  return {
    title: `${registration.name} - Detalhes do Cadastro - Rubi Agency Admin`,
    description: `Detalhes do cadastro de ${registration.name} no painel administrativo da Rubi Agency`,
  }
}
