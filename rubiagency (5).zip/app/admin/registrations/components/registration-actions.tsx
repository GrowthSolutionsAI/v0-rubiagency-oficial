"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle, XCircle, Loader2, AlertCircle } from "lucide-react"
import type { ContactRegistration } from "@/lib/database"

interface RegistrationActionsProps {
  registration: ContactRegistration
}

export function RegistrationActions({ registration }: RegistrationActionsProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [message, setMessage] = useState("")
  const [messageType, setMessageType] = useState<"success" | "error" | null>(null)

  const handleAction = async (action: "approve" | "reject") => {
    setIsLoading(true)
    setMessage("")
    setMessageType(null)

    try {
      const response = await fetch(`/api/admin/registrations/${registration.id}/status`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          status: action === "approve" ? "approved" : "rejected",
        }),
      })

      const result = await response.json()

      if (result.success) {
        setMessage(
          action === "approve"
            ? "Registro aprovado com sucesso! Email de aprovação enviado."
            : "Registro rejeitado. Email de notificação enviado.",
        )
        setMessageType("success")

        // Refresh the page after a delay
        setTimeout(() => {
          router.refresh()
        }, 2000)
      } else {
        setMessage(result.message || "Erro ao processar ação")
        setMessageType("error")
      }
    } catch (error) {
      console.error("Action error:", error)
      setMessage("Erro de conexão. Tente novamente.")
      setMessageType("error")
    } finally {
      setIsLoading(false)
    }
  }

  const canTakeAction = registration.status === "pending"

  return (
    <div className="space-y-4">
      {message && (
        <Alert className={messageType === "success" ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}>
          {messageType === "success" ? (
            <CheckCircle className="h-4 w-4 text-green-600" />
          ) : (
            <AlertCircle className="h-4 w-4 text-red-600" />
          )}
          <AlertDescription className={messageType === "success" ? "text-green-800" : "text-red-800"}>
            {message}
          </AlertDescription>
        </Alert>
      )}

      {canTakeAction ? (
        <div className="flex gap-4">
          <Button
            onClick={() => handleAction("approve")}
            disabled={isLoading}
            className="bg-green-600 hover:bg-green-700"
          >
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle className="mr-2 h-4 w-4" />}
            Aprovar
          </Button>

          <Button onClick={() => handleAction("reject")} disabled={isLoading} variant="destructive">
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <XCircle className="mr-2 h-4 w-4" />}
            Rejeitar
          </Button>
        </div>
      ) : (
        <div className="p-4 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-600">
            Este registro já foi processado. Status atual: <strong>{registration.status}</strong>
          </p>
        </div>
      )}
    </div>
  )
}
