import { getRegistrations } from "../../../actions"
import { RegistrationsList } from "../../../components/registrations-list"
import { notFound } from "next/navigation"

interface PageProps {
  params: {
    status: string
  }
}

export default async function RegistrationsByStatusPage({ params }: PageProps) {
  const validStatuses = ["pending", "approved", "rejected"]

  if (!validStatuses.includes(params.status)) {
    notFound()
  }

  const registrations = await getRegistrations(params.status)

  const titles = {
    pending: "Cadastros Pendentes",
    approved: "Cadastros Aprovados",
    rejected: "Cadastros Reprovados",
  }

  const descriptions = {
    pending: "Cadastros aguardando análise",
    approved: "Cadastros que foram aprovados",
    rejected: "Cadastros que foram reprovados",
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">{titles[params.status as keyof typeof titles]}</h2>
        <p className="text-gray-600">{descriptions[params.status as keyof typeof descriptions]}</p>
      </div>

      <RegistrationsList registrations={registrations} />
    </div>
  )
}
