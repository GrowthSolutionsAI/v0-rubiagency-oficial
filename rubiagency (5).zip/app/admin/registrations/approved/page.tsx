import { Suspense } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle } from "lucide-react"
import { RegistrationsList } from "../../components/registrations-list"
import { getUserRegistrations, getRegistrationStats } from "@/lib/database"

async function ApprovedRegistrationsContent() {
  const [approvedRegistrations, stats] = await Promise.all([getUserRegistrations("approved"), getRegistrationStats()])

  return (
    <div className="space-y-6">
      {/* Stats Card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              Cadastros Aprovados
            </CardTitle>
            <CardDescription>Candidatos aprovados e aceitos na agência</CardDescription>
          </div>
          <div className="text-3xl font-bold text-green-600">{stats.approved}</div>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-muted-foreground">
            {stats.approved === 0
              ? "Nenhum cadastro aprovado ainda"
              : `${stats.approved} ${stats.approved === 1 ? "candidato aprovado" : "candidatos aprovados"} na agência`}
          </div>
        </CardContent>
      </Card>

      {/* Registrations List */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Cadastros Aprovados</CardTitle>
          <CardDescription>Candidatos que foram aceitos e fazem parte da Rubi Agency</CardDescription>
        </CardHeader>
        <CardContent>
          {approvedRegistrations.length > 0 ? (
            <RegistrationsList registrations={approvedRegistrations} />
          ) : (
            <div className="text-center py-8">
              <CheckCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhum cadastro aprovado</h3>
              <p className="text-gray-600">Ainda não há candidatos aprovados.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default function ApprovedRegistrationsPage() {
  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Cadastros Aprovados</h2>
      </div>

      <Suspense
        fallback={
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
          </div>
        }
      >
        <ApprovedRegistrationsContent />
      </Suspense>
    </div>
  )
}
