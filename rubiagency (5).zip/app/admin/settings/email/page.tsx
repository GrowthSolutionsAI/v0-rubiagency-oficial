import { getSettings } from "@/app/admin/actions"
import { EmailSettings } from "@/app/admin/components/email-settings"

export default async function EmailSettingsPage() {
  const settings = await getSettings()

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Configurações de Email</h1>
        <p className="text-muted-foreground">Configure o sistema de envio automático de emails</p>
      </div>

      <EmailSettings settings={settings} />
    </div>
  )
}
