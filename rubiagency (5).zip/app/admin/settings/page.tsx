import { Suspense } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { SettingsForm } from "../components/settings-form"
import { EmailSettings } from "../components/email-settings"
import { DatabaseValidator } from "../components/database-validator"
import { SystemDiagnostics } from "../components/system-diagnostics"
import { Settings, Mail, Database, Activity } from "lucide-react"

// Dados mock para configurações (substituir por dados reais do banco)
const mockSettings = [
  {
    id: 1,
    setting_key: "welcome_message",
    setting_value: "Bem-vinda à Rubi Agency! Estamos ansiosos para trabalhar com você.",
    description: "Mensagem exibida para novos cadastros",
  },
  {
    id: 2,
    setting_key: "admin_email",
    setting_value: "admin@rubiagency.com",
    description: "Email principal do administrador",
  },
  {
    id: 3,
    setting_key: "approval_email_subject",
    setting_value: "🎉 Parabéns! Seu cadastro foi aprovado - Rubi Agency",
    description: "Assunto do email de aprovação",
  },
  {
    id: 4,
    setting_key: "approval_email_body",
    setting_value:
      "Olá {name},\n\nTemos o prazer de informar que seu cadastro foi aprovado!\n\nEm breve entraremos em contato com mais detalhes.\n\nAtenciosamente,\nEquipe Rubi Agency",
    description: "Corpo do email de aprovação",
  },
  {
    id: 5,
    setting_key: "rejection_email_subject",
    setting_value: "Sobre seu cadastro - Rubi Agency",
    description: "Assunto do email de reprovação",
  },
  {
    id: 6,
    setting_key: "rejection_email_body",
    setting_value:
      "Olá {name},\n\nAgradecemos seu interesse em trabalhar conosco.\n\nInfelizmente, no momento não temos uma oportunidade que se adeque ao seu perfil.\n\nAtenciosamente,\nEquipe Rubi Agency",
    description: "Corpo do email de reprovação",
  },
  {
    id: 7,
    setting_key: "smtp_enabled",
    setting_value: "false",
    description: "Ativar envio automático de emails",
  },
  {
    id: 8,
    setting_key: "smtp_provider",
    setting_value: "resend",
    description: "Provedor de email (resend, sendgrid, smtp)",
  },
  {
    id: 9,
    setting_key: "smtp_from_name",
    setting_value: "Rubi Agency",
    description: "Nome do remetente dos emails",
  },
  {
    id: 10,
    setting_key: "smtp_from_email",
    setting_value: "noreply@rubiagency.com",
    description: "Email do remetente",
  },
]

async function SettingsContent() {
  // Em produção, usar: const settings = await getSettings()
  const settings = mockSettings

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Configurações do Sistema</h1>
        <p className="text-muted-foreground mt-2">Gerencie todas as configurações da plataforma</p>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-8">
          <TabsTrigger value="general" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Geral
          </TabsTrigger>
          <TabsTrigger value="email" className="flex items-center gap-2">
            <Mail className="h-4 w-4" />
            Email
          </TabsTrigger>
          <TabsTrigger value="diagnostics" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Diagnóstico
          </TabsTrigger>
          <TabsTrigger value="validation" className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            Validação
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Configurações Gerais
              </CardTitle>
              <CardDescription>Configure mensagens, emails e parâmetros básicos do sistema</CardDescription>
            </CardHeader>
            <CardContent>
              <SettingsForm settings={settings} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="email" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="h-5 w-5" />
                Configurações de Email
              </CardTitle>
              <CardDescription>Configure provedores de email, templates e testes de envio</CardDescription>
            </CardHeader>
            <CardContent>
              <EmailSettings settings={settings} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="diagnostics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Diagnóstico do Sistema
              </CardTitle>
              <CardDescription>Monitore performance, logs e status dos serviços</CardDescription>
            </CardHeader>
            <CardContent>
              <SystemDiagnostics />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="validation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Validação do Banco de Dados
              </CardTitle>
              <CardDescription>Teste conexões, integridade e performance do banco</CardDescription>
            </CardHeader>
            <CardContent>
              <DatabaseValidator />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function SettingsLoading() {
  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-8">
        <Skeleton className="h-8 w-64 mb-2" />
        <Skeleton className="h-4 w-96" />
      </div>

      <div className="space-y-4">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-64 w-full" />
        <Skeleton className="h-32 w-full" />
      </div>
    </div>
  )
}

export default function SettingsPage() {
  return (
    <Suspense fallback={<SettingsLoading />}>
      <SettingsContent />
    </Suspense>
  )
}
