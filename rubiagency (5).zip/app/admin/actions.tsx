"use server"

import { revalidatePath } from "next/cache"
import { createSupabaseServerClient } from "@/lib/supabase-server"
import { sendApprovalEmail, sendRejectionEmail, testEmailConnection } from "@/lib/email"

// Tipos para as ações do admin
interface Registration {
  id: string
  name: string
  email: string
  phone?: string
  instagram?: string
  status: "pending" | "approved" | "rejected"
  created_at: string
  updated_at: string
  partner_id?: string
  partner_name?: string
}

interface SystemSetting {
  key: string
  value: string
  description?: string
}

interface AnalyticsData {
  totalRegistrations: number
  pendingRegistrations: number
  approvedRegistrations: number
  rejectedRegistrations: number
  recentRegistrations: Registration[]
  monthlyStats: Array<{
    month: string
    registrations: number
    approvals: number
  }>
}

// Função para obter dados de analytics
export async function getAnalyticsData(): Promise<AnalyticsData> {
  try {
    const supabase = createSupabaseServerClient()

    // Buscar estatísticas gerais
    const { data: registrations, error } = await supabase
      .from("registrations")
      .select("*")
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Error fetching registrations:", error)
      return {
        totalRegistrations: 0,
        pendingRegistrations: 0,
        approvedRegistrations: 0,
        rejectedRegistrations: 0,
        recentRegistrations: [],
        monthlyStats: [],
      }
    }

    const totalRegistrations = registrations?.length || 0
    const pendingRegistrations = registrations?.filter((r) => r.status === "pending").length || 0
    const approvedRegistrations = registrations?.filter((r) => r.status === "approved").length || 0
    const rejectedRegistrations = registrations?.filter((r) => r.status === "rejected").length || 0
    const recentRegistrations = registrations?.slice(0, 10) || []

    // Calcular estatísticas mensais
    const monthlyStats = calculateMonthlyStats(registrations || [])

    return {
      totalRegistrations,
      pendingRegistrations,
      approvedRegistrations,
      rejectedRegistrations,
      recentRegistrations,
      monthlyStats,
    }
  } catch (error) {
    console.error("Error in getAnalyticsData:", error)
    return {
      totalRegistrations: 0,
      pendingRegistrations: 0,
      approvedRegistrations: 0,
      rejectedRegistrations: 0,
      recentRegistrations: [],
      monthlyStats: [],
    }
  }
}

// Função auxiliar para calcular estatísticas mensais
function calculateMonthlyStats(registrations: Registration[]) {
  const monthlyData: { [key: string]: { registrations: number; approvals: number } } = {}

  registrations.forEach((reg) => {
    const date = new Date(reg.created_at)
    const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`

    if (!monthlyData[monthKey]) {
      monthlyData[monthKey] = { registrations: 0, approvals: 0 }
    }

    monthlyData[monthKey].registrations++
    if (reg.status === "approved") {
      monthlyData[monthKey].approvals++
    }
  })

  return Object.entries(monthlyData)
    .map(([month, data]) => ({
      month,
      registrations: data.registrations,
      approvals: data.approvals,
    }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12) // Últimos 12 meses
}

// Função para atualizar configurações de email
export async function updateEmailSettings(formData: FormData): Promise<{ success: boolean; error?: string }> {
  try {
    const supabase = createSupabaseServerClient()

    const emailProvider = formData.get("email_provider") as string
    const smtpHost = formData.get("smtp_host") as string
    const smtpPort = formData.get("smtp_port") as string
    const smtpUser = formData.get("smtp_user") as string
    const smtpPass = formData.get("smtp_pass") as string
    const resendApiKey = formData.get("resend_api_key") as string
    const sendgridApiKey = formData.get("sendgrid_api_key") as string

    // Atualizar configurações no banco
    const settings = [
      { key: "email_provider", value: emailProvider },
      { key: "smtp_host", value: smtpHost },
      { key: "smtp_port", value: smtpPort },
      { key: "smtp_user", value: smtpUser },
      { key: "smtp_pass", value: smtpPass },
      { key: "resend_api_key", value: resendApiKey },
      { key: "sendgrid_api_key", value: sendgridApiKey },
    ]

    for (const setting of settings) {
      if (setting.value) {
        await supabase.from("system_settings").upsert({
          key: setting.key,
          value: setting.value,
          updated_at: new Date().toISOString(),
        })
      }
    }

    revalidatePath("/admin/settings/email")
    return { success: true }
  } catch (error) {
    console.error("Error updating email settings:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }
  }
}

// Função para testar configuração de email
export async function testEmailConfiguration(): Promise<{ success: boolean; error?: string }> {
  try {
    const result = await testEmailConnection()
    return result
  } catch (error) {
    console.error("Error testing email configuration:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Test failed",
    }
  }
}

// Função para aprovar registro
export async function approveRegistration(registrationId: string): Promise<{ success: boolean; error?: string }> {
  try {
    const supabase = createSupabaseServerClient()

    // Buscar o registro
    const { data: registration, error: fetchError } = await supabase
      .from("registrations")
      .select("*")
      .eq("id", registrationId)
      .single()

    if (fetchError || !registration) {
      return { success: false, error: "Registration not found" }
    }

    // Atualizar status
    const { error: updateError } = await supabase
      .from("registrations")
      .update({
        status: "approved",
        updated_at: new Date().toISOString(),
      })
      .eq("id", registrationId)

    if (updateError) {
      return { success: false, error: updateError.message }
    }

    // Enviar email de aprovação
    await sendApprovalEmail(registration.email, registration.name)

    revalidatePath("/admin/registrations")
    revalidatePath("/admin")
    return { success: true }
  } catch (error) {
    console.error("Error approving registration:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }
  }
}

// Função para rejeitar registro
export async function rejectRegistration(
  registrationId: string,
  reason?: string,
): Promise<{ success: boolean; error?: string }> {
  try {
    const supabase = createSupabaseServerClient()

    // Buscar o registro
    const { data: registration, error: fetchError } = await supabase
      .from("registrations")
      .select("*")
      .eq("id", registrationId)
      .single()

    if (fetchError || !registration) {
      return { success: false, error: "Registration not found" }
    }

    // Atualizar status
    const { error: updateError } = await supabase
      .from("registrations")
      .update({
        status: "rejected",
        rejection_reason: reason,
        updated_at: new Date().toISOString(),
      })
      .eq("id", registrationId)

    if (updateError) {
      return { success: false, error: updateError.message }
    }

    // Enviar email de rejeição
    await sendRejectionEmail(registration.email, registration.name, reason)

    revalidatePath("/admin/registrations")
    revalidatePath("/admin")
    return { success: true }
  } catch (error) {
    console.error("Error rejecting registration:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }
  }
}

// Função para atualizar configuração individual
export async function updateSetting(key: string, value: string): Promise<{ success: boolean; error?: string }> {
  try {
    const supabase = createSupabaseServerClient()

    const { error } = await supabase.from("system_settings").upsert({
      key,
      value,
      updated_at: new Date().toISOString(),
    })

    if (error) {
      return { success: false, error: error.message }
    }

    revalidatePath("/admin/settings")
    return { success: true }
  } catch (error) {
    console.error("Error updating setting:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }
  }
}

// Função para testar banco de dados
export async function testDatabase(): Promise<{ success: boolean; error?: string }> {
  try {
    const supabase = createSupabaseServerClient()

    // Teste simples de conexão
    const { data, error } = await supabase.from("system_settings").select("count").limit(1)

    if (error) {
      return { success: false, error: error.message }
    }

    return { success: true }
  } catch (error) {
    console.error("Error testing database:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Database test failed",
    }
  }
}

// Função para forçar revalidação
export async function forceRevalidate(): Promise<{ success: boolean }> {
  try {
    revalidatePath("/admin")
    revalidatePath("/admin/registrations")
    revalidatePath("/admin/settings")
    revalidatePath("/admin/analytics")
    revalidatePath("/")

    return { success: true }
  } catch (error) {
    console.error("Error revalidating:", error)
    return { success: false }
  }
}

// Função para buscar configurações
export async function getSettings(): Promise<SystemSetting[]> {
  try {
    const supabase = createSupabaseServerClient()

    const { data, error } = await supabase.from("system_settings").select("*").order("key")

    if (error) {
      console.error("Error fetching settings:", error)
      return []
    }

    return data || []
  } catch (error) {
    console.error("Error in getSettings:", error)
    return []
  }
}

// Função para atualizar configuração do sistema
export async function updateSystemSetting(
  key: string,
  value: string,
  description?: string,
): Promise<{ success: boolean; error?: string }> {
  try {
    const supabase = createSupabaseServerClient()

    const { error } = await supabase.from("system_settings").upsert({
      key,
      value,
      description,
      updated_at: new Date().toISOString(),
    })

    if (error) {
      return { success: false, error: error.message }
    }

    revalidatePath("/admin/settings")
    return { success: true }
  } catch (error) {
    console.error("Error updating system setting:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }
  }
}

// Função para buscar registro por ID
export async function getRegistrationByIdAction(id: string): Promise<Registration | null> {
  try {
    const supabase = createSupabaseServerClient()

    const { data, error } = await supabase.from("registrations").select("*").eq("id", id).single()

    if (error) {
      console.error("Error fetching registration:", error)
      return null
    }

    return data
  } catch (error) {
    console.error("Error in getRegistrationByIdAction:", error)
    return null
  }
}

// Função para buscar registros com filtro
export async function getRegistrations(
  status?: "pending" | "approved" | "rejected",
  limit?: number,
): Promise<Registration[]> {
  try {
    const supabase = createSupabaseServerClient()

    let query = supabase.from("registrations").select("*").order("created_at", { ascending: false })

    if (status) {
      query = query.eq("status", status)
    }

    if (limit) {
      query = query.limit(limit)
    }

    const { data, error } = await query

    if (error) {
      console.error("Error fetching registrations:", error)
      return []
    }

    return data || []
  } catch (error) {
    console.error("Error in getRegistrations:", error)
    return []
  }
}

// Função para deletar registro
export async function deleteRegistration(id: string): Promise<{ success: boolean; error?: string }> {
  try {
    const supabase = createSupabaseServerClient()

    const { error } = await supabase.from("registrations").delete().eq("id", id)

    if (error) {
      return { success: false, error: error.message }
    }

    revalidatePath("/admin/registrations")
    revalidatePath("/admin")
    return { success: true }
  } catch (error) {
    console.error("Error deleting registration:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }
  }
}

// Função para atualização em lote
export async function bulkUpdateRegistrations(
  ids: string[],
  status: "pending" | "approved" | "rejected",
): Promise<{ success: boolean; error?: string }> {
  try {
    const supabase = createSupabaseServerClient()

    const { error } = await supabase
      .from("registrations")
      .update({
        status,
        updated_at: new Date().toISOString(),
      })
      .in("id", ids)

    if (error) {
      return { success: false, error: error.message }
    }

    revalidatePath("/admin/registrations")
    revalidatePath("/admin")
    return { success: true }
  } catch (error) {
    console.error("Error bulk updating registrations:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }
  }
}

// Função para exportar registros
export async function exportRegistrations(
  status?: "pending" | "approved" | "rejected",
): Promise<{ success: boolean; data?: string; error?: string }> {
  try {
    const registrations = await getRegistrations(status)

    // Converter para CSV
    const headers = ["ID", "Nome", "Email", "Telefone", "Instagram", "Status", "Data de Criação"]
    const csvContent = [
      headers.join(","),
      ...registrations.map((reg) =>
        [
          reg.id,
          `"${reg.name}"`,
          reg.email,
          reg.phone || "",
          reg.instagram || "",
          reg.status,
          new Date(reg.created_at).toLocaleDateString("pt-BR"),
        ].join(","),
      ),
    ].join("\n")

    return { success: true, data: csvContent }
  } catch (error) {
    console.error("Error exporting registrations:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Export failed",
    }
  }
}
