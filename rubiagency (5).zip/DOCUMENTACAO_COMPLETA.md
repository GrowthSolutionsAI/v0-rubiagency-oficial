# 📋 Documentação Completa - Rubi Agency

## 🏗️ Estrutura do Projeto

### Visão Geral
O projeto Rubi Agency é uma aplicação Next.js 15 completa para uma agência de marketing digital, incluindo site institucional, sistema de cadastros, dashboard administrativo e sistema de parceiros.

### Arquitetura
- **Frontend**: Next.js 15 com App Router
- **Backend**: API Routes do Next.js
- **Banco de Dados**: Supabase (PostgreSQL)
- **Autenticação**: Sistema próprio com cookies
- **Email**: Suporte a SMTP, Resend e SendGrid
- **Styling**: Tailwind CSS + shadcn/ui
- **Deploy**: Vercel

## 📁 Estrutura de Diretórios

\`\`\`
rubiagency/
├── app/                          # App Router (Next.js 15)
│   ├── admin/                    # Dashboard Administrativo
│   │   ├── analytics/            # Página de Analytics
│   │   ├── components/           # Componentes do Admin
│   │   ├── login/               # Login do Admin
│   │   ├── partners/            # Gestão de Parceiros
│   │   ├── registrations/       # Gestão de Cadastros
│   │   ├── settings/            # Configurações
│   │   ├── actions.tsx          # Server Actions
│   │   ├── layout.tsx           # Layout do Admin
│   │   └── page.tsx             # Dashboard Principal
│   ├── api/                     # API Routes
│   │   ├── admin/               # APIs do Admin
│   │   ├── contact/             # API de Contato
│   │   └── email/               # APIs de Email
│   ├── blog/                    # Sistema de Blog
│   ├── seo/                     # Páginas SEO
│   ├── globals.css              # Estilos Globais
│   ├── layout.tsx               # Layout Principal
│   ├── page.tsx                 # Página Inicial
│   ├── robots.ts                # Robots.txt
│   └── sitemap.ts               # Sitemap
├── components/                   # Componentes React
│   ├── ui/                      # Componentes shadcn/ui
│   ├── about.tsx                # Seção Sobre
│   ├── blog.tsx                 # Componente Blog
│   ├── contact.tsx              # Formulário de Contato
│   ├── faq.tsx                  # FAQ
│   ├── footer.tsx               # Rodapé
│   ├── hero.tsx                 # Hero Section
│   ├── navbar.tsx               # Navegação
│   ├── services.tsx             # Serviços
│   └── testimonials.tsx         # Depoimentos
├── contexts/                    # Contextos React
│   └── language-context.tsx     # Contexto de Idioma
├── hooks/                       # Custom Hooks
│   └── use-mobile.tsx           # Hook Mobile
├── lib/                         # Bibliotecas e Utilitários
│   ├── auth.ts                  # Autenticação
│   ├── database.ts              # Funções do Banco
│   ├── email.ts                 # Sistema de Email
│   ├── i18n.ts                  # Internacionalização
│   ├── supabase.ts              # Cliente Supabase
│   └── utils.ts                 # Utilitários
├── public/                      # Arquivos Estáticos
│   ├── images/                  # Imagens
│   └── icons/                   # Ícones
├── scripts/                     # Scripts SQL e JS
│   ├── supabase-*.sql           # Scripts do Supabase
│   └── validate-*.js            # Scripts de Validação
├── styles/                      # Estilos
│   └── globals.css              # CSS Global
├── .env.local                   # Variáveis de Ambiente
├── next.config.mjs              # Configuração Next.js
├── package.json                 # Dependências
├── tailwind.config.ts           # Configuração Tailwind
└── tsconfig.json                # Configuração TypeScript
\`\`\`

## 🗄️ Banco de Dados - Estrutura Completa

### Tabelas Principais

#### 1. contact_registrations
\`\`\`sql
CREATE TABLE contact_registrations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    instagram VARCHAR(255),
    experience TEXT,
    partner_code VARCHAR(50),
    partner_name VARCHAR(255),
    status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    attachments JSONB
);
\`\`\`

**Campos:**
- `id`: Identificador único (UUID)
- `name`: Nome completo do candidato
- `email`: Email de contato
- `phone`: Telefone (opcional)
- `instagram`: Perfil do Instagram
- `experience`: Experiência profissional
- `partner_code`: Código do parceiro (se aplicável)
- `partner_name`: Nome do parceiro
- `status`: Status do cadastro (pending, approved, rejected)
- `created_at`: Data de criação
- `updated_at`: Data de atualização
- `attachments`: Anexos em JSON

#### 2. partners
\`\`\`sql
CREATE TABLE partners (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    commission_rate DECIMAL(5,2) DEFAULT 10.00,
    total_referrals INTEGER DEFAULT 0,
    total_commission DECIMAL(10,2) DEFAULT 0.00,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
\`\`\`

**Campos:**
- `id`: Identificador único
- `name`: Nome do parceiro
- `email`: Email do parceiro
- `code`: Código único do parceiro
- `commission_rate`: Taxa de comissão (%)
- `total_referrals`: Total de indicações
- `total_commission`: Comissão total acumulada
- `status`: Status do parceiro (active, inactive)

#### 3. system_settings
\`\`\`sql
CREATE TABLE system_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    description TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
\`\`\`

**Configurações Padrão:**
- `site_name`: Nome do site
- `admin_email`: Email do administrador
- `smtp_host`: Servidor SMTP
- `smtp_port`: Porta SMTP
- `smtp_user`: Usuário SMTP
- `smtp_pass`: Senha SMTP
- `email_from`: Email remetente
- `resend_api_key`: Chave API Resend
- `sendgrid_api_key`: Chave API SendGrid

#### 4. admin_users
\`\`\`sql
CREATE TABLE admin_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'admin',
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
\`\`\`

### Triggers e Funções

#### 1. Atualização Automática de Timestamps
\`\`\`sql
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Aplicar a todas as tabelas
CREATE TRIGGER update_contact_registrations_updated_at 
    BEFORE UPDATE ON contact_registrations 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
\`\`\`

#### 2. Atualização de Estatísticas de Parceiros
\`\`\`sql
CREATE OR REPLACE FUNCTION update_partner_stats()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.partner_code IS NOT NULL THEN
        UPDATE partners 
        SET total_referrals = total_referrals + 1,
            updated_at = NOW()
        WHERE code = NEW.partner_code;
    END IF;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_partner_stats_trigger
    AFTER INSERT ON contact_registrations
    FOR EACH ROW EXECUTE FUNCTION update_partner_stats();
\`\`\`

### Índices para Performance
\`\`\`sql
-- Índices principais
CREATE INDEX idx_contact_registrations_status ON contact_registrations(status);
CREATE INDEX idx_contact_registrations_created_at ON contact_registrations(created_at);
CREATE INDEX idx_contact_registrations_partner_code ON contact_registrations(partner_code);
CREATE INDEX idx_partners_code ON partners(code);
CREATE INDEX idx_system_settings_key ON system_settings(setting_key);
\`\`\`

### Row Level Security (RLS)
\`\`\`sql
-- Habilitar RLS
ALTER TABLE contact_registrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE partners ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Políticas de acesso (exemplo)
CREATE POLICY "Allow public read access to contact_registrations" 
    ON contact_registrations FOR SELECT 
    USING (true);

CREATE POLICY "Allow authenticated insert to contact_registrations" 
    ON contact_registrations FOR INSERT 
    WITH CHECK (true);
\`\`\`

## 🎛️ Dashboard Administrativo

### 1. Dashboard Principal (`/admin`)

**Funcionalidades:**
- **Estatísticas em Tempo Real**: Total de cadastros, pendentes, aprovados, rejeitados
- **Gráficos de Crescimento**: Comparação mensal, taxa de crescimento
- **Cadastros Recentes**: Lista dos últimos 5 cadastros
- **Status do Sistema**: Conexão com banco, email, parceiros
- **Ações Rápidas**: Botões para principais funcionalidades

**Métricas Exibidas:**
\`\`\`typescript
interface DashboardStats {
  total: number;           // Total de cadastros
  pending: number;         // Cadastros pendentes
  approved: number;        // Cadastros aprovados
  rejected: number;        // Cadastros rejeitados
  thisMonth: number;       // Cadastros deste mês
  lastMonth: number;       // Cadastros do mês passado
  growthRate: number;      // Taxa de crescimento (%)
}
\`\`\`

### 2. Gestão de Cadastros (`/admin/registrations`)

**Páginas:**
- `/admin/registrations` - Lista geral
- `/admin/registrations/pending` - Cadastros pendentes
- `/admin/registrations/approved` - Cadastros aprovados
- `/admin/registrations/rejected` - Cadastros rejeitados
- `/admin/registrations/details/[id]` - Detalhes do cadastro

**Funcionalidades:**
- **Filtros Avançados**: Por status, data, parceiro
- **Busca**: Por nome, email, telefone
- **Ações em Massa**: Aprovar/rejeitar múltiplos
- **Exportação**: CSV, Excel
- **Detalhes Completos**: Visualização de todos os dados
- **Histórico**: Log de alterações de status
- **Notificações Email**: Automáticas na aprovação/rejeição

**Interface de Cadastro:**
\`\`\`typescript
interface Registration {
  id: string;
  name: string;
  email: string;
  phone?: string;
  instagram?: string;
  experience: string;
  partner_code?: string;
  partner_name?: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
  updated_at: string;
  attachments?: any[];
}
\`\`\`

### 3. Sistema de Parceiros (`/admin/partners`)

**Páginas:**
- `/admin/partners` - Lista de parceiros
- `/admin/partners/new` - Criar novo parceiro
- `/admin/partners/[id]` - Detalhes do parceiro

**Funcionalidades:**
- **Dashboard do Parceiro**: Estatísticas individuais
- **Gestão de Comissões**: Cálculo automático
- **Relatórios**: Performance, indicações, ganhos
- **Códigos Únicos**: Geração automática
- **Status**: Ativo/Inativo

**Métricas do Parceiro:**
\`\`\`typescript
interface PartnerStats {
  totalReferrals: number;      // Total de indicações
  approvedReferrals: number;   // Indicações aprovadas
  pendingReferrals: number;    // Indicações pendentes
  totalCommission: number;     // Comissão total
  monthlyCommission: number;   // Comissão mensal
  conversionRate: number;      // Taxa de conversão
}
\`\`\`

### 4. Configurações (`/admin/settings`)

**Abas Disponíveis:**

#### Aba 1: Configurações Gerais
- Nome do site
- Email do administrador
- Configurações de SEO
- Configurações de idioma

#### Aba 2: Configurações de Email
- **SMTP**: Host, porta, usuário, senha
- **Resend**: Chave API
- **SendGrid**: Chave API
- **Templates**: Personalização de emails
- **Teste de Email**: Envio de email de teste

#### Aba 3: Diagnóstico do Sistema
- **Status do Banco**: Conexão, performance
- **Status do Email**: Provedor ativo, últimos envios
- **Logs do Sistema**: Erros, sucessos, warnings
- **Performance**: Tempo de resposta, uso de recursos

#### Aba 4: Validação e Manutenção
- **Validação de Dados**: Integridade do banco
- **Limpeza**: Remoção de dados antigos
- **Backup**: Status dos backups
- **Atualizações**: Versão do sistema

### 5. Analytics (`/admin/analytics`)

**Relatórios Disponíveis:**
- **Cadastros por Período**: Gráficos temporais
- **Performance de Parceiros**: Ranking, comissões
- **Origem dos Cadastros**: Canais de aquisição
- **Taxa de Conversão**: Aprovação vs. rejeição
- **Relatórios Personalizados**: Filtros avançados

## 🔌 APIs Documentadas

### 1. API de Contato

#### POST `/api/contact`
Cria um novo cadastro de contato.

**Request:**
\`\`\`json
{
  "name": "João Silva",
  "email": "joao@email.com",
  "phone": "+5511999999999",
  "instagram": "@joaosilva",
  "experience": "2 anos em marketing digital",
  "partner_code": "PARTNER001"
}
\`\`\`

**Response:**
\`\`\`json
{
  "success": true,
  "message": "Cadastro realizado com sucesso!",
  "id": "uuid-do-cadastro"
}
\`\`\`

### 2. APIs do Admin

#### GET `/api/admin/stats`
Retorna estatísticas do dashboard.

**Response:**
\`\`\`json
{
  "total": 150,
  "pending": 25,
  "approved": 100,
  "rejected": 25,
  "thisMonth": 30,
  "lastMonth": 20,
  "growthRate": 50.0
}
\`\`\`

#### GET `/api/admin/registrations`
Lista cadastros com filtros opcionais.

**Query Parameters:**
- `status`: pending, approved, rejected
- `limit`: número de resultados
- `offset`: paginação
- `search`: busca por nome/email

#### PUT `/api/admin/registrations/[id]/status`
Atualiza status de um cadastro.

**Request:**
\`\`\`json
{
  "status": "approved",
  "message": "Mensagem personalizada (opcional)"
}
\`\`\`

### 3. APIs de Parceiros

#### GET `/api/admin/partners`
Lista todos os parceiros.

#### POST `/api/admin/partners`
Cria um novo parceiro.

**Request:**
\`\`\`json
{
  "name": "Parceiro Exemplo",
  "email": "parceiro@email.com",
  "commission_rate": 15.0
}
\`\`\`

#### GET `/api/admin/partners/[id]`
Detalhes de um parceiro específico.

### 4. APIs de Email

#### POST `/api/email/test`
Envia um email de teste.

#### GET `/api/email/status`
Verifica status do serviço de email.

## 🌐 Funcionalidades do Site

### 1. Página Inicial
- **Hero Section**: Apresentação da agência
- **Serviços**: Lista de serviços oferecidos
- **Sobre**: Informações da empresa
- **Depoimentos**: Feedback de clientes
- **FAQ**: Perguntas frequentes
- **Contato**: Formulário de cadastro

### 2. Sistema de Blog
- **Posts**: Artigos sobre marketing digital
- **Categorias**: Organização por temas
- **SEO**: Otimização para buscadores
- **Compartilhamento**: Redes sociais

### 3. Multilíngue
- **Português**: Idioma padrão
- **Inglês**: Tradução completa
- **Seletor**: Troca dinâmica de idioma

### 4. Formulário de Contato Avançado
- **Validação**: Client-side e server-side
- **Campos Obrigatórios**: Nome, email, experiência
- **Campos Opcionais**: Telefone, Instagram
- **Código de Parceiro**: Integração automática
- **Upload**: Anexos (futuro)

## 📧 Sistema de Email

### Provedores Suportados

#### 1. SMTP
\`\`\`typescript
{
  host: "smtp.gmail.com",
  port: 587,
  secure: false,
  auth: {
    user: "seu-email@gmail.com",
    pass: "sua-senha-app"
  }
}
\`\`\`

#### 2. Resend
\`\`\`typescript
{
  apiKey: "re_xxxxxxxxxx",
  from: "noreply@seudominio.com"
}
\`\`\`

#### 3. SendGrid
\`\`\`typescript
{
  apiKey: "SG.xxxxxxxxxx",
  from: "noreply@seudominio.com"
}
\`\`\`

### Templates de Email

#### 1. Email de Aprovação
\`\`\`html
<h2>🎉 Parabéns! Seu cadastro foi aprovado</h2>
<p>Olá {{name}},</p>
<p>Temos o prazer de informar que seu cadastro foi aprovado!</p>
<p>Em breve nossa equipe entrará em contato.</p>
\`\`\`

#### 2. Email de Rejeição
\`\`\`html
<h2>Sobre seu cadastro - Rubi Agency</h2>
<p>Olá {{name}},</p>
<p>Agradecemos seu interesse em trabalhar conosco.</p>
<p>{{custom_message}}</p>
\`\`\`

#### 3. Email de Teste
\`\`\`html
<h2>✅ Teste de Email - Sistema Funcionando</h2>
<p>Este é um email de teste do sistema Rubi Agency.</p>
<p>Data: {{current_date}}</p>
\`\`\`

### Monitoramento de Email
- **Status de Envio**: Sucesso/Falha
- **Logs Detalhados**: Timestamp, destinatário, erro
- **Métricas**: Taxa de entrega, bounces
- **Alertas**: Notificações de falhas

## 🚀 Deploy e Configuração

### Variáveis de Ambiente Obrigatórias

\`\`\`env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://seu-projeto.supabase.co
SUPABASE_SERVICE_ROLE_KEY=sua-service-role-key
NEXT_PUBLIC_SUPABASE_ANON_KEY=sua-anon-key

# Email SMTP
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=seu-email@gmail.com
SMTP_PASS=sua-senha-app
EMAIL_FROM=noreply@rubiagency.com

# Email APIs (opcional)
RESEND_API_KEY=re_xxxxxxxxxx
SENDGRID_API_KEY=SG.xxxxxxxxxx

# Admin
ADMIN_EMAIL=admin@rubiagency.com
NEXT_PUBLIC_APP_URL=https://rubiagency.vercel.app
\`\`\`

### Scripts de Instalação

#### 1. Instalação Local
\`\`\`bash
# Clone o repositório
git clone https://github.com/seu-usuario/rubiagency.git
cd rubiagency

# Instale as dependências
npm install

# Configure as variáveis de ambiente
cp .env.example .env.local
# Edite o arquivo .env.local com suas configurações

# Execute os scripts do banco de dados
npm run db:setup

# Inicie o servidor de desenvolvimento
npm run dev
\`\`\`

#### 2. Deploy na Vercel
\`\`\`bash
# Instale a CLI da Vercel
npm i -g vercel

# Faça o deploy
vercel

# Configure as variáveis de ambiente na Vercel
vercel env add NEXT_PUBLIC_SUPABASE_URL
vercel env add SUPABASE_SERVICE_ROLE_KEY
# ... adicione todas as variáveis necessárias

# Deploy final
vercel --prod
\`\`\`

### Setup do Banco de Dados

#### 1. Criação das Tabelas
Execute os scripts na ordem:
\`\`\`sql
-- 1. Criar tabelas
\i scripts/supabase-001-create-tables.sql

-- 2. Inserir dados padrão
\i scripts/supabase-002-insert-default-data.sql

-- 3. Configurar RLS
\i scripts/supabase-013-add-rls.sql

-- 4. Criar índices
\i scripts/supabase-010-add-indexes.sql

-- 5. Adicionar triggers
\i scripts/supabase-011-add-triggers.sql
\`\`\`

#### 2. Dados de Teste
\`\`\`sql
-- Inserir parceiro de teste
INSERT INTO partners (name, email, code, commission_rate) 
VALUES ('Parceiro Teste', 'parceiro@teste.com', 'TEST001', 15.00);

-- Inserir configurações básicas
INSERT INTO system_settings (setting_key, setting_value) VALUES
('site_name', 'Rubi Agency'),
('admin_email', 'admin@rubiagency.com'),
('email_from', 'noreply@rubiagency.com');
\`\`\`

## 📊 Monitoramento e Manutenção

### Métricas Importantes

#### 1. Performance
- **Tempo de Resposta**: < 2 segundos
- **Uptime**: > 99.9%
- **Taxa de Erro**: < 1%

#### 2. Negócio
- **Cadastros por Dia**: Meta de crescimento
- **Taxa de Aprovação**: % de cadastros aprovados
- **Performance de Parceiros**: Top performers

#### 3. Sistema
- **Uso de Banco**: Queries por minuto
- **Emails Enviados**: Taxa de sucesso
- **Erros de API**: Monitoramento contínuo

### Logs Detalhados

#### 1. Logs de Sucesso
\`\`\`
[2024-01-15 10:30:00] ✅ Registration created: ID=uuid, Email=user@email.com
[2024-01-15 10:30:05] ✅ Email sent: Type=approval, To=user@email.com
[2024-01-15 10:30:10] ✅ Partner stats updated: Code=PARTNER001
\`\`\`

#### 2. Logs de Erro
\`\`\`
[2024-01-15 10:35:00] ❌ Database error: Connection timeout
[2024-01-15 10:35:05] ❌ Email failed: SMTP authentication failed
[2024-01-15 10:35:10] ⚠️  Partner not found: Code=INVALID001
\`\`\`

#### 3. Logs de Segurança
\`\`\`
[2024-01-15 10:40:00] 🔐 Admin login: IP=192.168.1.1, User=admin
[2024-01-15 10:40:05] 🔐 Failed login attempt: IP=192.168.1.100
[2024-01-15 10:40:10] 🔐 Admin logout: User=admin, Session=30min
\`\`\`

### Troubleshooting

#### Problemas Comuns

1. **Erro de Conexão com Banco**
   - Verificar variáveis de ambiente
   - Testar conexão no Supabase
   - Verificar RLS policies

2. **Falha no Envio de Email**
   - Verificar configurações SMTP
   - Testar credenciais
   - Verificar limites de API

3. **Erro 500 no Admin**
   - Verificar logs do servidor
   - Validar autenticação
   - Verificar permissões

4. **Performance Lenta**
   - Verificar índices do banco
   - Otimizar queries
   - Verificar cache

### Backup e Recuperação

#### 1. Backup Automático
- **Supabase**: Backup diário automático
- **Vercel**: Deploy history
- **Código**: Git repository

#### 2. Recuperação de Dados
\`\`\`sql
-- Restaurar cadastros
COPY contact_registrations FROM 'backup_registrations.csv' CSV HEADER;

-- Restaurar parceiros
COPY partners FROM 'backup_partners.csv' CSV HEADER;

-- Restaurar configurações
COPY system_settings FROM 'backup_settings.csv' CSV HEADER;
\`\`\`

## 🔧 Desenvolvimento

### Comandos Úteis

\`\`\`bash
# Desenvolvimento
npm run dev          # Servidor de desenvolvimento
npm run build        # Build de produção
npm run start        # Servidor de produção
npm run lint         # Verificar código

# Banco de dados
npm run db:setup     # Configurar banco
npm run db:seed      # Inserir dados de teste
npm run db:reset     # Resetar banco
npm run db:migrate   # Executar migrações

# Testes
npm run test         # Executar testes
npm run test:watch   # Testes em modo watch
npm run test:coverage # Cobertura de testes

# Deploy
npm run deploy       # Deploy para produção
npm run preview      # Preview do build
\`\`\`

### Estrutura de Componentes

\`\`\`typescript
// Exemplo de componente tipado
interface ComponentProps {
  title: string;
  description?: string;
  children?: React.ReactNode;
}

export function Component({ title, description, children }: ComponentProps) {
  return (
    <div className="component">
      <h2>{title}</h2>
      {description && <p>{description}</p>}
      {children}
    </div>
  );
}
\`\`\`

### Padrões de Código

1. **TypeScript**: Tipagem forte obrigatória
2. **ESLint**: Regras de código consistentes
3. **Prettier**: Formatação automática
4. **Conventional Commits**: Padrão de commits
5. **Component Composition**: Reutilização de componentes

## 📈 Roadmap Futuro

### Próximas Funcionalidades

1. **Sistema de Notificações**
   - Push notifications
   - Email automático
   - SMS integration

2. **Dashboard Avançado**
   - Gráficos interativos
   - Relatórios personalizados
   - Exportação avançada

3. **Mobile App**
   - React Native
   - Notificações push
   - Offline support

4. **Integrações**
   - CRM integration
   - WhatsApp Business
   - Google Analytics

5. **IA e Automação**
   - Chatbot inteligente
   - Análise automática de perfis
   - Recomendações personalizadas

---

## 📞 Suporte

Para suporte técnico ou dúvidas sobre o sistema:

- **Email**: dev@rubiagency.com
- **Documentação**: Esta documentação completa
- **Issues**: GitHub Issues
- **Discord**: Canal de desenvolvimento

---

**Versão da Documentação**: 1.0.0  
**Última Atualização**: Janeiro 2024  
**Autor**: Equipe de Desenvolvimento Rubi Agency
