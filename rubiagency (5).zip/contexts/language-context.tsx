"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { type Language, type TranslationKey, getTranslation } from "@/lib/i18n"

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: TranslationKey) => string
  isLoading: boolean
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("pt")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Initialize language from localStorage or default to Portuguese
    const savedLanguage = localStorage.getItem("preferred-language") as Language
    if (savedLanguage && ["pt", "en", "es"].includes(savedLanguage)) {
      setLanguage(savedLanguage)
    }
    setIsLoading(false)
  }, [])

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang)
    localStorage.setItem("preferred-language", lang)

    // Update HTML lang attribute
    if (typeof document !== "undefined") {
      const langMap = { pt: "pt-BR", en: "en-US", es: "es-ES" }
      document.documentElement.lang = langMap[lang]
    }
  }

  const t = (key: TranslationKey) => {
    return getTranslation(key, language)
  }

  // Update lang attribute when language changes
  useEffect(() => {
    if (typeof document !== "undefined") {
      const langMap = { pt: "pt-BR", en: "en-US", es: "es-ES" }
      document.documentElement.lang = langMap[language]
    }
  }, [language])

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t, isLoading }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
