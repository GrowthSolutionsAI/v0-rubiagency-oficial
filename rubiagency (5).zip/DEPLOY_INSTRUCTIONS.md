# 🚀 Guia Completo de Deploy - Rubi Agency

## 📋 Pré-requisitos

- Node.js 18+ instalado
- npm 8+ instalado
- Conta na Vercel
- Conta no Supabase (para banco de dados)

## 🔧 Configuração Inicial

### 1. Preparar o Projeto

\`\`\`bash
# Clonar ou baixar o projeto
cd rubiagency

# Instalar dependências
npm install

# Testar build local
npm run build
\`\`\`

### 2. Configurar Banco de Dados (Supabase)

1. Acesse [supabase.com](https://supabase.com)
2. Crie um novo projeto
3. Execute os scripts SQL da pasta `/scripts/supabase-*`
4. Anote as credenciais:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`

## 🚀 Deploy Automatizado

### Opção 1: Script Automatizado

\`\`\`bash
# Tornar o script executável
chmod +x deploy.sh

# Executar deploy
./deploy.sh
\`\`\`

### Opção 2: Deploy Manual

\`\`\`bash
# Instalar Vercel CLI
npm install -g vercel

# Login na Vercel
vercel login

# Deploy
vercel --prod
\`\`\`

## 🔐 Variáveis de Ambiente

Configure no painel da Vercel:

### Obrigatórias:
\`\`\`
NEXT_PUBLIC_SUPABASE_URL=sua_url_supabase
NEXT_PUBLIC_SUPABASE_ANON_KEY=sua_chave_anonima
SUPABASE_SERVICE_ROLE_KEY=sua_chave_servico
ADMIN_EMAIL=admin@rubiagency.com
NEXT_PUBLIC_APP_URL=https://seu-dominio.vercel.app
\`\`\`

### Email (escolha uma opção):

#### Opção 1: SMTP
\`\`\`
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=seu-email@gmail.com
SMTP_PASS=sua-senha-app
EMAIL_FROM=seu-email@gmail.com
\`\`\`

#### Opção 2: Resend
\`\`\`
RESEND_API_KEY=sua_chave_resend
EMAIL_FROM=noreply@seu-dominio.com
\`\`\`

#### Opção 3: SendGrid
\`\`\`
SENDGRID_API_KEY=sua_chave_sendgrid
EMAIL_FROM=noreply@seu-dominio.com
\`\`\`

## 📊 Configuração do Banco de Dados

### Scripts SQL (executar em ordem):

1. `supabase-001-create-tables.sql` - Criar tabelas
2. `supabase-002-insert-default-data.sql` - Dados iniciais
3. `supabase-003-add-attachments-column.sql` - Coluna anexos
4. `supabase-004-create-storage-bucket.sql` - Bucket storage

### Configurar RLS (Row Level Security):

\`\`\`sql
-- Habilitar RLS nas tabelas
ALTER TABLE registrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE partners ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;

-- Políticas básicas (ajustar conforme necessário)
CREATE POLICY "Allow public insert on registrations" ON registrations
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow admin access" ON registrations
  FOR ALL USING (auth.role() = 'service_role');
\`\`\`

## 🧪 Testes Pós-Deploy

### 1. Testar Funcionalidades Básicas:
- [ ] Site carrega corretamente
- [ ] Formulário de contato funciona
- [ ] Imagens carregam
- [ ] Responsividade mobile

### 2. Testar Admin:
- [ ] Login admin (`/admin`)
- [ ] Dashboard carrega
- [ ] Listagem de registros
- [ ] Estatísticas aparecem

### 3. Testar Email:
- [ ] Envio de formulário gera email
- [ ] Notificações admin funcionam
- [ ] Templates estão corretos

## 🔍 Troubleshooting

### Erro de Build:
\`\`\`bash
# Limpar cache e reinstalar
rm -rf .next node_modules package-lock.json
npm install
npm run build
\`\`\`

### Erro de Banco:
- Verificar variáveis de ambiente
- Testar conexão no Supabase
- Verificar se tabelas existem

### Erro de Email:
- Verificar credenciais SMTP/API
- Testar com serviço de email
- Verificar logs da Vercel

### Erro 500:
- Verificar logs na Vercel
- Verificar variáveis de ambiente
- Testar APIs individualmente

## 📈 Monitoramento

### Vercel Dashboard:
- Logs de função
- Métricas de performance
- Uso de recursos

### Supabase Dashboard:
- Logs de banco
- Queries lentas
- Uso de storage

## 🔧 Manutenção

### Atualizações:
\`\`\`bash
# Atualizar dependências
npm update

# Testar localmente
npm run build
npm run dev

# Deploy nova versão
vercel --prod
\`\`\`

### Backup:
- Backup regular do Supabase
- Backup das variáveis de ambiente
- Backup do código fonte

## 📞 Suporte

Em caso de problemas:

1. Verificar logs da Vercel
2. Verificar logs do Supabase
3. Testar localmente
4. Verificar documentação
5. Contatar suporte técnico

---

**✅ Deploy concluído com sucesso!**

Seu site está agora rodando em produção na Vercel com todas as funcionalidades ativas.
