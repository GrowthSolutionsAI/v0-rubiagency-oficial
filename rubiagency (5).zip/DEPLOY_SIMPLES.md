# 🚀 DEPLOY SIMPLES - RUBI AGENCY

## SITUAÇÃO ATUAL
- Você tem vários teams no Vercel (growth-rubi-agency, growth-rubi)
- Está no plano Hobby, não Premium
- Tem vários projetos duplicados
- Precisa subir o site AGORA

## SOLUÇÃO RÁPIDA - 3 PASSOS

### PASSO 1: USAR O PROJETO QUE JÁ EXISTE
Vejo que você já tem o projeto `v0-rubiagency-lancamento` na sua dashboard.
- Clique nele
- Vá em Settings
- Configure as variáveis de ambiente

### PASSO 2: VARIÁVEIS DE AMBIENTE (COPIE E COLE)
\`\`\`
NEXT_PUBLIC_SUPABASE_URL=https://lovnfxbjqclblzizokcn.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxvdm5meGJqcWNsYmx6aXpva2NuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzQ5NzI2NzEsImV4cCI6MjA1MDU0ODY3MX0.8VZQQQxQQxQQxQQxQQxQQxQQxQQxQQxQQxQQxQQxQQxQ
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxvdm5meGJqcWNsYmx6aXpva2NuIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTczNDk3MjY3MSwiZXhwIjoyMDUwNTQ4NjcxfQ.SERVICE_ROLE_KEY_HERE
EMAIL_FROM=contato@rubiagency.com
SMTP_HOST=smtp.gmail.com
SMTP_PORT=465
SMTP_SECURE=true
SMTP_USER=contato@rubiagency.com
SMTP_PASS=ymxmutrfrtzkeice
NEXT_PUBLIC_APP_URL=https://rubiagency.vercel.app
ADMIN_EMAIL=admin@rubiagency.com
\`\`\`

### PASSO 3: REDEPLOY
- Vá na aba Deployments
- Clique em "Redeploy"
- Aguarde 2-3 minutos

## SE NÃO FUNCIONAR - PLANO B

### OPÇÃO 1: VERCEL CLI (MAIS RÁPIDO)
\`\`\`bash
npm install -g vercel
vercel login
vercel
\`\`\`

### OPÇÃO 2: NETLIFY (ALTERNATIVA)
1. Vá em netlify.com
2. Arraste a pasta do projeto
3. Configure as mesmas variáveis

## DOMÍNIO
Depois que subir, configure:
- rubiagency.com
- www.rubiagency.com
