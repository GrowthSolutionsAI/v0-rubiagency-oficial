#!/bin/bash

# Rubi Agency - Automated Deployment Script
# This script handles the complete deployment process to Vercel

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo -e "\n${BLUE}================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}================================${NC}\n"
}

# Main deployment function
main() {
    print_header "🚀 RUBI AGENCY - AUTOMATED DEPLOYMENT"
    
    # Step 1: Check prerequisites
    print_status "Checking prerequisites..."
    
    # Check if Node.js is installed
    if ! command -v node &> /dev/null; then
        print_error "Node.js is not installed. Please install Node.js 18+ first."
        exit 1
    fi
    
    # Check Node.js version
    NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$NODE_VERSION" -lt 18 ]; then
        print_error "Node.js version 18+ is required. Current version: $(node --version)"
        exit 1
    fi
    
    print_success "Node.js $(node --version) is installed"
    
    # Check if npm is installed
    if ! command -v npm &> /dev/null; then
        print_error "npm is not installed. Please install npm first."
        exit 1
    fi
    
    print_success "npm $(npm --version) is installed"
    
    # Step 2: Install dependencies
    print_header "📦 INSTALLING DEPENDENCIES"
    
    if [ -f "package-lock.json" ]; then
        print_status "Using npm ci for faster, reliable, reproducible builds..."
        npm ci
    else
        print_status "Installing dependencies with npm install..."
        npm install
    fi
    
    print_success "Dependencies installed successfully"
    
    # Step 3: Run type checking
    print_header "🔍 TYPE CHECKING"
    
    print_status "Running TypeScript type checking..."
    if npm run type-check; then
        print_success "Type checking passed"
    else
        print_warning "Type checking failed, but continuing with deployment..."
    fi
    
    # Step 4: Build the project
    print_header "🏗️ BUILDING PROJECT"
    
    print_status "Building Next.js application..."
    if npm run build; then
        print_success "Build completed successfully"
    else
        print_error "Build failed. Please fix the errors and try again."
        exit 1
    fi
    
    # Step 5: Install Vercel CLI if not present
    print_header "⚡ VERCEL SETUP"
    
    if ! command -v vercel &> /dev/null; then
        print_status "Installing Vercel CLI..."
        npm install -g vercel@latest
        print_success "Vercel CLI installed"
    else
        print_success "Vercel CLI is already installed ($(vercel --version))"
    fi
    
    # Step 6: Check Vercel authentication
    print_status "Checking Vercel authentication..."
    
    if ! vercel whoami &> /dev/null; then
        print_warning "Not authenticated with Vercel. Please login..."
        vercel login
    else
        print_success "Already authenticated with Vercel as $(vercel whoami)"
    fi
    
    # Step 7: Deploy to Vercel
    print_header "🚀 DEPLOYING TO VERCEL"
    
    print_status "Starting deployment to Vercel..."
    
    # Deploy to production
    if vercel --prod --yes; then
        print_success "Deployment completed successfully!"
    else
        print_error "Deployment failed. Please check the logs above."
        exit 1
    fi
    
    # Step 8: Post-deployment tasks
    print_header "✅ POST-DEPLOYMENT"
    
    print_success "Deployment completed successfully!"
    
    # Get deployment URL
    DEPLOYMENT_URL=$(vercel ls --limit 1 | grep -o 'https://[^ ]*' | head -1)
    
    if [ -n "$DEPLOYMENT_URL" ]; then
        print_success "Your application is live at: $DEPLOYMENT_URL"
    fi
    
    # Step 9: Next steps
    print_header "📋 NEXT STEPS"
    
    echo -e "${YELLOW}Important: Configure the following environment variables in Vercel:${NC}"
    echo ""
    echo "🔐 Database Configuration:"
    echo "  - NEXT_PUBLIC_SUPABASE_URL"
    echo "  - SUPABASE_SERVICE_ROLE_KEY"
    echo "  - NEXT_PUBLIC_SUPABASE_ANON_KEY"
    echo ""
    echo "📧 Email Configuration (choose one):"
    echo "  - RESEND_API_KEY (recommended)"
    echo "  - SENDGRID_API_KEY"
    echo "  - SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS"
    echo ""
    echo "⚙️ General Configuration:"
    echo "  - ADMIN_EMAIL"
    echo "  - EMAIL_FROM"
    echo "  - NEXT_PUBLIC_APP_URL"
    echo ""
    echo -e "${BLUE}To configure environment variables:${NC}"
    echo "1. Go to https://vercel.com/dashboard"
    echo "2. Select your project"
    echo "3. Go to Settings > Environment Variables"
    echo "4. Add the required variables"
    echo "5. Redeploy the application"
    echo ""
    echo -e "${GREEN}🎉 Deployment completed successfully!${NC}"
    echo -e "${GREEN}Your Rubi Agency application is now live!${NC}"
}

# Error handling
trap 'print_error "Deployment failed at line $LINENO. Exit code: $?"' ERR

# Run main function
main "$@"
