# 🚀 Guia de Deploy - Rubi Agency

## 1. Preparação do Repositório

### Criar repositório no GitHub
\`\`\`bash
# 1. Inicializar Git (se ainda não foi feito)
git init

# 2. Adicionar todos os arquivos
git add .

# 3. Fazer commit inicial
git commit -m "feat: initial commit - Rubi Agency website"

# 4. Criar repositório no GitHub
# Vá para https://github.com/new
# Nome: rubiagency
# Descrição: Website oficial da Rubi Agency - Agência especializada em criação de conteúdo

# 5. Conectar repositório local ao GitHub
git remote add origin https://github.com/SEU_USUARIO/rubiagency.git
git branch -M main
git push -u origin main
\`\`\`

## 2. Deploy no Vercel

### Passo 1: Conectar Repositório
1. Acesse [vercel.com](https://vercel.com)
2. Faça login com sua conta GitHub
3. Clique em "New Project"
4. Selecione o repositório "rubiagency"
5. Clique em "Import"

### Passo 2: Configurar Projeto
\`\`\`
Framework Preset: Next.js
Root Directory: ./
Build Command: npm run build
Output Directory: .next
Install Command: npm install
\`\`\`

### Passo 3: Configurar Variáveis de Ambiente
Adicione as seguintes variáveis no Vercel:

\`\`\`env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://lovnfxbjqclblzizokcn.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxvdm5meGJqcWNsYmx6aXpva2NuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTYwOTQ5NjQsImV4cCI6MjA3MTY3MDk2NH0.tfSvDLBTl5zZH9V8LK8H5Q6eSzY1AxEtE0iMFGqLK2E
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxvdm5meGJqcWNsYmx6aXpva2NuIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1NjA5NDk2NCwiZXhwIjoyMDcxNjcwOTY0fQ.FjEeJJtiV8utjnzpB9HvSl_9ALWNdZxRh9dWfjSrJT0

# Site
NEXT_PUBLIC_SITE_URL=https://rubiagency.com
NODE_ENV=production

# Admin
ADMIN_USERNAME=admin
ADMIN_PASSWORD=RubiAdmin@2024!
JWT_SECRET=rubi-agency-super-secret-jwt-key-production-2024

# Email (opcional)
CONTACT_EMAIL=contato@rubiagency.com
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=contato@rubiagency.com
SMTP_PASS=your-gmail-app-password

# Analytics (opcional)
NEXT_PUBLIC_GA_ID=G-XXXXXXXXXX
NEXT_PUBLIC_META_PIXEL_ID=123456789
\`\`\`

### Passo 4: Deploy
1. Clique em "Deploy"
2. Aguarde o build completar (2-5 minutos)
3. Acesse a URL temporária gerada

## 3. Configurar Domínio Personalizado

### No Vercel:
1. Vá para o projeto no dashboard
2. Clique em "Settings" > "Domains"
3. Adicione "rubiagency.com"
4. Adicione "www.rubiagency.com" (redirect para apex)

### No seu provedor de domínio:
\`\`\`
Tipo: A
Nome: @
Valor: 76.76.19.61

Tipo: CNAME
Nome: www
Valor: cname.vercel-dns.com
\`\`\`

## 4. Configurar Supabase

### Executar Scripts SQL:
1. Acesse [supabase.com](https://supabase.com)
2. Vá para o projeto
3. Clique em "SQL Editor"
4. Execute os scripts na ordem:

\`\`\`sql
-- Script 1: Criar tabelas
-- (Cole o conteúdo de scripts/supabase-001-create-tables.sql)

-- Script 2: Inserir dados padrão
-- (Cole o conteúdo de scripts/supabase-002-insert-default-data.sql)
\`\`\`

## 5. Verificações Pós-Deploy

### Checklist:
- [ ] Site carrega em https://rubiagency.com
- [ ] Formulário de contato funciona
- [ ] Admin acessível em /admin/login
- [ ] Blog carrega corretamente
- [ ] Supabase conectado
- [ ] SSL ativo
- [ ] Redirects funcionando

### URLs para testar:
- https://rubiagency.com
- https://rubiagency.com/admin/login
- https://rubiagency.com/blog
- https://rubiagency.com/sitemap.xml
- https://rubiagency.com/robots.txt

## 6. Monitoramento

### Logs do Vercel:
- Functions logs
- Build logs
- Analytics

### Supabase Dashboard:
- Database health
- API usage
- Auth logs

## 7. Comandos Úteis

\`\`\`bash
# Deploy local para teste
npm run build
npm run start

# Verificar build
npm run lint
npm run type-check

# Logs do Vercel CLI
npx vercel logs
npx vercel env ls
\`\`\`

## 8. Troubleshooting

### Problemas Comuns:

**Build falha:**
- Verificar variáveis de ambiente
- Verificar sintaxe TypeScript
- Verificar imports

**Supabase não conecta:**
- Verificar URLs e chaves
- Verificar RLS policies
- Verificar network

**Domínio não funciona:**
- Verificar DNS propagation
- Verificar SSL certificate
- Verificar redirects

## 9. Próximos Passos

Após deploy bem-sucedido:
1. Configurar Google Analytics
2. Configurar Meta Pixel
3. Configurar email SMTP
4. Configurar backups
5. Configurar monitoring
6. SEO optimization
