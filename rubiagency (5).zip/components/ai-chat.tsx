"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { MessageCircle, X, Send, Bot, User } from "lucide-react"

interface Message {
  id: string
  text: string
  sender: "user" | "ai"
  timestamp: Date
}

export default function AIChat() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Olá! Eu sou a Rubi, sua assistente virtual da Rubi Agency! 💎 Como posso ajudá-la hoje? Posso esclarecer dúvidas sobre nossos serviços, processo de seleção, ou qualquer outra questão sobre sua carreira como criadora de conteúdo.",
      sender: "ai",
      timestamp: new Date(),
    },
  ])
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // Base de conhecimento da IA Rubi
  const knowledgeBase = {
    servicos: {
      keywords: ["serviços", "serviço", "oferece", "fazem", "trabalho", "gestão", "marketing", "networking"],
      response:
        "Oferecemos uma gama completa de serviços premium: 🌟 Gestão de Carreira Premium com planejamento estratégico personalizado, 📱 Marketing Digital Exclusivo para redes sociais e branding pessoal, 🤝 Networking de Elite com acesso a contatos premium, 📋 Contratos Seguros com assessoria jurídica, 💄 Consultoria de Imagem profissional, e 🎓 Desenvolvimento Profissional com workshops exclusivos. Qual serviço te interessa mais?",
    },
    precos: {
      keywords: ["preço", "valor", "custa", "investimento", "taxa", "comissão", "quanto"],
      response:
        "Nossos investimentos são personalizados conforme o pacote de serviços escolhido. 💰 Trabalhamos com diferentes modalidades: planos mensais, anuais e comissões sobre projetos. Para conhecer os valores específicos para seu perfil, recomendo agendar uma consulta gratuita através do nosso formulário de contato. Assim posso apresentar a proposta ideal para seus objetivos! 📊",
    },
    processo: {
      keywords: ["processo", "seleção", "como", "começar", "iniciar", "candidatar", "inscrever"],
      response:
        "O processo é bem simples e profissional! 📝 1) Preencha nosso formulário de pré-seleção com suas informações e portfólio, 2) Nossa equipe analisa seu perfil em até 48h, 3) Se aprovada, agendamos uma entrevista online, 4) Definimos o plano ideal para seus objetivos, 5) Começamos a trabalhar juntas! Todo o processo é gratuito e sem compromisso inicial. Quer iniciar agora?",
    },
    experiencia: {
      keywords: ["experiência", "iniciante", "começando", "nova", "sem experiência", "primeira vez"],
      response:
        "Perfeito! 🌟 Adoramos trabalhar com talentos iniciantes! Não se preocupe se está começando - nossa especialidade é justamente desenvolver carreiras do zero. Temos programas específicos para iniciantes com: mentoria individual, treinamentos básicos, construção de portfólio profissional e introdução gradual ao mercado. Muitas de nossas top performers começaram sem experiência alguma! 💪",
    },
    seguranca: {
      keywords: ["seguro", "segurança", "proteção", "confiável", "legítimo", "golpe"],
      response:
        "Sua segurança é nossa prioridade máxima! 🛡️ Somos uma agência estabelecida há mais de 10 anos, com registro legal completo. Oferecemos: contratos transparentes, assessoria jurídica, ambiente de trabalho seguro, proteção de dados pessoais, e nunca solicitamos pagamentos antecipados. Todas as negociações passam por nossa equipe jurídica. Pode confiar na Rubi Agency! ✨",
    },
    idade: {
      keywords: ["idade", "anos", "maior", "menor", "jovem", "madura"],
      response:
        "Trabalhamos exclusivamente com criadoras maiores de 18 anos! 🔞 Não há limite máximo de idade - valorizamos a diversidade e temos talentos de todas as idades fazendo sucesso. O que importa é sua dedicação, profissionalismo e vontade de crescer. Cada faixa etária tem seu público e oportunidades específicas! 💎",
    },
    ganhos: {
      keywords: ["ganho", "ganhar", "dinheiro", "renda", "salário", "lucro", "faturamento"],
      response:
        "Os ganhos variam muito conforme dedicação, nicho e estratégia! 💰 Nossas criadoras iniciantes costumam faturar entre R$ 2.000-8.000/mês, intermediárias R$ 8.000-25.000/mês, e as top performers podem superar R$ 50.000/mês! Oferecemos suporte completo para maximizar seus resultados com estratégias comprovadas. Lembre-se: seu sucesso é nosso sucesso! 📈",
    },
    contato: {
      keywords: ["contato", "falar", "telefone", "whatsapp", "email", "endereço"],
      response:
        "Você pode entrar em contato conosco de várias formas! 📞 WhatsApp: +55 (11) 99999-9999, 📧 Email: contato@rubiagency.com, 📍 Escritório: Av. Paulista, 1000 - São Paulo/SP. Nosso horário de atendimento é de segunda a sexta, das 9h às 18h. Para emergências, temos suporte 24h pelo WhatsApp! 🕐",
    },
    default: {
      keywords: [],
      response:
        "Interessante! 🤔 Embora eu não tenha uma resposta específica para essa pergunta, posso te ajudar com informações sobre nossos serviços, processo de seleção, segurança, ganhos, ou qualquer dúvida sobre carreira como criadora de conteúdo. Ou se preferir, posso te conectar com nossa equipe humana para um atendimento mais personalizado! Como posso ajudar melhor? 💎",
    },
  }

  const generateAIResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase()

    // Procura por palavras-chave na mensagem
    for (const [category, data] of Object.entries(knowledgeBase)) {
      if (category === "default") continue

      const hasKeyword = data.keywords.some((keyword) => message.includes(keyword.toLowerCase()))

      if (hasKeyword) {
        return data.response
      }
    }

    // Resposta padrão se não encontrar palavras-chave
    return knowledgeBase.default.response
  }

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setIsTyping(true)

    // Simula delay de digitação da IA
    setTimeout(
      () => {
        const aiResponse: Message = {
          id: (Date.now() + 1).toString(),
          text: generateAIResponse(inputValue),
          sender: "ai",
          timestamp: new Date(),
        }

        setMessages((prev) => [...prev, aiResponse])
        setIsTyping(false)
      },
      1500 + Math.random() * 1000,
    ) // Delay variável para parecer mais natural
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  return (
    <>
      {/* Chat Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            className="fixed bottom-6 right-6 z-50"
          >
            <Button
              onClick={() => setIsOpen(true)}
              className="h-16 w-16 rounded-full bg-gradient-to-r from-primary to-gold hover:from-primary/90 hover:to-gold/90 shadow-lg hover:shadow-xl transition-all duration-300 group"
              aria-label="Abrir chat com Rubi"
            >
              <div className="relative">
                <MessageCircle className="h-6 w-6 text-white group-hover:scale-110 transition-transform" />
                <div className="absolute -top-1 -right-1 h-3 w-3 bg-green-500 rounded-full animate-pulse"></div>
              </div>
            </Button>

            {/* Tooltip */}
            <div className="absolute bottom-20 right-0 bg-black/95 text-white px-4 py-2 rounded-lg text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none shadow-lg border border-white/10">
              Fale com a Rubi! 💎
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.8 }}
            className="fixed bottom-4 right-4 w-80 sm:w-96 h-[500px] sm:h-[600px] z-50 max-w-[calc(100vw-2rem)] max-h-[calc(100vh-2rem)]"
          >
            <div className="glass-effect rounded-2xl premium-border h-full flex flex-col overflow-hidden">
              {/* Header */}
              <div className="p-4 border-b border-white/20 bg-gradient-to-r from-primary/30 to-gold/30 backdrop-blur-sm">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <div className="h-10 w-10 rounded-full bg-gradient-to-r from-gold to-primary flex items-center justify-center shadow-lg">
                        <Bot className="h-5 w-5 text-white" />
                      </div>
                      <div className="absolute -bottom-1 -right-1 h-3 w-3 bg-green-500 rounded-full border-2 border-black animate-pulse"></div>
                    </div>
                    <div>
                      <h3 className="text-white font-semibold text-base">Rubi</h3>
                      <p className="text-platinum/80 text-xs">Assistente Virtual • Online</p>
                    </div>
                  </div>
                  <Button
                    onClick={() => setIsOpen(false)}
                    variant="ghost"
                    size="sm"
                    className="text-platinum/80 hover:text-white hover:bg-white/20 rounded-full h-8 w-8 p-0"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Messages */}
              <ScrollArea className="flex-1 p-3 sm:p-4">
                <div className="space-y-3">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[85%] rounded-2xl px-3 py-2 sm:px-4 sm:py-3 ${
                          message.sender === "user"
                            ? "bg-gradient-to-r from-primary to-gold text-white shadow-lg"
                            : "bg-white/15 text-white border border-white/10 backdrop-blur-sm"
                        }`}
                      >
                        <div className="flex items-start gap-2">
                          {message.sender === "ai" && <Bot className="h-4 w-4 text-gold mt-1 flex-shrink-0" />}
                          {message.sender === "user" && <User className="h-4 w-4 text-white mt-1 flex-shrink-0" />}
                          <p className="text-sm leading-relaxed break-words">{message.text}</p>
                        </div>
                        <p className="text-xs opacity-70 mt-2 text-right">
                          {message.timestamp.toLocaleTimeString("pt-BR", {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                      </div>
                    </div>
                  ))}

                  {/* Typing Indicator */}
                  {isTyping && (
                    <div className="flex justify-start">
                      <div className="bg-white/15 rounded-2xl px-4 py-3 max-w-[85%] border border-white/10 backdrop-blur-sm">
                        <div className="flex items-center gap-2">
                          <Bot className="h-4 w-4 text-gold" />
                          <div className="flex gap-1">
                            <div className="w-2 h-2 bg-gold rounded-full animate-bounce"></div>
                            <div
                              className="w-2 h-2 bg-gold rounded-full animate-bounce"
                              style={{ animationDelay: "0.1s" }}
                            ></div>
                            <div
                              className="w-2 h-2 bg-gold rounded-full animate-bounce"
                              style={{ animationDelay: "0.2s" }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                <div ref={messagesEndRef} />
              </ScrollArea>

              {/* Input */}
              <div className="p-3 sm:p-4 border-t border-white/20 bg-black/20 backdrop-blur-sm">
                <div className="flex gap-2">
                  <Input
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Digite sua mensagem..."
                    className="bg-white/10 border-white/20 focus:border-gold text-white placeholder:text-platinum/60 rounded-xl text-sm backdrop-blur-sm"
                    disabled={isTyping}
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={!inputValue.trim() || isTyping}
                    className="btn-primary px-3 rounded-xl flex-shrink-0 shadow-lg"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-platinum/60 mt-2 text-center">
                  Rubi está aqui para ajudar com suas dúvidas! ✨
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
