"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Calendar, User, ArrowRight, Search, Filter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useLanguage } from "@/contexts/language-context"
import Image from "next/image"
import { useState } from "react"

export default function Blog() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })
  const { t } = useLanguage()
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")

  const blogPosts = [
    {
      id: 1,
      title: "Como Maximizar seus Ganhos no Mercado Digital",
      excerpt: "Estratégias comprovadas para aumentar sua receita e construir uma carreira sólida no ambiente digital.",
      image: "/placeholder.svg?height=300&width=400",
      author: "Equipe Rubi",
      date: "15 Mar 2024",
      category: "career",
      readTime: "5 min",
    },
    {
      id: 2,
      title: "Construindo uma Marca Pessoal Forte",
      excerpt: "Dicas essenciais para desenvolver uma identidade única e atrativa nas redes sociais.",
      image: "/placeholder.svg?height=300&width=400",
      author: "Especialista Marketing",
      date: "12 Mar 2024",
      category: "marketing",
      readTime: "7 min",
    },
    {
      id: 3,
      title: "Segurança e Privacidade Online",
      excerpt: "Proteja-se no ambiente digital com nossas dicas de segurança e privacidade.",
      image: "/placeholder.svg?height=300&width=400",
      author: "Consultor Segurança",
      date: "10 Mar 2024",
      category: "tips",
      readTime: "4 min",
    },
    {
      id: 4,
      title: "Tendências do Mercado para 2024",
      excerpt: "Descubra as principais tendências que vão dominar o mercado digital este ano.",
      image: "/placeholder.svg?height=300&width=400",
      author: "Analista Mercado",
      date: "8 Mar 2024",
      category: "trends",
      readTime: "6 min",
    },
    {
      id: 5,
      title: "Histórias de Sucesso: Julia Moreira",
      excerpt: "Conheça a jornada inspiradora de uma de nossas criadoras mais bem-sucedidas.",
      image: "/placeholder.svg?height=300&width=400",
      author: "Rubi Agency",
      date: "5 Mar 2024",
      category: "success",
      readTime: "8 min",
    },
    {
      id: 6,
      title: "Networking Estratégico no Mercado Digital",
      excerpt: "Como construir relacionamentos valiosos que impulsionam sua carreira.",
      image: "/placeholder.svg?height=300&width=400",
      author: "Especialista Networking",
      date: "3 Mar 2024",
      category: "career",
      readTime: "5 min",
    },
  ]

  const categories = [
    { id: "all", name: "Todos" },
    { id: "career", name: "Carreira" },
    { id: "marketing", name: "Marketing" },
    { id: "tips", name: "Dicas" },
    { id: "trends", name: "Tendências" },
    { id: "success", name: "Sucesso" },
  ]

  const filteredPosts = blogPosts.filter((post) => {
    const matchesSearch =
      post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || post.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const featuredPosts = filteredPosts.slice(0, 3)
  const allPosts = filteredPosts

  return (
    <section id="blog" className="section-padding section-bg-gradient relative overflow-hidden">
      {/* Background pattern with red accents */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,rgba(239,68,68,0.15),transparent_50%)]"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_70%,rgba(220,38,38,0.1),transparent_50%)]"></div>
      </div>

      <div className="container mx-auto container-padding relative z-10">
        {/* Section Header */}
        <div className="text-center mb-20 lg:mb-28">
          <motion.div
            className="inline-flex items-center gap-3 mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6 }}
          >
            <div className="h-px w-12 bg-gradient-to-r from-transparent to-red-500"></div>
            <span className="text-overline text-red-500">Conteúdo Exclusivo</span>
            <div className="h-px w-12 bg-gradient-to-l from-transparent to-red-500"></div>
          </motion.div>

          <motion.h2
            className="text-headline text-white mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Blog da <span className="text-gradient">Rubi Agency</span>
          </motion.h2>

          <motion.p
            className="text-body-large text-platinum/80 max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            Conteúdo especializado para criadoras que querem crescer profissionalmente. Dicas, estratégias e insights
            exclusivos para maximizar seu sucesso no mercado digital.
          </motion.p>
        </div>

        {/* Search and Filter */}
        <motion.div
          className="flex flex-col md:flex-row gap-6 mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-platinum/60" />
            <Input
              type="text"
              placeholder="Buscar artigos, dicas, estratégias..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 bg-black/20 border-platinum/20 text-white placeholder:text-platinum/60 focus:border-red-500/50 h-12"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
                  selectedCategory === category.id
                    ? "bg-red-500 text-white"
                    : "bg-black/20 text-platinum/80 hover:bg-red-500/20 hover:text-red-400 border border-platinum/20"
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Featured Posts */}
        {featuredPosts.length > 0 && (
          <div className="mb-20">
            <motion.h3
              className="text-title text-white mb-12 text-center"
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.6, delay: 0.8 }}
            >
              Artigos em Destaque
            </motion.h3>

            <div ref={ref} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredPosts.map((post, index) => (
                <motion.article
                  key={post.id}
                  className="group glass-effect rounded-2xl overflow-hidden premium-border hover-lift"
                  initial={{ opacity: 0, y: 30 }}
                  animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                  transition={{ duration: 0.5, delay: 0.1 * index }}
                >
                  <div className="relative overflow-hidden">
                    <Image
                      src={post.image || "/placeholder.svg"}
                      alt={post.title}
                      width={400}
                      height={300}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                    <div className="absolute top-4 left-4">
                      <span className="bg-red-500/90 text-white text-xs font-semibold px-3 py-1 rounded-full">
                        {categories.find((c) => c.id === post.category)?.name}
                      </span>
                    </div>
                  </div>

                  <div className="p-6">
                    <div className="flex items-center gap-4 text-platinum/60 text-sm mb-4">
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4" />
                        <span>{post.author}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        <span>{post.date}</span>
                      </div>
                      <span>{post.readTime}</span>
                    </div>

                    <h3 className="text-xl font-bold text-white mb-3 group-hover:text-red-400 transition-colors duration-300">
                      {post.title}
                    </h3>

                    <p className="text-platinum/80 leading-relaxed mb-6">{post.excerpt}</p>

                    <Button
                      variant="ghost"
                      className="text-red-500 hover:text-white hover:bg-red-500/20 p-0 h-auto font-semibold"
                    >
                      Ler mais
                      <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform duration-300" />
                    </Button>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        )}

        {/* All Posts */}
        {allPosts.length > 3 && (
          <div className="mb-20">
            <motion.h3
              className="text-title text-white mb-12 text-center"
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.6, delay: 1.0 }}
            >
              Todos os Artigos
            </motion.h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {allPosts.slice(3).map((post, index) => (
                <motion.article
                  key={post.id}
                  className="group glass-effect p-6 rounded-2xl premium-border hover-lift flex gap-6"
                  initial={{ opacity: 0, y: 30 }}
                  animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                  transition={{ duration: 0.5, delay: 0.1 * index }}
                >
                  <div className="relative w-24 h-24 flex-shrink-0 rounded-lg overflow-hidden">
                    <Image
                      src={post.image || "/placeholder.svg"}
                      alt={post.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center gap-2 text-platinum/60 text-xs mb-2">
                      <span className="bg-red-500/20 text-red-400 px-2 py-1 rounded">
                        {categories.find((c) => c.id === post.category)?.name}
                      </span>
                      <span>{post.date}</span>
                      <span>•</span>
                      <span>{post.readTime}</span>
                    </div>

                    <h3 className="text-lg font-bold text-white mb-2 group-hover:text-red-400 transition-colors duration-300">
                      {post.title}
                    </h3>

                    <p className="text-platinum/80 text-sm leading-relaxed mb-3">{post.excerpt.substring(0, 100)}...</p>

                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-red-500 hover:text-white hover:bg-red-500/20 p-0 h-auto font-semibold text-sm"
                    >
                      Ler
                      <ArrowRight className="h-3 w-3 ml-1" />
                    </Button>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        )}

        {/* No Results */}
        {filteredPosts.length === 0 && (
          <motion.div
            className="text-center py-20"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6 }}
          >
            <Filter className="h-16 w-16 text-platinum/40 mx-auto mb-6" />
            <h3 className="text-title text-white mb-4">Nenhum artigo encontrado</h3>
            <p className="text-platinum/80 mb-8">Tente ajustar sua busca ou filtros.</p>
            <Button
              onClick={() => {
                setSearchTerm("")
                setSelectedCategory("all")
              }}
              className="btn-conversion text-white font-semibold px-8 py-3 rounded-xl"
            >
              Limpar Filtros
            </Button>
          </motion.div>
        )}

        {/* Newsletter Signup */}
        <motion.div
          className="text-center"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6, delay: 1.2 }}
        >
          <div className="glass-effect p-10 lg:p-12 rounded-2xl premium-border max-w-4xl mx-auto">
            <h3 className="text-title text-white mb-6">Receba Conteúdo Exclusivo</h3>
            <p className="text-body text-platinum/80 mb-8 leading-relaxed">
              Inscreva-se em nossa newsletter e receba dicas exclusivas, estratégias avançadas e novidades do mercado
              diretamente em seu email.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <Input
                type="email"
                placeholder="Seu melhor email"
                className="flex-1 bg-black/20 border-platinum/20 text-white placeholder:text-platinum/60 focus:border-red-500/50"
              />
              <Button className="btn-conversion text-white font-semibold px-8 py-3 rounded-xl">Inscrever-se</Button>
            </div>
            <p className="text-platinum/60 text-sm mt-4">Sem spam. Cancele a qualquer momento.</p>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
