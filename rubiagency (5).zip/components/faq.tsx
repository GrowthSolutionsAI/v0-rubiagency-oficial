"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Plus, Minus } from "lucide-react"
import { useLanguage } from "@/contexts/language-context"
import { useState } from "react"

export default function FAQ() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })
  const { t } = useLanguage()
  const [openItems, setOpenItems] = useState<number[]>([0])

  const toggleItem = (index: number) => {
    setOpenItems((prev) => (prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]))
  }

  const faqItems = [
    {
      question: "Como funciona o processo de seleção da Rubi Agency?",
      answer:
        "Nosso processo de seleção é cuidadoso e personalizado. Após o preenchimento do formulário de pré-seleção, nossa equipe analisa seu perfil, experiência e objetivos. Em seguida, realizamos uma entrevista para conhecer melhor suas expectativas e explicar como podemos ajudar no desenvolvimento da sua carreira.",
    },
    {
      question: "Quais são os requisitos para trabalhar com a Rubi Agency?",
      answer:
        "Os requisitos básicos incluem: ter mais de 18 anos, possuir documentos válidos, ter perfil ativo no Instagram, disponibilidade para dedicar tempo à carreira e estar comprometida com o crescimento profissional. Valorizamos a autenticidade, profissionalismo e vontade de crescer.",
    },
    {
      question: "Como a Rubi Agency me ajuda a aumentar meus ganhos?",
      answer:
        "Oferecemos estratégias personalizadas de marketing digital, gestão profissional de redes sociais, networking exclusivo, negociação de contratos vantajosos e orientação para diversificação de receitas. Nossa abordagem foca em maximizar seu potencial de forma sustentável e profissional.",
    },
    {
      question: "A Rubi Agency oferece suporte jurídico?",
      answer:
        "Sim, oferecemos assessoria jurídica especializada para proteção dos nossos talentos. Isso inclui revisão de contratos, orientações sobre direitos autorais, proteção de imagem e suporte em questões legais relacionadas à sua atividade profissional.",
    },
    {
      question: "Como funciona o acompanhamento e mentoria?",
      answer:
        "Cada talento recebe acompanhamento personalizado com reuniões regulares, análise de performance, orientação estratégica e suporte contínuo. Nossa equipe está disponível para esclarecer dúvidas, oferecer feedback e ajustar estratégias conforme necessário.",
    },
    {
      question: "Qual é o investimento para trabalhar com a Rubi Agency?",
      answer:
        "Trabalhamos com um modelo de parceria baseado em resultados. Não cobramos taxas antecipadas. Nossa remuneração está diretamente ligada ao seu sucesso, garantindo que estamos sempre alinhados com seus objetivos de crescimento e rentabilidade.",
    },
    {
      question: "A Rubi Agency trabalha com modelos iniciantes?",
      answer:
        "Sim, trabalhamos com talentos em diferentes estágios de carreira, incluindo iniciantes. Oferecemos programas de desenvolvimento específicos para quem está começando, com treinamentos, orientações e suporte especializado para construir uma base sólida.",
    },
    {
      question: "Como posso manter minha privacidade e segurança?",
      answer:
        "A privacidade e segurança são prioridades absolutas. Oferecemos orientações sobre proteção de dados pessoais, uso seguro de plataformas digitais, gestão de privacidade online e estratégias para manter o equilíbrio entre vida pessoal e profissional.",
    },
  ]

  return (
    <section id="faq" className="section-padding section-bg-gradient relative overflow-hidden">
      {/* Background pattern with red accents */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(239,68,68,0.15),transparent_50%)]"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_80%,rgba(220,38,38,0.1),transparent_50%)]"></div>
      </div>

      <div className="container mx-auto container-padding relative z-10">
        {/* Section Header */}
        <div className="text-center mb-20 lg:mb-28">
          <motion.div
            className="inline-flex items-center gap-3 mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6 }}
          >
            <div className="h-px w-12 bg-gradient-to-r from-transparent to-red-500"></div>
            <span className="text-overline text-red-500">Dúvidas Frequentes</span>
            <div className="h-px w-12 bg-gradient-to-l from-transparent to-red-500"></div>
          </motion.div>

          <motion.h2
            className="text-headline text-white mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Perguntas <span className="text-gradient">Frequentes</span>
          </motion.h2>

          <motion.p
            className="text-body-large text-platinum/80 max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            Esclarecemos as principais dúvidas sobre nossos serviços, processo de seleção e como podemos transformar sua
            carreira no mercado digital.
          </motion.p>
        </div>

        {/* FAQ Items */}
        <div ref={ref} className="max-w-4xl mx-auto">
          {faqItems.map((item, index) => (
            <motion.div
              key={index}
              className="mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.5, delay: 0.1 * index }}
            >
              <div className="glass-effect rounded-2xl premium-border overflow-hidden">
                <button
                  onClick={() => toggleItem(index)}
                  className="w-full p-6 lg:p-8 text-left flex items-center justify-between hover:bg-white/5 transition-colors duration-300"
                >
                  <h3 className="text-lg lg:text-xl font-semibold text-white pr-4">{item.question}</h3>
                  <div className="flex-shrink-0">
                    {openItems.includes(index) ? (
                      <Minus className="h-6 w-6 text-red-500" />
                    ) : (
                      <Plus className="h-6 w-6 text-red-500" />
                    )}
                  </div>
                </button>

                <motion.div
                  initial={false}
                  animate={{
                    height: openItems.includes(index) ? "auto" : 0,
                    opacity: openItems.includes(index) ? 1 : 0,
                  }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                  className="overflow-hidden"
                >
                  <div className="px-6 lg:px-8 pb-6 lg:pb-8">
                    <div className="h-px bg-gradient-to-r from-red-500/20 to-transparent mb-6"></div>
                    <p className="text-platinum/80 leading-relaxed">{item.answer}</p>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Contact CTA */}
        <motion.div
          className="text-center mt-20"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <div className="glass-effect p-10 lg:p-12 rounded-2xl premium-border max-w-2xl mx-auto">
            <h3 className="text-title text-white mb-6">Ainda tem dúvidas?</h3>
            <p className="text-body text-platinum/80 mb-8 leading-relaxed">
              Nossa equipe está pronta para esclarecer todas as suas questões e ajudar você a dar o próximo passo na sua
              carreira.
            </p>
            <a
              href="#contact"
              className="inline-flex items-center gap-2 bg-gradient-to-r from-red-600 via-red-500 to-red-400 hover:from-red-700 hover:via-red-600 hover:to-red-500 text-white font-semibold px-8 py-4 rounded-xl transition-all duration-300 hover:scale-105"
            >
              Entre em Contato
              <Plus className="h-4 w-4" />
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
