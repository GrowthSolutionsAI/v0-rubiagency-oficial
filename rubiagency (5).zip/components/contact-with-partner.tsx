"use client"

import { Suspense } from "react"
import Contact from "./contact"

function ContactFallback() {
  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-pink-50 to-purple-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Entre em{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-purple-600">
                Contato
              </span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">Carregando formulário...</p>
          </div>
          <div className="animate-pulse">
            <div className="bg-white rounded-lg shadow-2xl p-8">
              <div className="space-y-4">
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                <div className="h-10 bg-gray-200 rounded"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                <div className="h-10 bg-gray-200 rounded"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                <div className="h-32 bg-gray-200 rounded"></div>
                <div className="h-12 bg-gray-200 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default function ContactWithPartner() {
  return (
    <Suspense fallback={<ContactFallback />}>
      <Contact />
    </Suspense>
  )
}
