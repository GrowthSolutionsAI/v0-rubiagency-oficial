"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ArrowRight, Play, Star, Users, Award, TrendingUp } from "lucide-react"
import { useLanguage } from "@/contexts/language-context"

export default function Hero() {
  const { t } = useLanguage()
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const scrollToContact = () => {
    const contactSection = document.getElementById("contact")
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: "smooth" })
    }
  }

  const scrollToAbout = () => {
    const aboutSection = document.getElementById("about")
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background with Gradients */}
      <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-black">
        {/* Image Background */}
        <div className="absolute inset-0">
          <Image
            src="/hero-julia-moraes.jpg"
            alt="Professional model showcasing elegance and confidence"
            fill
            className="object-cover object-center"
            priority
            quality={95}
          />
          {/* Gradient Overlays */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/60"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 via-transparent to-red-600/20"></div>
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/90"></div>
        </div>

        {/* Animated Background Elements */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-red-600/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-red-600/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-screen py-20">
          {/* Left Content */}
          <div
            className={`space-y-8 transition-all duration-1000 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
          >
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-red-600/20 backdrop-blur-sm border border-red-500/30 rounded-full px-4 py-2 text-red-200">
              <Star className="h-4 w-4 text-red-400" />
              <span className="text-sm font-medium">Agência Premium de Modelos</span>
            </div>

            {/* Main Heading */}
            <div className="space-y-4">
              <h1 className="text-5xl sm:text-6xl lg:text-7xl xl:text-8xl font-bold font-playfair leading-[0.9] tracking-tight">
                <span className="text-white block">Transforme</span>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-red-600 block">
                  Sua Carreira
                </span>
                <span className="text-white block">em Sucesso</span>
              </h1>

              <p className="text-xl sm:text-2xl text-gray-300 max-w-2xl leading-relaxed font-light">
                Conectamos talentos excepcionais com as melhores oportunidades do mercado. Sua jornada para o estrelato
                começa aqui.
              </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 py-6">
              <div className="text-center">
                <div className="text-3xl sm:text-4xl font-bold text-white font-playfair">500+</div>
                <div className="text-sm text-gray-400 font-medium">Modelos Ativas</div>
              </div>
              <div className="text-center">
                <div className="text-3xl sm:text-4xl font-bold text-white font-playfair">1000+</div>
                <div className="text-sm text-gray-400 font-medium">Campanhas</div>
              </div>
              <div className="text-center">
                <div className="text-3xl sm:text-4xl font-bold text-white font-playfair">98%</div>
                <div className="text-sm text-gray-400 font-medium">Satisfação</div>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                onClick={scrollToContact}
                size="lg"
                className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-semibold px-8 py-4 rounded-xl shadow-lg transform transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-red-600/25 text-lg h-14"
              >
                Começar Agora
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>

              <Button
                onClick={scrollToAbout}
                variant="outline"
                size="lg"
                className="border-2 border-white/30 text-white hover:bg-white/10 hover:border-white/50 backdrop-blur-sm font-semibold px-8 py-4 rounded-xl transition-all duration-300 hover:scale-105 text-lg h-14 bg-transparent"
              >
                <Play className="mr-2 h-5 w-5" />
                Saiba Mais
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="flex items-center gap-6 pt-6 border-t border-white/10">
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-red-400" />
                <span className="text-sm text-gray-300">Comunidade Ativa</span>
              </div>
              <div className="flex items-center gap-2">
                <Award className="h-5 w-5 text-red-400" />
                <span className="text-sm text-gray-300">Premiada</span>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-red-400" />
                <span className="text-sm text-gray-300">Em Crescimento</span>
              </div>
            </div>
          </div>

          {/* Right Content - Image Showcase */}
          <div
            className={`relative transition-all duration-1000 delay-300 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"}`}
          >
            <div className="relative">
              {/* Main Image Container */}
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <div className="aspect-[3/4] relative">
                  <Image
                    src="/hero-julia-moraes.jpg"
                    alt="Professional model portrait"
                    fill
                    className="object-cover object-center"
                    quality={95}
                  />
                  {/* Subtle overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent"></div>
                </div>
              </div>

              {/* Floating Elements */}
              <div className="absolute -top-6 -right-6 bg-white/10 backdrop-blur-sm rounded-2xl p-4 border border-white/20">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                  <span className="text-white text-sm font-medium">Disponível</span>
                </div>
              </div>

              <div className="absolute -bottom-6 -left-6 bg-red-600/90 backdrop-blur-sm rounded-2xl p-4 border border-red-500/30">
                <div className="text-white">
                  <div className="text-2xl font-bold font-playfair">4.9★</div>
                  <div className="text-sm opacity-90">Avaliação</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/50 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  )
}
