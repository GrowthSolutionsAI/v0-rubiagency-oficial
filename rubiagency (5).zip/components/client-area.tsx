"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  User,
  Calendar,
  DollarSign,
  TrendingUp,
  Camera,
  Settings,
  Download,
  Eye,
  Star,
  Lock,
  LogIn,
  UserPlus,
} from "lucide-react"

export default function ClientArea() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [loginForm, setLoginForm] = useState({ email: "", password: "" })
  const [activeTab, setActiveTab] = useState("dashboard")

  // Dados simulados do cliente
  const clientData = {
    name: "Isabella Santos",
    email: "isabella@email.com",
    memberSince: "Janeiro 2023",
    status: "Premium",
    profileCompletion: 85,
    totalEarnings: 15420.5,
    monthlyEarnings: 3250.0,
    totalSessions: 24,
    rating: 4.9,
    nextSession: "15 Dez, 14:00",
  }

  const recentSessions = [
    {
      id: 1,
      client: "Revista Glamour",
      date: "10 Dez 2024",
      type: "Editorial",
      status: "Concluído",
      earnings: 850.0,
      rating: 5,
    },
    {
      id: 2,
      client: "Brand Luxury",
      date: "08 Dez 2024",
      type: "Campanha Digital",
      status: "Concluído",
      earnings: 1200.0,
      rating: 5,
    },
    {
      id: 3,
      client: "Fashion Week SP",
      date: "05 Dez 2024",
      type: "Runway",
      status: "Concluído",
      earnings: 950.0,
      rating: 4,
    },
  ]

  const upcomingOpportunities = [
    {
      id: 1,
      title: "Campanha Verão 2025",
      client: "Beachwear Brand",
      date: "20 Dez 2024",
      payment: "R$ 2.500",
      type: "Editorial",
    },
    {
      id: 2,
      title: "Ensaio Artístico",
      client: "Art Gallery SP",
      date: "22 Dez 2024",
      payment: "R$ 1.800",
      type: "Artístico",
    },
  ]

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    // Simular login
    setIsLoggedIn(true)
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setLoginForm({ email: "", password: "" })
  }

  if (!isLoggedIn) {
    return (
      <section id="client-area" className="section-padding premium-gradient relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(220,38,38,0.1),transparent_50%)]"></div>
        </div>

        <div className="container mx-auto container-padding relative z-10">
          <div className="text-center mb-20">
            <motion.div
              className="inline-flex items-center gap-3 mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.6 }}
            >
              <div className="h-px w-12 bg-gradient-to-r from-transparent to-gold"></div>
              <span className="text-overline text-gold">Portal Exclusivo</span>
              <div className="h-px w-12 bg-gradient-to-l from-transparent to-gold"></div>
            </motion.div>

            <motion.h2
              className="text-headline text-white mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              Área do <span className="text-gradient">Cliente</span>
            </motion.h2>

            <motion.p
              className="text-body-large text-platinum/80 max-w-4xl mx-auto"
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              Acesse seu portal exclusivo para gerenciar sua carreira, acompanhar ganhos e descobrir novas
              oportunidades.
            </motion.p>
          </div>

          <div ref={ref} className="max-w-md mx-auto">
            <motion.div
              className="glass-effect p-10 rounded-2xl premium-border"
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-center mb-8">
                <div className="p-4 bg-gradient-to-br from-gold/20 to-primary/20 rounded-full w-16 h-16 mx-auto mb-4">
                  <Lock className="h-8 w-8 text-gold" />
                </div>
                <h3 className="text-title text-white mb-2">Acesso Restrito</h3>
                <p className="text-body text-platinum/80">Entre com suas credenciais para acessar sua área exclusiva</p>
              </div>

              <form onSubmit={handleLogin} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-platinum/90">
                    Email
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={loginForm.email}
                    onChange={(e) => setLoginForm((prev) => ({ ...prev, email: e.target.value }))}
                    placeholder="seu@email.com"
                    required
                    className="bg-white/5 border-white/10 focus:border-gold text-white placeholder:text-platinum/50 rounded-lg"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-platinum/90">
                    Senha
                  </Label>
                  <Input
                    id="password"
                    type="password"
                    value={loginForm.password}
                    onChange={(e) => setLoginForm((prev) => ({ ...prev, password: e.target.value }))}
                    placeholder="••••••••"
                    required
                    className="bg-white/5 border-white/10 focus:border-gold text-white placeholder:text-platinum/50 rounded-lg"
                  />
                </div>

                <Button type="submit" className="w-full btn-primary text-white font-semibold py-3 rounded-xl">
                  <LogIn className="h-4 w-4 mr-2" />
                  ENTRAR
                </Button>
              </form>

              <div className="mt-8 text-center">
                <p className="text-platinum/60 text-sm mb-4">Ainda não é cliente?</p>
                <Button asChild variant="outline" className="btn-secondary text-platinum rounded-xl">
                  <a href="#contact" className="flex items-center gap-2">
                    <UserPlus className="h-4 w-4" />
                    INICIAR PRÉ-SELEÇÃO
                  </a>
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section id="client-area" className="section-padding premium-gradient relative overflow-hidden">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(220,38,38,0.1),transparent_50%)]"></div>
      </div>

      <div className="container mx-auto container-padding relative z-10">
        {/* Header */}
        <div className="flex justify-between items-center mb-12">
          <div>
            <h1 className="text-headline text-white mb-2">Bem-vinda, {clientData.name}!</h1>
            <p className="text-body text-platinum/80">Membro desde {clientData.memberSince}</p>
          </div>
          <div className="flex items-center gap-4">
            <Badge className="bg-gold/20 text-gold border-gold/30">{clientData.status}</Badge>
            <Button onClick={handleLogout} variant="outline" className="btn-secondary">
              Sair
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid w-full grid-cols-5 bg-white/5 rounded-xl p-1">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-gold/20 data-[state=active]:text-gold">
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="sessions" className="data-[state=active]:bg-gold/20 data-[state=active]:text-gold">
              Sessões
            </TabsTrigger>
            <TabsTrigger value="opportunities" className="data-[state=active]:bg-gold/20 data-[state=active]:text-gold">
              Oportunidades
            </TabsTrigger>
            <TabsTrigger value="portfolio" className="data-[state=active]:bg-gold/20 data-[state=active]:text-gold">
              Portfólio
            </TabsTrigger>
            <TabsTrigger value="profile" className="data-[state=active]:bg-gold/20 data-[state=active]:text-gold">
              Perfil
            </TabsTrigger>
          </TabsList>

          {/* Dashboard */}
          <TabsContent value="dashboard" className="space-y-8">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="glass-effect border-white/10">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-platinum/80 flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-gold" />
                    Ganhos Totais
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">
                    R$ {clientData.totalEarnings.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                  </div>
                  <p className="text-xs text-platinum/60 mt-1">+12% este mês</p>
                </CardContent>
              </Card>

              <Card className="glass-effect border-white/10">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-platinum/80 flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-gold" />
                    Este Mês
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">
                    R$ {clientData.monthlyEarnings.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                  </div>
                  <p className="text-xs text-platinum/60 mt-1">3 sessões concluídas</p>
                </CardContent>
              </Card>

              <Card className="glass-effect border-white/10">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-platinum/80 flex items-center gap-2">
                    <Camera className="h-4 w-4 text-gold" />
                    Total de Sessões
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{clientData.totalSessions}</div>
                  <p className="text-xs text-platinum/60 mt-1">Desde o início</p>
                </CardContent>
              </Card>

              <Card className="glass-effect border-white/10">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-platinum/80 flex items-center gap-2">
                    <Star className="h-4 w-4 text-gold" />
                    Avaliação
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{clientData.rating}</div>
                  <p className="text-xs text-platinum/60 mt-1">Média geral</p>
                </CardContent>
              </Card>
            </div>

            {/* Profile Completion */}
            <Card className="glass-effect border-white/10">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <User className="h-5 w-5 text-gold" />
                  Completude do Perfil
                </CardTitle>
                <CardDescription className="text-platinum/70">
                  Complete seu perfil para receber mais oportunidades
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-platinum/80">Progresso</span>
                    <span className="text-gold font-medium">{clientData.profileCompletion}%</span>
                  </div>
                  <Progress value={clientData.profileCompletion} className="h-2" />
                  <div className="text-sm text-platinum/60">
                    Adicione mais fotos ao seu portfólio para alcançar 100%
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Sessions */}
            <Card className="glass-effect border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Sessões Recentes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentSessions.map((session) => (
                    <div key={session.id} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                      <div>
                        <h4 className="text-white font-medium">{session.client}</h4>
                        <p className="text-platinum/60 text-sm">
                          {session.date} • {session.type}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-gold font-semibold">
                          R$ {session.earnings.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                        </div>
                        <div className="flex items-center gap-1">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-3 w-3 ${i < session.rating ? "fill-gold text-gold" : "text-platinum/30"}`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Sessions */}
          <TabsContent value="sessions" className="space-y-6">
            <Card className="glass-effect border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Histórico de Sessões</CardTitle>
                <CardDescription className="text-platinum/70">
                  Todas as suas sessões e ganhos detalhados
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentSessions.map((session) => (
                    <div
                      key={session.id}
                      className="flex items-center justify-between p-6 bg-white/5 rounded-xl hover:bg-white/10 transition-colors"
                    >
                      <div className="flex items-center gap-4">
                        <div className="p-3 bg-gradient-to-br from-gold/20 to-primary/20 rounded-lg">
                          <Camera className="h-5 w-5 text-gold" />
                        </div>
                        <div>
                          <h4 className="text-white font-medium">{session.client}</h4>
                          <p className="text-platinum/60 text-sm">
                            {session.date} • {session.type}
                          </p>
                          <Badge className="mt-1 bg-green-500/20 text-green-400 border-green-500/30">
                            {session.status}
                          </Badge>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-gold font-semibold text-lg">
                          R$ {session.earnings.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                        </div>
                        <div className="flex items-center gap-1 justify-end">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-3 w-3 ${i < session.rating ? "fill-gold text-gold" : "text-platinum/30"}`}
                            />
                          ))}
                        </div>
                        <Button variant="outline" size="sm" className="mt-2 btn-secondary">
                          <Download className="h-3 w-3 mr-1" />
                          Recibo
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Opportunities */}
          <TabsContent value="opportunities" className="space-y-6">
            <Card className="glass-effect border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Oportunidades Disponíveis</CardTitle>
                <CardDescription className="text-platinum/70">
                  Novas oportunidades selecionadas especialmente para você
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {upcomingOpportunities.map((opportunity) => (
                    <div key={opportunity.id} className="p-6 bg-white/5 rounded-xl hover:bg-white/10 transition-colors">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h4 className="text-white font-medium text-lg">{opportunity.title}</h4>
                          <p className="text-platinum/60">{opportunity.client}</p>
                        </div>
                        <Badge className="bg-gold/20 text-gold border-gold/30">{opportunity.type}</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-4 text-sm text-platinum/70">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {opportunity.date}
                          </span>
                          <span className="flex items-center gap-1">
                            <DollarSign className="h-4 w-4" />
                            {opportunity.payment}
                          </span>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" className="btn-secondary">
                            <Eye className="h-3 w-3 mr-1" />
                            Detalhes
                          </Button>
                          <Button size="sm" className="btn-primary">
                            Candidatar-se
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Portfolio */}
          <TabsContent value="portfolio" className="space-y-6">
            <Card className="glass-effect border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Meu Portfólio</CardTitle>
                <CardDescription className="text-platinum/70">
                  Gerencie suas fotos e materiais profissionais
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {[...Array(8)].map((_, i) => (
                    <div key={i} className="relative aspect-square rounded-lg overflow-hidden group cursor-pointer">
                      <Image
                        src={`/placeholder.svg?height=200&width=200`}
                        alt={`Portfolio ${i + 1}`}
                        fill
                        className="object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Eye className="h-6 w-6 text-white" />
                      </div>
                    </div>
                  ))}
                </div>
                <Button className="w-full mt-6 btn-primary">
                  <Camera className="h-4 w-4 mr-2" />
                  Adicionar Fotos
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Profile */}
          <TabsContent value="profile" className="space-y-6">
            <Card className="glass-effect border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Configurações do Perfil</CardTitle>
                <CardDescription className="text-platinum/70">
                  Atualize suas informações pessoais e preferências
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label className="text-platinum/90">Nome Completo</Label>
                    <Input
                      value={clientData.name}
                      className="bg-white/5 border-white/10 focus:border-gold text-white rounded-lg"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-platinum/90">Email</Label>
                    <Input
                      value={clientData.email}
                      className="bg-white/5 border-white/10 focus:border-gold text-white rounded-lg"
                    />
                  </div>
                </div>
                <Button className="btn-primary">
                  <Settings className="h-4 w-4 mr-2" />
                  Salvar Alterações
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  )
}
