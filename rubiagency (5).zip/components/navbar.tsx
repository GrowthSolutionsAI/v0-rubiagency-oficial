"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLanguage } from "@/contexts/language-context"
import LanguageSelector from "./language-selector"

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)
  const { t } = useLanguage()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const navItems = [
    { name: t("nav.home"), href: "#home" },
    { name: t("nav.about"), href: "#about" },
    { name: t("nav.services"), href: "#services" },
    { name: t("nav.testimonials"), href: "#testimonials" },
    { name: t("nav.blog"), href: "#blog" },
    { name: t("nav.contact"), href: "#contact" },
  ]

  const handleNavClick = (href: string) => {
    setIsOpen(false)

    if (href.startsWith("#")) {
      if (window.location.pathname !== "/") {
        window.location.href = "/" + href
        return
      }

      const element = document.querySelector(href)
      if (element) {
        element.scrollIntoView({ behavior: "smooth" })
      }
    }
  }

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-in-out ${
        isScrolled
          ? "bg-white/85 backdrop-blur-xl border-b border-gray-200/50 shadow-lg shadow-black/5"
          : "bg-white border-b border-gray-100"
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center justify-start group">
            <div className="relative flex items-center justify-center h-14 w-auto group-hover:scale-105 transition-transform duration-300">
              <Image
                src="/rubi-agency-new-logo.png"
                alt="Rubi Agency"
                width={120}
                height={48}
                className="object-contain"
                priority
              />
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            {navItems.map((item) => (
              <button
                key={item.name}
                onClick={() => handleNavClick(item.href)}
                className="text-gray-900 hover:text-red-600 transition-colors duration-300 font-medium text-sm tracking-wide relative group py-2"
              >
                {item.name}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-red-600 transition-all duration-300 group-hover:w-full rounded-full"></span>
              </button>
            ))}
          </div>

          {/* Right Side - Language Selector & CTA */}
          <div className="hidden lg:flex items-center space-x-4">
            <LanguageSelector />
            <Button
              onClick={() => handleNavClick("#contact")}
              className="bg-red-600 hover:bg-red-700 text-white font-medium px-6 py-2.5 rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl hover:shadow-red-600/25 transform hover:-translate-y-0.5"
            >
              {t("nav.login")}
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center space-x-4">
            <LanguageSelector />
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-900 hover:text-red-600 transition-colors duration-300 p-2 rounded-lg hover:bg-gray-50"
              aria-label="Toggle menu"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <div
          className={`lg:hidden transition-all duration-300 overflow-hidden ${
            isOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
          }`}
        >
          <div className="py-4 space-y-2 border-t border-gray-100">
            {navItems.map((item) => (
              <button
                key={item.name}
                onClick={() => handleNavClick(item.href)}
                className="block w-full text-left text-gray-900 hover:text-red-600 hover:bg-gray-50 transition-colors duration-300 font-medium py-3 px-4 rounded-lg"
              >
                {item.name}
              </button>
            ))}
            <div className="pt-4 border-t border-gray-100">
              <Button
                onClick={() => handleNavClick("#contact")}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-medium py-3 rounded-lg transition-all duration-300"
              >
                {t("nav.login")}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  )
}
