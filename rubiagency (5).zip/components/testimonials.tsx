"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import Image from "next/image"
import { Star, Quote } from "lucide-react"
import { useLanguage } from "@/contexts/language-context"

export default function Testimonials() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })
  const { t } = useLanguage()

  const testimonials = [
    {
      name: t("testimonials.testimonial1.name"),
      role: t("testimonials.testimonial1.role"),
      image: "/images/testimonial-isabela.png",
      quote: t("testimonials.testimonial1.quote"),
      rating: 5,
    },
    {
      name: t("testimonials.testimonial2.name"),
      role: t("testimonials.testimonial2.role"),
      image: "/images/testimonial-julia.png",
      quote: t("testimonials.testimonial2.quote"),
      rating: 5,
    },
    {
      name: t("testimonials.testimonial3.name"),
      role: t("testimonials.testimonial3.role"),
      image: "/images/testimonial-camila.png",
      quote: t("testimonials.testimonial3.quote"),
      rating: 5,
    },
  ]

  return (
    <section id="testimonials" className="section-padding section-gradient textured-bg relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 opacity-5">
        <div
          className="absolute top-10 right-20 w-40 h-40 bg-red-500/10 rounded-full animate-float"
          style={{ animationDelay: "1s" }}
        ></div>
        <div
          className="absolute bottom-32 left-16 w-28 h-28 bg-red-500/10 rounded-full animate-float"
          style={{ animationDelay: "3s" }}
        ></div>
        <div className="absolute top-1/3 right-1/4 w-20 h-20 bg-red-500/10 rounded-full animate-pulse-slow"></div>
      </div>

      {/* Background image with overlay */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-black/80 z-10"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-black via-transparent to-black z-20"></div>
      </div>

      <div className="container mx-auto container-padding relative z-30">
        {/* Section Header */}
        <div className="text-center mb-20 lg:mb-28">
          <motion.div
            className="inline-flex items-center gap-3 mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6 }}
          >
            <div className="h-px w-12 bg-gradient-to-r from-transparent to-red-500 animate-pulse-slow"></div>
            <span className="text-overline text-red-500 animate-fade-in-up-delay">{t("testimonials.overline")}</span>
            <div className="h-px w-12 bg-gradient-to-l from-transparent to-red-500 animate-pulse-slow"></div>
          </motion.div>

          <motion.h2
            className="text-headline text-white mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {t("testimonials.title")}{" "}
            <span className="text-gradient animate-gradient">{t("testimonials.title.highlight")}</span>
          </motion.h2>

          <motion.p
            className="text-body-large text-platinum/80 max-w-4xl mx-auto leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            {t("testimonials.subtitle")}
          </motion.p>
        </div>

        {/* Testimonials Grid */}
        <div ref={ref} className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-10">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              className="bg-black/40 p-8 rounded-2xl testimonial-card-border hover-lift hover-glow relative overflow-hidden group"
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.5, delay: 0.1 * index }}
              whileHover={{ scale: 1.02 }}
            >
              {/* Background gradient on hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 to-red-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

              {/* Quote icon */}
              <motion.div
                className="absolute top-6 right-6 text-red-500/20 group-hover:text-red-500/40 transition-colors duration-300"
                animate={{ rotate: [0, 5, -5, 0] }}
                transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse" }}
              >
                <Quote className="h-12 w-12" />
              </motion.div>

              <div className="relative z-10 space-y-6">
                {/* Rating */}
                <motion.div
                  className="flex items-center gap-1 mb-2"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={inView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.8 }}
                  transition={{ duration: 0.5, delay: 0.2 * index }}
                >
                  {[...Array(5)].map((_, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, scale: 0 }}
                      animate={inView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0 }}
                      transition={{ duration: 0.3, delay: 0.1 * index + 0.1 * i }}
                    >
                      <Star
                        className={`h-4 w-4 ${
                          i < testimonial.rating ? "fill-red-500 text-red-500" : "fill-muted text-muted-foreground"
                        }`}
                      />
                    </motion.div>
                  ))}
                </motion.div>

                {/* Quote */}
                <motion.p
                  className="text-body text-platinum/90 italic leading-relaxed"
                  initial={{ opacity: 0 }}
                  animate={inView ? { opacity: 1 } : { opacity: 0 }}
                  transition={{ duration: 0.6, delay: 0.3 * index }}
                >
                  "{testimonial.quote}"
                </motion.p>

                {/* Author */}
                <motion.div
                  className="flex items-center gap-4 pt-4"
                  initial={{ opacity: 0, x: -20 }}
                  animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
                  transition={{ duration: 0.5, delay: 0.4 * index }}
                >
                  <div className="relative h-16 w-16 rounded-full overflow-hidden border-2 border-red-500/20 group-hover:border-red-500/40 transition-colors duration-300">
                    <Image
                      src={testimonial.image || "/placeholder.svg"}
                      alt={testimonial.name}
                      fill
                      className="object-cover transition-transform duration-300 group-hover:scale-110"
                    />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white group-hover:text-red-400 transition-colors duration-300">
                      {testimonial.name}
                    </h4>
                    <p className="text-caption text-platinum/70">{testimonial.role}</p>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
