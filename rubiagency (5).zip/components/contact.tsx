"use client"

import type React from "react"

import { useState, useRef, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Upload,
  X,
  CheckCircle,
  AlertCircle,
  Loader2,
  Mail,
  Phone,
  Instagram,
  User,
  MessageCircle,
  Paperclip,
  FileImage,
  FileText,
  Star,
} from "lucide-react"
import { useLanguage } from "@/contexts/language-context"

interface FormData {
  name: string
  email: string
  phone: string
  instagram: string
  message: string
}

interface FileWithPreview {
  file: File
  preview: string
  type: "image" | "pdf"
}

export default function Contact() {
  const { t } = useLanguage()
  const [formData, setFormData] = useState<FormData>({
    name: "",
    email: "",
    phone: "",
    instagram: "",
    message: "",
  })
  const [files, setFiles] = useState<FileWithPreview[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [error, setError] = useState("")
  const [submittedData, setSubmittedData] = useState<any>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Validação dos campos
  const validateForm = () => {
    if (!formData.name.trim()) return "Nome é obrigatório"
    if (!formData.email.trim()) return "Email é obrigatório"
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) return "Email inválido"
    if (!formData.phone.trim()) return "Telefone é obrigatório"
    if (!formData.message.trim()) return "Mensagem é obrigatória"
    return null
  }

  // Validação de arquivos
  const validateFile = (file: File): string | null => {
    const allowedTypes = ["image/png", "image/jpeg", "image/jpg", "application/pdf"]
    const maxSize = 5 * 1024 * 1024 // 5MB

    if (!allowedTypes.includes(file.type)) {
      return "Tipo de arquivo não permitido. Use PNG, JPEG ou PDF."
    }

    if (file.size > maxSize) {
      return "Arquivo muito grande. Máximo 5MB."
    }

    return null
  }

  // Adicionar arquivos
  const handleFileSelect = useCallback(
    (selectedFiles: FileList) => {
      const newFiles: FileWithPreview[] = []

      Array.from(selectedFiles).forEach((file) => {
        if (files.length + newFiles.length >= 3) {
          setError("Máximo 3 arquivos permitidos")
          return
        }

        const validation = validateFile(file)
        if (validation) {
          setError(validation)
          return
        }

        const preview = file.type.startsWith("image/") ? URL.createObjectURL(file) : ""
        const type = file.type.startsWith("image/") ? "image" : "pdf"

        newFiles.push({ file, preview, type })
      })

      if (newFiles.length > 0) {
        setFiles((prev) => [...prev, ...newFiles])
        setError("")
      }
    },
    [files.length],
  )

  // Drag and Drop
  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      const droppedFiles = e.dataTransfer.files
      if (droppedFiles.length > 0) {
        handleFileSelect(droppedFiles)
      }
    },
    [handleFileSelect],
  )

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
  }, [])

  // Remover arquivo
  const removeFile = (index: number) => {
    setFiles((prev) => {
      const newFiles = prev.filter((_, i) => i !== index)
      // Limpar URL do preview
      if (prev[index].preview) {
        URL.revokeObjectURL(prev[index].preview)
      }
      return newFiles
    })
  }

  // Formatar Instagram
  const handleInstagramChange = (value: string) => {
    let formatted = value.replace(/[^a-zA-Z0-9._]/g, "")
    if (formatted && !formatted.startsWith("@")) {
      formatted = "@" + formatted
    }
    setFormData((prev) => ({ ...prev, instagram: formatted }))
  }

  // Submit do formulário
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    // Validar formulário
    const validation = validateForm()
    if (validation) {
      setError(validation)
      setIsLoading(false)
      return
    }

    try {
      // Preparar FormData para multipart
      const submitData = new FormData()
      submitData.append("name", formData.name.trim())
      submitData.append("email", formData.email.trim().toLowerCase())
      submitData.append("phone", formData.phone.trim())
      submitData.append("instagram", formData.instagram.trim())
      submitData.append("message", formData.message.trim())

      // Adicionar arquivos
      files.forEach((fileWithPreview, index) => {
        submitData.append(`file_${index}`, fileWithPreview.file)
      })

      console.log("📤 Enviando formulário:", {
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        instagram: formData.instagram,
        filesCount: files.length,
      })

      // Enviar para API
      const response = await fetch("/api/contact", {
        method: "POST",
        body: submitData,
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || "Erro ao enviar formulário")
      }

      console.log("✅ Formulário enviado com sucesso:", result)

      // Salvar dados para tela de sucesso
      setSubmittedData({
        ...formData,
        id: result.id,
        attachments: result.attachments || [],
        filesCount: files.length,
      })

      // Limpar formulário
      setFormData({
        name: "",
        email: "",
        phone: "",
        instagram: "",
        message: "",
      })
      setFiles([])
      setIsSuccess(true)
    } catch (error) {
      console.error("❌ Erro ao enviar formulário:", error)
      setError(error instanceof Error ? error.message : "Erro interno do servidor")
    } finally {
      setIsLoading(false)
    }
  }

  // Tela de sucesso
  if (isSuccess && submittedData) {
    return (
      <section id="contact" className="section-padding bg-gradient-to-b from-black via-gray-900 to-black">
        <div className="container mx-auto container-padding">
          <div className="max-w-2xl mx-auto text-center">
            <Card className="bg-gradient-to-br from-gray-900 to-black border border-green-500/30 shadow-2xl">
              <CardContent className="p-8">
                <div className="flex items-center justify-center w-16 h-16 bg-green-500 rounded-full mx-auto mb-6">
                  <CheckCircle className="h-8 w-8 text-white" />
                </div>

                <h2 className="text-3xl font-bold text-white mb-4">Candidatura Enviada com Sucesso! 🎉</h2>

                <p className="text-gray-300 mb-6 text-lg">
                  Obrigada por se candidatar à Rubi Agency! Recebemos sua candidatura e nossa equipe irá analisá-la em
                  breve.
                </p>

                {/* Resumo dos dados */}
                <div className="bg-black/30 rounded-lg p-6 mb-6 text-left">
                  <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Resumo da Candidatura:
                  </h3>

                  <div className="grid gap-3 text-sm">
                    <div className="flex items-center gap-2 text-gray-300">
                      <User className="h-4 w-4 text-red-400" />
                      <span className="font-medium">Nome:</span>
                      <span>{submittedData.name}</span>
                    </div>

                    <div className="flex items-center gap-2 text-gray-300">
                      <Mail className="h-4 w-4 text-red-400" />
                      <span className="font-medium">Email:</span>
                      <span>{submittedData.email}</span>
                    </div>

                    <div className="flex items-center gap-2 text-gray-300">
                      <Phone className="h-4 w-4 text-red-400" />
                      <span className="font-medium">Telefone:</span>
                      <span>{submittedData.phone}</span>
                    </div>

                    {submittedData.instagram && (
                      <div className="flex items-center gap-2 text-gray-300">
                        <Instagram className="h-4 w-4 text-red-400" />
                        <span className="font-medium">Instagram:</span>
                        <span>{submittedData.instagram}</span>
                      </div>
                    )}

                    {submittedData.filesCount > 0 && (
                      <div className="flex items-center gap-2 text-gray-300">
                        <Paperclip className="h-4 w-4 text-red-400" />
                        <span className="font-medium">Anexos:</span>
                        <span>{submittedData.filesCount} arquivo(s) enviado(s)</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4 mb-6">
                  <p className="text-blue-200 text-sm">
                    <strong>ID da Candidatura:</strong> #{submittedData.id}
                    <br />
                    <span className="text-xs">Guarde este número para futuras consultas</span>
                  </p>
                </div>

                <div className="space-y-3 text-gray-300 text-sm">
                  <p>📧 Você receberá um email de confirmação em breve</p>
                  <p>⏱️ Nossa equipe analisará sua candidatura em até 48 horas</p>
                  <p>📱 Acompanhe nosso Instagram para dicas e novidades</p>
                </div>

                <Button
                  onClick={() => {
                    setIsSuccess(false)
                    setSubmittedData(null)
                  }}
                  className="mt-6 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white px-8"
                >
                  Enviar Nova Candidatura
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    )
  }

  // Formulário principal
  return (
    <section id="contact" className="section-padding bg-gradient-to-b from-black via-gray-900 to-black textured-bg">
      <div className="container mx-auto container-padding">
        <div className="text-center mb-16">
          <Badge variant="outline" className="premium-border text-red-400 bg-red-500/10 px-4 py-2 mb-4">
            <Star className="w-4 h-4 mr-2" />
            Candidate-se Agora
          </Badge>

          <h2 className="text-headline text-white mb-6">
            Pronta para ser a Próxima
            <span className="text-red-gradient block">Estrela da Rubi?</span>
          </h2>

          <p className="text-body-large text-gray-300 max-w-3xl mx-auto">
            Preencha o formulário abaixo com suas informações e portfólio. Nossa equipe analisará sua candidatura e
            entrará em contato em até 48 horas.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="glass-effect premium-border shadow-2xl">
            <CardHeader>
              <CardTitle className="text-2xl text-white text-center">Formulário de Candidatura</CardTitle>
            </CardHeader>

            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Error Alert */}
                {error && (
                  <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 flex items-start gap-3">
                    <AlertCircle className="h-5 w-5 text-red-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-red-300 text-sm font-medium">Erro no formulário</p>
                      <p className="text-red-200 text-sm">{error}</p>
                    </div>
                  </div>
                )}

                <div className="grid md:grid-cols-2 gap-6">
                  {/* Nome */}
                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-white flex items-center gap-2">
                      <User className="h-4 w-4 text-red-400" />
                      Nome Completo *
                    </Label>
                    <Input
                      id="name"
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                      placeholder="Digite seu nome completo"
                      className="bg-black/30 border-white/20 text-white placeholder:text-gray-400 focus:border-red-500"
                      disabled={isLoading}
                      required
                    />
                  </div>

                  {/* Email */}
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-white flex items-center gap-2">
                      <Mail className="h-4 w-4 text-red-400" />
                      Email *
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                      placeholder="seu@email.com"
                      className="bg-black/30 border-white/20 text-white placeholder:text-gray-400 focus:border-red-500"
                      disabled={isLoading}
                      required
                    />
                  </div>

                  {/* Telefone */}
                  <div className="space-y-2">
                    <Label htmlFor="phone" className="text-white flex items-center gap-2">
                      <Phone className="h-4 w-4 text-red-400" />
                      Telefone/WhatsApp *
                    </Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData((prev) => ({ ...prev, phone: e.target.value }))}
                      placeholder="(11) 99999-9999"
                      className="bg-black/30 border-white/20 text-white placeholder:text-gray-400 focus:border-red-500"
                      disabled={isLoading}
                      required
                    />
                  </div>

                  {/* Instagram */}
                  <div className="space-y-2">
                    <Label htmlFor="instagram" className="text-white flex items-center gap-2">
                      <Instagram className="h-4 w-4 text-red-400" />
                      Instagram
                    </Label>
                    <Input
                      id="instagram"
                      type="text"
                      value={formData.instagram}
                      onChange={(e) => handleInstagramChange(e.target.value)}
                      placeholder="@seuusuario"
                      className="bg-black/30 border-white/20 text-white placeholder:text-gray-400 focus:border-red-500"
                      disabled={isLoading}
                    />
                  </div>
                </div>

                {/* Mensagem */}
                <div className="space-y-2">
                  <Label htmlFor="message" className="text-white flex items-center gap-2">
                    <MessageCircle className="h-4 w-4 text-red-400" />
                    Mensagem *
                  </Label>
                  <Textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => setFormData((prev) => ({ ...prev, message: e.target.value }))}
                    placeholder="Conte-nos sobre sua experiência, objetivos e por que quer fazer parte da Rubi Agency..."
                    rows={4}
                    className="bg-black/30 border-white/20 text-white placeholder:text-gray-400 focus:border-red-500 resize-none"
                    disabled={isLoading}
                    required
                  />
                </div>

                {/* Upload de arquivos */}
                <div className="space-y-4">
                  <Label className="text-white flex items-center gap-2">
                    <Paperclip className="h-4 w-4 text-red-400" />
                    Portfólio (Opcional - Máximo 3 arquivos)
                  </Label>

                  {/* Zona de drop */}
                  <div
                    onDrop={handleDrop}
                    onDragOver={handleDragOver}
                    className="border-2 border-dashed border-white/20 rounded-lg p-8 text-center hover:border-red-500/50 transition-colors cursor-pointer"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-white mb-2">Arraste arquivos aqui ou clique para selecionar</p>
                    <p className="text-sm text-gray-400">PNG, JPEG ou PDF • Máximo 5MB cada • Até 3 arquivos</p>

                    <input
                      ref={fileInputRef}
                      type="file"
                      multiple
                      accept="image/png,image/jpeg,image/jpg,application/pdf"
                      onChange={(e) => e.target.files && handleFileSelect(e.target.files)}
                      className="hidden"
                    />
                  </div>

                  {/* Preview dos arquivos */}
                  {files.length > 0 && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                      {files.map((fileWithPreview, index) => (
                        <div key={index} className="relative bg-black/30 rounded-lg p-4 border border-white/10">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-2 flex-1 min-w-0">
                              {fileWithPreview.type === "image" ? (
                                <FileImage className="h-4 w-4 text-blue-400 flex-shrink-0" />
                              ) : (
                                <FileText className="h-4 w-4 text-red-400 flex-shrink-0" />
                              )}
                              <span className="text-white text-sm truncate">{fileWithPreview.file.name}</span>
                            </div>
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => removeFile(index)}
                              className="text-gray-400 hover:text-red-400 p-1 h-auto flex-shrink-0"
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>

                          {fileWithPreview.preview && (
                            <div className="aspect-video bg-black/50 rounded overflow-hidden">
                              <img
                                src={fileWithPreview.preview || "/placeholder.svg"}
                                alt="Preview"
                                className="w-full h-full object-cover"
                              />
                            </div>
                          )}

                          <p className="text-xs text-gray-400 mt-2">
                            {(fileWithPreview.file.size / 1024 / 1024).toFixed(2)} MB
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Submit Button */}
                <div className="pt-6">
                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-semibold py-4 text-lg transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-red-500/25"
                  >
                    {isLoading ? (
                      <div className="flex items-center gap-2">
                        <Loader2 className="h-5 w-5 animate-spin" />
                        Enviando Candidatura...
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <Star className="h-5 w-5" />
                        Enviar Candidatura
                      </div>
                    )}
                  </Button>
                </div>

                {/* Informações */}
                <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4 mt-6">
                  <p className="text-blue-200 text-sm text-center">
                    🔒 Suas informações estão seguras conosco • ⏱️ Resposta em até 48 horas • 🌟 Processo gratuito
                  </p>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
