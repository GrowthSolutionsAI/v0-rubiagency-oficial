"use client"

import dynamic from "next/dynamic"
import { Skeleton } from "@/components/ui/skeleton"
import ClientOnly from "@/lib/client-only"

// Componente de loading para o gráfico
const ChartLoading = () => (
  <div className="h-64 w-full">
    <Skeleton className="h-full w-full" />
  </div>
)

// Import dinâmico do Recharts - APENAS NO CLIENTE
const ResponsiveContainer = dynamic(() => import("recharts").then((mod) => ({ default: mod.ResponsiveContainer })), {
  ssr: false,
  loading: ChartLoading,
})

const LineChart = dynamic(() => import("recharts").then((mod) => ({ default: mod.LineChart })), {
  ssr: false,
  loading: ChartLoading,
})

const Line = dynamic(() => import("recharts").then((mod) => ({ default: mod.Line })), {
  ssr: false,
  loading: () => null,
})

const XAxis = dynamic(() => import("recharts").then((mod) => ({ default: mod.XAxis })), {
  ssr: false,
  loading: () => null,
})

const YAxis = dynamic(() => import("recharts").then((mod) => ({ default: mod.YAxis })), {
  ssr: false,
  loading: () => null,
})

const CartesianGrid = dynamic(() => import("recharts").then((mod) => ({ default: mod.CartesianGrid })), {
  ssr: false,
  loading: () => null,
})

const Tooltip = dynamic(() => import("recharts").then((mod) => ({ default: mod.Tooltip })), {
  ssr: false,
  loading: () => null,
})

interface AnalyticsChartProps {
  data: Array<{
    name: string
    registrations: number
    approvals: number
  }>
}

export default function AnalyticsChart({ data }: AnalyticsChartProps) {
  return (
    <ClientOnly fallback={<ChartLoading />}>
      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="registrations" stroke="#8884d8" strokeWidth={2} name="Registros" />
            <Line type="monotone" dataKey="approvals" stroke="#82ca9d" strokeWidth={2} name="Aprovações" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </ClientOnly>
  )
}
