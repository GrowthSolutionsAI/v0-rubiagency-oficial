"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Share2, Facebook, Twitter, Linkedin, Copy, Check, MessageCircle } from "lucide-react"

interface ShareButtonsProps {
  url?: string
  title?: string
  description?: string
  className?: string
}

export default function ShareButtons({
  url = typeof window !== "undefined" ? window.location.href : "",
  title = "Rubi Agency - Agência Premium para Criadoras de Conteúdo",
  description = "Transforme sua sensualidade em um negócio profissional e rentável",
  className = "",
}: ShareButtonsProps) {
  const [copied, setCopied] = useState(false)

  const shareData = {
    title,
    text: description,
    url,
  }

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share(shareData)
      } catch (error) {
        console.log("Erro ao compartilhar:", error)
      }
    }
  }

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(url)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (error) {
      console.log("Erro ao copiar link:", error)
    }
  }

  const shareLinks = {
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
    twitter: `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}`,
    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`,
    whatsapp: `https://wa.me/?text=${encodeURIComponent(`${title} - ${url}`)}`,
  }

  const openShareWindow = (shareUrl: string) => {
    window.open(shareUrl, "_blank", "width=600,height=400,scrollbars=yes,resizable=yes")
  }

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      {/* Native Share (mobile) */}
      {typeof navigator !== "undefined" && navigator.share && (
        <Button variant="outline" size="sm" onClick={handleNativeShare} className="btn-secondary">
          <Share2 className="h-4 w-4" />
        </Button>
      )}

      {/* Facebook */}
      <Button
        variant="outline"
        size="sm"
        onClick={() => openShareWindow(shareLinks.facebook)}
        className="btn-secondary hover:bg-blue-600/20 hover:border-blue-600/50"
      >
        <Facebook className="h-4 w-4" />
      </Button>

      {/* Twitter */}
      <Button
        variant="outline"
        size="sm"
        onClick={() => openShareWindow(shareLinks.twitter)}
        className="btn-secondary hover:bg-sky-500/20 hover:border-sky-500/50"
      >
        <Twitter className="h-4 w-4" />
      </Button>

      {/* LinkedIn */}
      <Button
        variant="outline"
        size="sm"
        onClick={() => openShareWindow(shareLinks.linkedin)}
        className="btn-secondary hover:bg-blue-700/20 hover:border-blue-700/50"
      >
        <Linkedin className="h-4 w-4" />
      </Button>

      {/* WhatsApp */}
      <Button
        variant="outline"
        size="sm"
        onClick={() => openShareWindow(shareLinks.whatsapp)}
        className="btn-secondary hover:bg-green-600/20 hover:border-green-600/50"
      >
        <MessageCircle className="h-4 w-4" />
      </Button>

      {/* Copy Link */}
      <Button variant="outline" size="sm" onClick={handleCopyLink} className="btn-secondary">
        {copied ? <Check className="h-4 w-4 text-green-400" /> : <Copy className="h-4 w-4" />}
      </Button>
    </div>
  )
}
