"use client"

import Link from "next/link"
import Image from "next/image"
import { Facebook, Instagram, Twitter, Linkedin, Mail, Phone, MapPin } from "lucide-react"
import { useLanguage } from "@/contexts/language-context"

export default function Footer() {
  const { t } = useLanguage()

  const socialLinks = [
    { icon: Facebook, href: "#", label: "Facebook" },
    { icon: Instagram, href: "#", label: "Instagram" },
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Linkedin, href: "#", label: "LinkedIn" },
  ]

  const quickLinks = [
    { name: t("nav.home"), href: "#home" },
    { name: t("nav.about"), href: "#about" },
    { name: t("nav.services"), href: "#services" },
    { name: t("nav.contact"), href: "#contact" },
  ]

  const services = [
    { name: t("services.contentCreation"), href: "#services" },
    { name: t("services.socialMedia"), href: "#services" },
    { name: t("services.branding"), href: "#services" },
    { name: t("services.photography"), href: "#services" },
  ]

  const handleNavClick = (href: string) => {
    if (href.startsWith("#")) {
      if (window.location.pathname !== "/") {
        window.location.href = "/" + href
        return
      }

      const element = document.querySelector(href)
      if (element) {
        element.scrollIntoView({ behavior: "smooth" })
      }
    }
  }

  return (
    <footer className="relative bg-black overflow-hidden">
      {/* Background Gradients */}
      <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-black"></div>
      <div className="absolute inset-0 bg-gradient-to-t from-red-900/20 via-transparent to-transparent"></div>
      <div className="absolute inset-0 bg-gradient-to-r from-red-600/5 via-transparent to-red-600/5"></div>

      {/* Floating Elements */}
      <div className="absolute top-20 left-10 w-32 h-32 bg-red-600/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 right-10 w-40 h-40 bg-red-500/5 rounded-full blur-3xl animate-pulse delay-1000"></div>

      <div className="relative z-10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            {/* Logo and Description */}
            <div className="lg:col-span-1">
              <Link href="/" className="inline-block group mb-6">
                <div className="relative h-12 w-auto group-hover:scale-105 transition-transform duration-300">
                  <Image
                    src="/rubi-agency-new-logo.png"
                    alt="Rubi Agency"
                    width={120}
                    height={48}
                    className="object-contain brightness-0 invert"
                    style={{ filter: "brightness(0) invert(1)" }}
                  />
                </div>
              </Link>
              <p className="text-gray-300 text-sm leading-relaxed mb-6 font-light">{t("footer.description")}</p>
              <div className="flex space-x-4">
                {socialLinks.map((social, index) => (
                  <Link
                    key={index}
                    href={social.href}
                    className="w-10 h-10 bg-gray-800/50 hover:bg-red-600 rounded-lg flex items-center justify-center transition-all duration-300 group hover:scale-110 hover:shadow-lg hover:shadow-red-600/25"
                    aria-label={social.label}
                  >
                    <social.icon className="w-5 h-5 text-gray-400 group-hover:text-white transition-colors duration-300" />
                  </Link>
                ))}
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="text-white font-bold text-lg mb-6 relative">
                {t("footer.quickLinks")}
                <span className="absolute -bottom-2 left-0 w-8 h-0.5 bg-red-600 rounded-full"></span>
              </h3>
              <ul className="space-y-3">
                {quickLinks.map((link, index) => (
                  <li key={index}>
                    <button
                      onClick={() => handleNavClick(link.href)}
                      className="text-gray-300 hover:text-red-400 transition-colors duration-300 text-sm font-light hover:translate-x-1 transform inline-block"
                    >
                      {link.name}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Services */}
            <div>
              <h3 className="text-white font-bold text-lg mb-6 relative">
                {t("footer.services")}
                <span className="absolute -bottom-2 left-0 w-8 h-0.5 bg-red-600 rounded-full"></span>
              </h3>
              <ul className="space-y-3">
                {services.map((service, index) => (
                  <li key={index}>
                    <button
                      onClick={() => handleNavClick(service.href)}
                      className="text-gray-300 hover:text-red-400 transition-colors duration-300 text-sm font-light hover:translate-x-1 transform inline-block"
                    >
                      {service.name}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact Info */}
            <div>
              <h3 className="text-white font-bold text-lg mb-6 relative">
                {t("footer.contact")}
                <span className="absolute -bottom-2 left-0 w-8 h-0.5 bg-red-600 rounded-full"></span>
              </h3>
              <div className="space-y-4">
                <div className="flex items-start space-x-3 group">
                  <Mail className="w-5 h-5 text-red-500 mt-0.5 group-hover:scale-110 transition-transform duration-300" />
                  <div>
                    <p className="text-gray-300 text-sm font-light">contato@rubiagency.com</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3 group">
                  <Phone className="w-5 h-5 text-red-500 mt-0.5 group-hover:scale-110 transition-transform duration-300" />
                  <div>
                    <p className="text-gray-300 text-sm font-light">+55 (11) 99999-9999</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3 group">
                  <MapPin className="w-5 h-5 text-red-500 mt-0.5 group-hover:scale-110 transition-transform duration-300" />
                  <div>
                    <p className="text-gray-300 text-sm font-light">São Paulo, Brasil</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="border-t border-gray-800/50 mt-12 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
              <p className="text-gray-400 text-sm font-light">© 2024 Rubi Agency. {t("footer.rights")}</p>
              <div className="flex space-x-6">
                <Link
                  href="/privacy"
                  className="text-gray-400 hover:text-red-400 text-sm font-light transition-colors duration-300"
                >
                  {t("footer.privacy")}
                </Link>
                <Link
                  href="/terms"
                  className="text-gray-400 hover:text-red-400 text-sm font-light transition-colors duration-300"
                >
                  {t("footer.terms")}
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
