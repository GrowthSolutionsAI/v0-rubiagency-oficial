"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { RefreshCw, Users, UserCheck, UserX, Clock, CheckCircle, XCircle, AlertTriangle } from "lucide-react"

// ✅ COMPONENTE CLIENT-SIDE SEGURO
// Usa apenas APIs internas - nunca acessa SERVICE ROLE KEY diretamente

interface DashboardStats {
  total: number
  pending: number
  approved: number
  rejected: number
}

export default function AdminDashboardClient() {
  const [stats, setStats] = useState<DashboardStats>({
    total: 0,
    pending: 0,
    approved: 0,
    rejected: 0,
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date())

  // ✅ BUSCA DADOS VIA API INTERNA (Seguro)
  const loadStats = async () => {
    try {
      setLoading(true)
      setError(null)

      // ✅ Chama API interna que usa SERVICE ROLE KEY no servidor
      const response = await fetch("/api/admin/stats")

      if (!response.ok) {
        throw new Error(`Erro ${response.status}: ${response.statusText}`)
      }

      const data = await response.json()

      if (!data.success) {
        throw new Error(data.error || "Erro desconhecido")
      }

      setStats(data.stats)
      setLastUpdate(new Date())
    } catch (error) {
      console.error("Erro ao carregar estatísticas:", error)
      setError(error instanceof Error ? error.message : "Erro desconhecido")
    } finally {
      setLoading(false)
    }
  }

  // ✅ CARREGA DADOS NA INICIALIZAÇÃO
  useEffect(() => {
    loadStats()
  }, [])

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Dashboard Admin</h1>
          <p className="text-muted-foreground">Última atualização: {lastUpdate.toLocaleString("pt-BR")}</p>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={loadStats} disabled={loading} variant="outline">
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
            Atualizar
          </Button>
          {error && (
            <Badge variant="destructive">
              <XCircle className="h-3 w-3 mr-1" />
              Erro
            </Badge>
          )}
          {!error && !loading && (
            <Badge variant="default">
              <CheckCircle className="h-3 w-3 mr-1" />
              Online
            </Badge>
          )}
        </div>
      </div>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>Erro de Conexão:</strong> {error}
            <br />
            <small>Verifique se o Supabase está configurado corretamente.</small>
          </AlertDescription>
        </Alert>
      )}

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Registros</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{loading ? "..." : stats.total}</div>
            <p className="text-xs text-muted-foreground">Todos os registros no sistema</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pendentes</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{loading ? "..." : stats.pending}</div>
            <p className="text-xs text-muted-foreground">Aguardando aprovação</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Aprovados</CardTitle>
            <UserCheck className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{loading ? "..." : stats.approved}</div>
            <p className="text-xs text-muted-foreground">Registros aprovados</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Rejeitados</CardTitle>
            <UserX className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{loading ? "..." : stats.rejected}</div>
            <p className="text-xs text-muted-foreground">Registros rejeitados</p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Ações Rápidas</CardTitle>
          <CardDescription>Acesse as principais funcionalidades do sistema</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Button variant="outline" className="justify-start bg-transparent" asChild>
            <a href="/admin/registrations/pending">
              <Clock className="h-4 w-4 mr-2" />
              Ver Pendentes ({stats.pending})
            </a>
          </Button>
          <Button variant="outline" className="justify-start bg-transparent" asChild>
            <a href="/admin/registrations">
              <Users className="h-4 w-4 mr-2" />
              Todos os Registros
            </a>
          </Button>
          <Button variant="outline" className="justify-start bg-transparent" asChild>
            <a href="/admin/partners">
              <UserCheck className="h-4 w-4 mr-2" />
              Gerenciar Parceiros
            </a>
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
