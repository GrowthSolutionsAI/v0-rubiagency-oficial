"use client"

import { useState } from "react"
import dynamic from "next/dynamic"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Skeleton } from "@/components/ui/skeleton"
import ClientOnly from "@/lib/client-only"

// Componente de loading para o color picker
const ColorPickerLoading = () => <Skeleton className="h-32 w-64" />

// Import dinâmico do React Color - APENAS NO CLIENTE
const SketchPicker = dynamic(() => import("react-color").then((mod) => ({ default: mod.SketchPicker })), {
  ssr: false,
  loading: ColorPickerLoading,
})

interface ColorPickerFormProps {
  onColorChange?: (color: string) => void
  initialColor?: string
  label?: string
}

export default function ColorPickerForm({
  onColorChange,
  initialColor = "#ffffff",
  label = "Cor",
}: ColorPickerFormProps) {
  const [selectedColor, setSelectedColor] = useState(initialColor)
  const [showPicker, setShowPicker] = useState(false)

  const handleColorChange = (color: any) => {
    setSelectedColor(color.hex)
    onColorChange?.(color.hex)
  }

  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <ClientOnly fallback={<ColorPickerLoading />}>
        <div className="flex items-center space-x-2">
          <div
            className="w-12 h-12 rounded-md border border-input cursor-pointer"
            style={{ backgroundColor: selectedColor }}
            onClick={() => setShowPicker(!showPicker)}
          />
          <Button type="button" variant="outline" onClick={() => setShowPicker(!showPicker)}>
            {showPicker ? "Fechar" : "Escolher Cor"}
          </Button>
          <span className="text-sm text-muted-foreground">{selectedColor}</span>
        </div>

        {showPicker && (
          <div className="relative">
            <div className="fixed inset-0 z-10" onClick={() => setShowPicker(false)} />
            <div className="absolute z-20 mt-2">
              <SketchPicker color={selectedColor} onChange={handleColorChange} disableAlpha={false} />
            </div>
          </div>
        )}
      </ClientOnly>
    </div>
  )
}
