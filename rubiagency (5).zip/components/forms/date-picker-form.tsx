"use client"

import { useState } from "react"
import dynamic from "next/dynamic"
import { Label } from "@/components/ui/label"
import { Skeleton } from "@/components/ui/skeleton"
import ClientOnly from "@/lib/client-only"

// Componente de loading para o date picker
const DatePickerLoading = () => <Skeleton className="h-10 w-full" />

// Import dinâmico do React DatePicker - APENAS NO CLIENTE
const ReactDatePicker = dynamic(() => import("react-datepicker").then((mod) => ({ default: mod.default })), {
  ssr: false,
  loading: DatePickerLoading,
})

// Import do CSS do DatePicker
const DatePickerCSS = dynamic(
  () => import("react-datepicker/dist/react-datepicker.css").then(() => ({ default: () => null })),
  { ssr: false },
)

interface DatePickerFormProps {
  onDateChange?: (date: Date | null) => void
  initialDate?: Date
  placeholder?: string
}

export default function DatePickerForm({
  onDateChange,
  initialDate,
  placeholder = "Selecione uma data",
}: DatePickerFormProps) {
  const [selectedDate, setSelectedDate] = useState<Date | null>(initialDate || null)

  const handleDateChange = (date: Date | null) => {
    setSelectedDate(date)
    onDateChange?.(date)
  }

  return (
    <div className="space-y-2">
      <Label htmlFor="date-picker">Data</Label>
      <ClientOnly fallback={<DatePickerLoading />}>
        <DatePickerCSS />
        <div className="relative">
          <ReactDatePicker
            id="date-picker"
            selected={selectedDate}
            onChange={handleDateChange}
            dateFormat="dd/MM/yyyy"
            placeholderText={placeholder}
            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
            wrapperClassName="w-full"
            showPopperArrow={false}
            locale="pt-BR"
          />
        </div>
        {selectedDate && (
          <p className="text-sm text-muted-foreground">Data selecionada: {selectedDate.toLocaleDateString("pt-BR")}</p>
        )}
      </ClientOnly>
    </div>
  )
}
