"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Award, TrendingUp, Users, Briefcase, Lightbulb, Crown, ArrowRight, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLanguage } from "@/contexts/language-context"

export default function Services() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })
  const { t } = useLanguage()

  const services = [
    {
      icon: <Crown className="h-8 w-8" />,
      title: t("services.service1.title"),
      description: t("services.service1.desc"),
      features: [t("services.service1.feature1"), t("services.service1.feature2"), t("services.service1.feature3")],
    },
    {
      icon: <TrendingUp className="h-8 w-8" />,
      title: t("services.service2.title"),
      description: t("services.service2.desc"),
      features: [t("services.service2.feature1"), t("services.service2.feature2"), t("services.service2.feature3")],
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: t("services.service3.title"),
      description: t("services.service3.desc"),
      features: [t("services.service3.feature1"), t("services.service3.feature2"), t("services.service3.feature3")],
    },
    {
      icon: <Briefcase className="h-8 w-8" />,
      title: t("services.service4.title"),
      description: t("services.service4.desc"),
      features: [t("services.service4.feature1"), t("services.service4.feature2"), t("services.service4.feature3")],
    },
    {
      icon: <Lightbulb className="h-8 w-8" />,
      title: t("services.service5.title"),
      description: t("services.service5.desc"),
      features: [t("services.service5.feature1"), t("services.service5.feature2"), t("services.service5.feature3")],
    },
    {
      icon: <Award className="h-8 w-8" />,
      title: t("services.service6.title"),
      description: t("services.service6.desc"),
      features: [t("services.service6.feature1"), t("services.service6.feature2"), t("services.service6.feature3")],
    },
  ]

  return (
    <section id="services" className="section-padding section-gradient textured-bg relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-10 w-32 h-32 bg-red-500/10 rounded-full animate-float"></div>
        <div
          className="absolute bottom-20 right-10 w-24 h-24 bg-red-500/10 rounded-full animate-float"
          style={{ animationDelay: "2s" }}
        ></div>
        <div className="absolute top-1/2 left-1/4 w-16 h-16 bg-red-500/10 rounded-full animate-pulse-slow"></div>
      </div>

      <div className="container mx-auto container-padding relative z-10">
        {/* Section Header */}
        <div className="text-center mb-20 lg:mb-28">
          <motion.div
            className="inline-flex items-center gap-3 mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6 }}
          >
            <div className="h-px w-12 bg-gradient-to-r from-transparent to-red-500 animate-pulse-slow"></div>
            <span className="text-overline text-red-500 animate-fade-in-up-delay">{t("services.overline")}</span>
            <div className="h-px w-12 bg-gradient-to-l from-transparent to-red-500 animate-pulse-slow"></div>
          </motion.div>

          <motion.h2
            className="text-headline text-white mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {t("services.title")}{" "}
            <span className="text-gradient animate-gradient">{t("services.title.highlight")}</span>
          </motion.h2>

          <motion.p
            className="text-body-large text-platinum/80 max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            {t("services.subtitle")}
          </motion.p>
        </div>

        {/* Services Grid */}
        <div ref={ref} className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8 lg:gap-10">
          {services.map((service, index) => (
            <motion.div
              key={index}
              className="group bg-black/20 p-8 lg:p-10 rounded-2xl service-card-border hover-lift hover-glow relative overflow-hidden"
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.5, delay: 0.1 * index }}
              whileHover={{ scale: 1.02 }}
            >
              {/* Background gradient on hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 to-red-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

              <div className="relative z-10">
                {/* Icon */}
                <div className="flex items-center justify-between mb-6">
                  <motion.div
                    className="p-4 bg-gradient-to-br from-red-500/20 to-red-600/20 rounded-xl group-hover:from-red-500/30 group-hover:to-red-600/30 transition-all duration-300"
                    whileHover={{ rotate: 5 }}
                  >
                    <div className="text-red-500 group-hover:scale-110 transition-transform duration-300">
                      {service.icon}
                    </div>
                  </motion.div>
                  <ArrowRight className="h-5 w-5 text-platinum/40 group-hover:text-red-500 group-hover:translate-x-1 transition-all duration-300" />
                </div>

                {/* Content */}
                <div className="space-y-6">
                  <div>
                    <h3 className="text-title text-white mb-4 group-hover:text-red-400 transition-colors duration-300">
                      {service.title}
                    </h3>
                    <p className="text-body text-platinum/80 leading-relaxed">{service.description}</p>
                  </div>

                  {/* Features */}
                  <div className="space-y-3">
                    {service.features.map((feature, featureIndex) => (
                      <motion.div
                        key={featureIndex}
                        className="flex items-center gap-3"
                        initial={{ opacity: 0, x: -20 }}
                        animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
                        transition={{ duration: 0.5, delay: 0.1 * index + 0.1 * featureIndex }}
                      >
                        <div className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse-slow"></div>
                        <span className="text-caption text-platinum/70">{feature}</span>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA Section */}
        <motion.div
          className="text-center mt-20 lg:mt-28"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <div className="glass-effect p-10 lg:p-12 rounded-2xl premium-border max-w-4xl mx-auto hover-glow">
            <motion.h3 className="text-title text-white mb-6" whileHover={{ scale: 1.05 }}>
              {t("services.cta.title")}
            </motion.h3>
            <p className="text-body text-platinum/80 mb-8 leading-relaxed">{t("services.cta.desc")}</p>
            <Button
              asChild
              size="lg"
              className="btn-conversion text-white font-semibold px-10 py-4 rounded-xl hover-scale"
            >
              <a href="#contact" className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 animate-pulse-slow" />
                {t("services.cta.button")}
                <ArrowRight className="h-4 w-4" />
              </a>
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
