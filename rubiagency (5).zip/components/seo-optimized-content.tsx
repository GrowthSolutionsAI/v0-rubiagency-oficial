"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, Target, Award, Users, Star, ArrowRight, CheckCircle } from "lucide-react"

export default function SEOOptimizedContent() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  // Conteúdo otimizado para SEO com palavras-chave estratégicas
  const seoSections = [
    {
      id: "agencia-modelos-sao-paulo",
      title: "Agência de Modelos Premium em São Paulo",
      description:
        "A Rubi Agency é a principal agência de modelos e criadoras de conteúdo adulto em São Paulo. Oferecemos gestão de carreira profissional, marketing digital especializado e networking exclusivo para maximizar seus ganhos no mercado digital.",
      keywords: ["agência de modelos São Paulo", "criadora de conteúdo", "OnlyFans", "gestão de carreira"],
      icon: <Award className="h-6 w-6" />,
      benefits: [
        "Gestão profissional de carreira",
        "Marketing digital especializado",
        "Networking exclusivo no mercado",
        "Suporte jurídico completo",
      ],
    },
    {
      id: "marketing-digital-criadoras",
      title: "Marketing Digital para Criadoras de Conteúdo",
      description:
        "Estratégias avançadas de marketing digital desenvolvidas especificamente para criadoras de conteúdo adulto. Aumentamos sua visibilidade, engajamento e conversões através de técnicas comprovadas no mercado brasileiro.",
      keywords: ["marketing digital", "criadora de conteúdo", "redes sociais", "OnlyFans marketing"],
      icon: <TrendingUp className="h-6 w-6" />,
      benefits: [
        "Estratégias de crescimento orgânico",
        "Gestão profissional de redes sociais",
        "Campanhas de conversão otimizadas",
        "Analytics e relatórios detalhados",
      ],
    },
    {
      id: "gestao-carreira-modelos",
      title: "Gestão de Carreira para Modelos Webcam",
      description:
        "Serviços completos de gestão de carreira para modelos webcam e criadoras de conteúdo. Desenvolvemos estratégias personalizadas para maximizar seus ganhos e construir uma carreira sólida no mercado digital adulto.",
      keywords: ["gestão de carreira", "modelo webcam", "carreira digital", "consultoria profissional"],
      icon: <Target className="h-6 w-6" />,
      benefits: [
        "Planejamento estratégico personalizado",
        "Mentoria individual especializada",
        "Desenvolvimento de marca pessoal",
        "Otimização de performance",
      ],
    },
  ]

  const faqSEO = [
    {
      question: "Como funciona uma agência de modelos para criadoras de conteúdo?",
      answer:
        "Uma agência especializada oferece gestão completa de carreira, incluindo marketing digital, networking, suporte jurídico e estratégias de monetização para maximizar os ganhos das criadoras no mercado digital.",
    },
    {
      question: "Qual o investimento para trabalhar com a Rubi Agency?",
      answer:
        "Oferecemos diferentes modalidades de investimento, desde planos mensais até comissões sobre projetos. O investimento é personalizado conforme o perfil e objetivos de cada criadora.",
    },
    {
      question: "A Rubi Agency trabalha com iniciantes?",
      answer:
        "Sim! Temos programas específicos para iniciantes, incluindo treinamentos, construção de portfólio e introdução gradual ao mercado digital.",
    },
  ]

  return (
    <section className="section-padding premium-gradient relative overflow-hidden">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(220,38,38,0.1),transparent_50%)]"></div>
      </div>

      <div className="container mx-auto container-padding relative z-10">
        {/* SEO Optimized Header */}
        <div className="text-center mb-20">
          <motion.div
            className="inline-flex items-center gap-3 mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6 }}
          >
            <div className="h-px w-12 bg-gradient-to-r from-transparent to-gold"></div>
            <span className="text-overline text-gold">Agência Premium</span>
            <div className="h-px w-12 bg-gradient-to-l from-transparent to-gold"></div>
          </motion.div>

          <motion.h1
            className="text-headline text-white mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Agência de Modelos e <span className="text-gradient">Criadoras de Conteúdo</span> em São Paulo
          </motion.h1>

          <motion.p
            className="text-body-large text-platinum/80 max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            A Rubi Agency é a principal agência especializada em gestão de carreira para criadoras de conteúdo adulto,
            modelos webcam e influenciadoras digitais. Oferecemos serviços premium de marketing digital, networking
            exclusivo e suporte completo para maximizar seus ganhos no mercado brasileiro.
          </motion.p>
        </div>

        {/* SEO Content Sections */}
        <div ref={ref} className="space-y-16 mb-20">
          {seoSections.map((section, index) => (
            <motion.article
              key={section.id}
              id={section.id}
              className="glass-effect p-10 rounded-2xl premium-border"
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-3 bg-gradient-to-br from-gold/20 to-primary/20 rounded-xl">
                      <div className="text-gold">{section.icon}</div>
                    </div>
                    <Badge className="bg-gold/20 text-gold border-gold/30">SEO Otimizado</Badge>
                  </div>

                  <h2 className="text-title text-white mb-4">{section.title}</h2>
                  <p className="text-body text-platinum/90 mb-6 leading-relaxed">{section.description}</p>

                  <div className="space-y-3 mb-6">
                    {section.benefits.map((benefit, benefitIndex) => (
                      <div key={benefitIndex} className="flex items-center gap-3">
                        <CheckCircle className="h-4 w-4 text-gold flex-shrink-0" />
                        <span className="text-platinum/80">{benefit}</span>
                      </div>
                    ))}
                  </div>

                  <Button asChild className="btn-primary">
                    <Link href="#contact" className="flex items-center gap-2">
                      Saiba Mais
                      <ArrowRight className="h-4 w-4" />
                    </Link>
                  </Button>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-white mb-4">Palavras-chave Relevantes:</h3>
                  <div className="flex flex-wrap gap-2">
                    {section.keywords.map((keyword, keywordIndex) => (
                      <Badge
                        key={keywordIndex}
                        variant="outline"
                        className="border-gold/30 text-gold/80 hover:bg-gold/10"
                      >
                        {keyword}
                      </Badge>
                    ))}
                  </div>

                  <div className="mt-6 p-4 bg-white/5 rounded-xl">
                    <h4 className="text-white font-medium mb-2">Otimização SEO:</h4>
                    <ul className="text-sm text-platinum/70 space-y-1">
                      <li>• Meta descriptions únicas</li>
                      <li>• Schema markup implementado</li>
                      <li>• Títulos H1, H2, H3 otimizados</li>
                      <li>• Conteúdo relevante e original</li>
                    </ul>
                  </div>
                </div>
              </div>
            </motion.article>
          ))}
        </div>

        {/* FAQ Section for SEO */}
        <motion.div
          className="glass-effect p-10 rounded-2xl premium-border"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <div className="text-center mb-12">
            <h2 className="text-title text-white mb-4">Perguntas Frequentes</h2>
            <p className="text-platinum/80">
              Respostas para as principais dúvidas sobre nossos serviços especializados
            </p>
          </div>

          <div className="space-y-6">
            {faqSEO.map((faq, index) => (
              <div key={index} className="border-b border-white/10 pb-6 last:border-b-0">
                <h3 className="text-lg font-semibold text-white mb-3">{faq.question}</h3>
                <p className="text-platinum/80 leading-relaxed">{faq.answer}</p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Local SEO Section */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-16"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6, delay: 1.0 }}
        >
          <div className="glass-effect p-8 rounded-2xl premium-border">
            <h3 className="text-title text-white mb-4 flex items-center gap-2">
              <Users className="h-6 w-6 text-gold" />
              Atendimento em São Paulo
            </h3>
            <p className="text-platinum/80 mb-4">
              Localizada no coração de São Paulo, a Rubi Agency oferece atendimento presencial e online para criadoras
              de todo o Brasil. Nossa sede na Av. Paulista garante fácil acesso e networking premium no centro
              financeiro do país.
            </p>
            <div className="space-y-2 text-sm text-platinum/70">
              <p>📍 Av. Paulista, 1000 - São Paulo/SP</p>
              <p>🕐 Segunda a Sexta: 9h às 18h</p>
              <p>📞 +55 (11) 99999-9999</p>
            </div>
          </div>

          <div className="glass-effect p-8 rounded-2xl premium-border">
            <h3 className="text-title text-white mb-4 flex items-center gap-2">
              <Star className="h-6 w-6 text-gold" />
              Avaliações e Depoimentos
            </h3>
            <p className="text-platinum/80 mb-4">
              Com mais de 500 carreiras transformadas e 98% de satisfação, somos a agência mais bem avaliada do mercado
              brasileiro para criadoras de conteúdo adulto.
            </p>
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-gold text-gold" />
                ))}
              </div>
              <span className="text-platinum/70">4.9/5 (247 avaliações)</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
