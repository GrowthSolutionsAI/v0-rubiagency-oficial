"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Award, Shield, Target, Users, ArrowRight, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLanguage } from "@/contexts/language-context"
import Image from "next/image"

export default function About() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })
  const { t } = useLanguage()

  const features = [
    {
      icon: <Award className="h-6 w-6" />,
      title: "Profissionalismo",
      description: "Abordagem séria e estruturada para o desenvolvimento de carreira com padrões internacionais.",
    },
    {
      icon: <Sparkles className="h-6 w-6" />,
      title: "Exclusividade",
      description: "Atendimento personalizado e focado nas necessidades individuais de cada talento.",
    },
    {
      icon: <Target className="h-6 w-6" />,
      title: "Resultados",
      description: "Estratégias comprovadas para maximizar o potencial e retorno de investimento.",
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: "Segurança",
      description: "Ambiente seguro e respeitoso para todos os nossos talentos e parceiros.",
    },
  ]

  const stats = [
    { number: "10+", label: "Anos de Experiência" },
    { number: "500+", label: "Carreiras Transformadas" },
    { number: "98%", label: "Taxa de Satisfação" },
    { number: "24/7", label: "Suporte Dedicado" },
  ]

  return (
    <section id="about" className="section-padding section-bg-gradient relative overflow-hidden">
      {/* Background pattern with red accents */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(239,68,68,0.15),transparent_50%)]"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_60%,rgba(220,38,38,0.1),transparent_50%)]"></div>
      </div>

      <div className="container mx-auto container-padding relative z-10">
        {/* Section Header */}
        <div className="text-center mb-20 lg:mb-28">
          <motion.div
            className="inline-flex items-center gap-3 mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6 }}
          >
            <div className="h-px w-12 bg-gradient-to-r from-transparent to-red-500"></div>
            <span className="text-overline text-red-500">Sobre Nós</span>
            <div className="h-px w-12 bg-gradient-to-l from-transparent to-red-500"></div>
          </motion.div>

          <motion.h2
            className="text-headline text-white mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            A Excelência da <span className="text-gradient">Rubi Agency</span>
          </motion.h2>

          <motion.p
            className="text-body-large text-platinum/80 max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            Somos uma agência premium dedicada a transformar talentos em carreiras de sucesso. Com mais de uma década de
            experiência no mercado, oferecemos uma abordagem única que combina profissionalismo, exclusividade e
            resultados comprovados.
          </motion.p>
        </div>

        {/* Main Content */}
        <div ref={ref} className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-20 items-center mb-20">
          {/* Left Content */}
          <motion.div
            className="space-y-8"
            initial={{ opacity: 0, x: -50 }}
            animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {/* Mission */}
            <div className="glass-effect p-8 rounded-2xl premium-border">
              <h3 className="text-title text-white mb-4 flex items-center gap-3">
                <Target className="h-6 w-6 text-red-500" />
                Nossa Missão
              </h3>
              <p className="text-body text-platinum/80 leading-relaxed">
                Transformar talentos em carreiras de sucesso, oferecendo oportunidades exclusivas em um ambiente
                profissional, seguro e respeitoso, elevando o padrão da indústria com dignidade e excelência.
              </p>
            </div>

            {/* Vision */}
            <div className="glass-effect p-8 rounded-2xl premium-border">
              <h3 className="text-title text-white mb-4 flex items-center gap-3">
                <Sparkles className="h-6 w-6 text-red-500" />
                Nossa Visão
              </h3>
              <p className="text-body text-platinum/80 leading-relaxed">
                Ser reconhecida como a agência premium líder no mercado, referência em profissionalismo e inovação,
                conectando talentos excepcionais a oportunidades transformadoras globalmente.
              </p>
            </div>

            {/* Values */}
            <div className="glass-effect p-8 rounded-2xl premium-border">
              <h3 className="text-title text-white mb-4 flex items-center gap-3">
                <Award className="h-6 w-6 text-red-500" />
                Nossos Valores
              </h3>
              <p className="text-body text-platinum/80 leading-relaxed">
                Integridade, respeito, excelência e transparência. Acreditamos no potencial único de cada talento e
                trabalhamos com dedicação para maximizar seu sucesso de forma ética e sustentável.
              </p>
            </div>
          </motion.div>

          {/* Right Content - Image */}
          <motion.div
            className="relative"
            initial={{ opacity: 0, x: 50 }}
            animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <div className="relative rounded-2xl overflow-hidden premium-border">
              <Image
                src="/about-professional-office.png"
                alt="Profissionalismo Digital"
                width={600}
                height={400}
                className="w-full h-auto object-cover"
                priority
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
              <div className="absolute bottom-6 left-6 right-6">
                <h4 className="text-xl font-bold text-white mb-2">Profissionalismo Digital</h4>
                <p className="text-platinum/80 text-sm">
                  Transformando o mercado digital com estratégias profissionais, ambiente seguro e resultados
                  excepcionais para nossos talentos.
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Stats Section */}
        <motion.div
          className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-20"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-gradient mb-2">{stat.number}</div>
              <div className="text-platinum/70 text-sm uppercase tracking-wider">{stat.label}</div>
            </div>
          ))}
        </motion.div>

        {/* Features Grid */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          {features.map((feature, index) => (
            <div
              key={index}
              className="group glass-effect p-8 rounded-2xl premium-border hover-lift relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 to-red-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <div className="relative z-10">
                <div className="flex items-center gap-4 mb-4">
                  <div className="p-3 bg-gradient-to-br from-red-500/20 to-red-600/20 rounded-xl group-hover:from-red-500/30 group-hover:to-red-600/30 transition-all duration-300">
                    <div className="text-red-500 group-hover:scale-110 transition-transform duration-300">
                      {feature.icon}
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-white group-hover:text-red-400 transition-colors duration-300">
                    {feature.title}
                  </h3>
                </div>
                <p className="text-platinum/80 leading-relaxed">{feature.description}</p>
              </div>
            </div>
          ))}
        </motion.div>

        {/* Why Choose Us */}
        <motion.div
          className="text-center"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6, delay: 1.0 }}
        >
          <div className="glass-effect p-10 lg:p-12 rounded-2xl premium-border max-w-4xl mx-auto">
            <h3 className="text-title text-white mb-6">Por que Escolher a Rubi Agency?</h3>
            <p className="text-body text-platinum/80 mb-8 leading-relaxed">
              Nossa abordagem exclusiva nos permite focar no desenvolvimento individual de cada modelo, maximizando seu
              potencial e retorno com total segurança e profissionalismo no ambiente digital.
            </p>
            <Button asChild size="lg" className="btn-conversion text-white font-semibold px-10 py-4 rounded-xl">
              <a href="#contact" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                Saiba Mais Sobre Nossa Estratégia
                <ArrowRight className="h-4 w-4" />
              </a>
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
