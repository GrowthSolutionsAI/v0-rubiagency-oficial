"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Instagram, Heart, MessageCircle, Share, ExternalLink, Play, TrendingUp, Star } from "lucide-react"

export default function SocialIntegration() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  // Simulação de dados do Instagram com URLs corretas
  const [instagramFeed, setInstagramFeed] = useState([
    {
      id: "1",
      type: "image",
      url: "/placeholder.svg?height=300&width=300",
      caption:
        "✨ Transformando sonhos em realidade! Nossa nova criadora Isabella já está brilhando no mercado digital. #RubiAgency #Sucesso",
      likes: 1247,
      comments: 89,
      timestamp: "2024-12-10T10:30:00Z",
      isVideo: false,
    },
    {
      id: "2",
      type: "video",
      url: "/placeholder.svg?height=300&width=300",
      caption: "🎥 Bastidores do nosso último ensaio profissional. Qualidade premium em cada detalhe! #BastidoresRubi",
      likes: 2156,
      comments: 134,
      timestamp: "2024-12-09T15:45:00Z",
      isVideo: true,
    },
    {
      id: "3",
      type: "image",
      url: "/placeholder.svg?height=300&width=300",
      caption: "💎 Networking exclusivo da Rubi Agency. Conectando talentos a oportunidades únicas! #NetworkingPremium",
      likes: 987,
      comments: 67,
      timestamp: "2024-12-08T12:20:00Z",
      isVideo: false,
    },
    {
      id: "4",
      type: "image",
      url: "/placeholder.svg?height=300&width=300",
      caption: "🌟 Dicas de marketing digital para criadoras. Swipe para ver todas as estratégias! #MarketingDigital",
      likes: 1543,
      comments: 98,
      timestamp: "2024-12-07T09:15:00Z",
      isVideo: false,
    },
    {
      id: "5",
      type: "image",
      url: "/placeholder.svg?height=300&width=300",
      caption: "🔥 Campanha de sucesso! Mais uma criadora alcançando seus objetivos com nossa gestão premium.",
      likes: 1876,
      comments: 156,
      timestamp: "2024-12-06T16:30:00Z",
      isVideo: false,
    },
    {
      id: "6",
      type: "image",
      url: "/placeholder.svg?height=300&width=300",
      caption: "💼 Profissionalismo e elegância em cada projeto. Essa é a marca da Rubi Agency! #Profissionalismo",
      likes: 1234,
      comments: 78,
      timestamp: "2024-12-05T14:10:00Z",
      isVideo: false,
    },
  ])

  // Stories Highlights simulados
  const storiesHighlights = [
    {
      id: "1",
      title: "Dicas",
      cover: "/placeholder.svg?height=100&width=100",
      count: 12,
    },
    {
      id: "2",
      title: "Bastidores",
      cover: "/placeholder.svg?height=100&width=100",
      count: 8,
    },
    {
      id: "3",
      title: "Sucessos",
      cover: "/placeholder.svg?height=100&width=100",
      count: 15,
    },
    {
      id: "4",
      title: "Eventos",
      cover: "/placeholder.svg?height=100&width=100",
      count: 6,
    },
    {
      id: "5",
      title: "Novidades",
      cover: "/placeholder.svg?height=100&width=100",
      count: 9,
    },
  ]

  // Estatísticas das redes sociais
  const socialStats = [
    {
      platform: "Instagram",
      followers: "125K",
      growth: "+15%",
      engagement: "8.5%",
      icon: <Instagram className="h-6 w-6" />,
    },
    {
      platform: "TikTok",
      followers: "89K",
      growth: "+23%",
      engagement: "12.3%",
      icon: <Play className="h-6 w-6" />,
    },
    {
      platform: "Twitter",
      followers: "45K",
      growth: "+8%",
      engagement: "6.2%",
      icon: <MessageCircle className="h-6 w-6" />,
    },
  ]

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date()
    const postTime = new Date(timestamp)
    const diffInHours = Math.floor((now.getTime() - postTime.getTime()) / (1000 * 60 * 60))

    if (diffInHours < 24) {
      return `${diffInHours}h`
    } else {
      const diffInDays = Math.floor(diffInHours / 24)
      return `${diffInDays}d`
    }
  }

  const handleShare = (post: any) => {
    if (navigator.share) {
      navigator.share({
        title: "Rubi Agency",
        text: post.caption,
        url: window.location.href,
      })
    } else {
      // Fallback para navegadores que não suportam Web Share API
      navigator.clipboard.writeText(window.location.href)
    }
  }

  return (
    <section className="section-padding bg-black relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(220,38,38,0.1),transparent_50%)]"></div>
      </div>

      <div className="container mx-auto container-padding relative z-10">
        {/* Section Header */}
        <div className="text-center mb-20">
          <motion.div
            className="inline-flex items-center gap-3 mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6 }}
          >
            <div className="h-px w-12 bg-gradient-to-r from-transparent to-gold"></div>
            <span className="text-overline text-gold">Redes Sociais</span>
            <div className="h-px w-12 bg-gradient-to-l from-transparent to-gold"></div>
          </motion.div>

          <motion.h2
            className="text-headline text-white mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Siga a <span className="text-gradient">Rubi Agency</span>
          </motion.h2>

          <motion.p
            className="text-body-large text-platinum/80 max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            Acompanhe nosso conteúdo exclusivo, dicas profissionais e histórias de sucesso das nossas criadoras.
          </motion.p>
        </div>

        {/* Social Stats */}
        <div ref={ref} className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {socialStats.map((stat, index) => (
            <motion.div
              key={stat.platform}
              className="glass-effect p-6 rounded-2xl premium-border text-center hover-lift"
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <div className="flex justify-center mb-4">
                <div className="p-3 bg-gradient-to-br from-gold/20 to-primary/20 rounded-xl">
                  <div className="text-gold">{stat.icon}</div>
                </div>
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">{stat.platform}</h3>
              <div className="text-2xl font-bold text-gold mb-1">{stat.followers}</div>
              <div className="flex items-center justify-center gap-4 text-sm text-platinum/70">
                <span className="flex items-center gap-1">
                  <TrendingUp className="h-3 w-3 text-green-400" />
                  {stat.growth}
                </span>
                <span>{stat.engagement} eng.</span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Stories Highlights */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <h3 className="text-title text-white mb-8 flex items-center gap-2">
            <Star className="h-6 w-6 text-gold" />
            Destaques dos Stories
          </h3>

          <div className="flex gap-6 overflow-x-auto pb-4">
            {storiesHighlights.map((highlight) => (
              <div key={highlight.id} className="flex-shrink-0 text-center cursor-pointer group">
                <div className="relative mb-3">
                  <div className="w-20 h-20 rounded-full p-1 bg-gradient-to-tr from-gold via-primary to-gold group-hover:scale-110 transition-transform duration-300">
                    <div className="w-full h-full rounded-full overflow-hidden border-2 border-black">
                      <Image
                        src={highlight.cover || "/placeholder.svg"}
                        alt={highlight.title}
                        width={80}
                        height={80}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                  <Badge className="absolute -bottom-1 -right-1 bg-gold text-black text-xs px-1 min-w-0 h-5">
                    {highlight.count}
                  </Badge>
                </div>
                <span className="text-sm text-platinum/80 group-hover:text-gold transition-colors">
                  {highlight.title}
                </span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Instagram Feed */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-title text-white flex items-center gap-2">
              <Instagram className="h-6 w-6 text-gold" />
              Feed do Instagram
            </h3>

            <Button asChild className="btn-primary">
              <a
                href="https://www.instagram.com/rubiagency.br/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2"
              >
                <Instagram className="h-4 w-4" />
                Seguir
                <ExternalLink className="h-3 w-3" />
              </a>
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {instagramFeed.map((post, index) => (
              <motion.div
                key={post.id}
                className="glass-effect rounded-2xl premium-border overflow-hidden hover-lift group"
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                transition={{ duration: 0.6, delay: 0.1 * index }}
              >
                <div className="relative aspect-square overflow-hidden">
                  <Image
                    src={post.url || "/placeholder.svg"}
                    alt="Instagram post"
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  {post.isVideo && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="p-3 bg-black/50 rounded-full">
                        <Play className="h-6 w-6 text-white fill-white" />
                      </div>
                    </div>
                  )}
                  <div className="absolute top-3 right-3">
                    <Instagram className="h-5 w-5 text-white" />
                  </div>
                </div>

                <div className="p-4">
                  <p className="text-platinum/90 text-sm mb-3 line-clamp-3">{post.caption}</p>

                  <div className="flex items-center justify-between text-sm text-platinum/70">
                    <div className="flex items-center gap-4">
                      <span className="flex items-center gap-1">
                        <Heart className="h-4 w-4" />
                        {post.likes.toLocaleString()}
                      </span>
                      <span className="flex items-center gap-1">
                        <MessageCircle className="h-4 w-4" />
                        {post.comments}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span>{formatTimeAgo(post.timestamp)}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleShare(post)}
                        className="p-1 h-auto text-platinum/70 hover:text-gold"
                      >
                        <Share className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* View More Button */}
          <div className="text-center mt-12">
            <Button asChild size="lg" className="btn-secondary">
              <a
                href="https://www.instagram.com/rubiagency.br/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2"
              >
                Ver Mais no Instagram
                <ExternalLink className="h-4 w-4" />
              </a>
            </Button>
          </div>
        </motion.div>

        {/* Social Follow Section */}
        <motion.div
          className="glass-effect p-10 rounded-2xl premium-border text-center mt-16"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <h3 className="text-title text-white mb-4">Conecte-se Conosco</h3>
          <p className="text-platinum/80 mb-8 max-w-2xl mx-auto">
            Siga nossas redes sociais para conteúdo exclusivo, dicas profissionais e acompanhe o sucesso das nossas
            criadoras.
          </p>

          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild className="btn-primary">
              <a
                href="https://www.instagram.com/rubiagency.br/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2"
              >
                <Instagram className="h-4 w-4" />
                Instagram
              </a>
            </Button>

            <Button asChild variant="outline" className="btn-secondary">
              <a
                href="https://tiktok.com/@rubiagency"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2"
              >
                <Play className="h-4 w-4" />
                TikTok
              </a>
            </Button>

            <Button asChild variant="outline" className="btn-secondary">
              <a
                href="https://twitter.com/rubiagency"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2"
              >
                <MessageCircle className="h-4 w-4" />
                Twitter
              </a>
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
