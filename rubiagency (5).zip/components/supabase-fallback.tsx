"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Database, ExternalLink, Settings, CheckCircle } from "lucide-react"

export function SupabaseFallback() {
  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold mb-4">🔧 Configuração do Banco de Dados</h1>
        <p className="text-muted-foreground">
          O sistema está funcionando em modo demonstração. Configure o Supabase para funcionalidade completa.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Status Atual */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Status do Sistema
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <Settings className="h-4 w-4" />
              <AlertTitle>Modo Demonstração</AlertTitle>
              <AlertDescription>
                O sistema está funcionando sem banco de dados. Todas as funcionalidades básicas estão disponíveis.
              </AlertDescription>
            </Alert>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-sm">Site principal funcionando</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-sm">Formulários simulados</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-sm">Admin em modo demo</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Instruções de Configuração */}
        <Card>
          <CardHeader>
            <CardTitle>Configurar Supabase</CardTitle>
            <CardDescription>Siga os passos para configurar o banco de dados</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">
                  1
                </div>
                <div>
                  <h4 className="font-semibold">Criar conta Supabase</h4>
                  <p className="text-sm text-muted-foreground">Acesse supabase.com e crie um projeto</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">
                  2
                </div>
                <div>
                  <h4 className="font-semibold">Obter credenciais</h4>
                  <p className="text-sm text-muted-foreground">Copie a URL e as chaves API do projeto</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">
                  3
                </div>
                <div>
                  <h4 className="font-semibold">Configurar variáveis</h4>
                  <p className="text-sm text-muted-foreground">Adicione as credenciais no .env.local</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">
                  4
                </div>
                <div>
                  <h4 className="font-semibold">Executar scripts</h4>
                  <p className="text-sm text-muted-foreground">Execute os scripts SQL no Supabase</p>
                </div>
              </div>
            </div>

            <Button className="w-full" asChild>
              <a
                href="https://supabase.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2"
              >
                Abrir Supabase <ExternalLink className="h-4 w-4" />
              </a>
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Variáveis de Ambiente */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Variáveis de Ambiente Necessárias</CardTitle>
          <CardDescription>Adicione estas variáveis no seu arquivo .env.local</CardDescription>
        </CardHeader>
        <CardContent>
          <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto">
            {`# Configuração do Supabase
NEXT_PUBLIC_SUPABASE_URL=https://seu-projeto.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sua-chave-publica-aqui
SUPABASE_SERVICE_ROLE_KEY=sua-chave-de-servico-aqui

# Configuração do site
NEXT_PUBLIC_SITE_URL=https://rubiagency.com

# Admin
ADMIN_USERNAME=admin
ADMIN_PASSWORD=sua-senha-segura
JWT_SECRET=sua-chave-jwt-secreta`}
          </pre>
        </CardContent>
      </Card>

      {/* Scripts SQL */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Scripts SQL</CardTitle>
          <CardDescription>Execute estes scripts no SQL Editor do Supabase</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <Database className="h-4 w-4" />
            <AlertTitle>Scripts Disponíveis</AlertTitle>
            <AlertDescription>
              Execute os scripts na pasta /scripts/ em ordem:
              <br />• supabase-001-create-tables.sql
              <br />• supabase-002-insert-default-data.sql
            </AlertDescription>
          </Alert>

          <div className="bg-muted p-4 rounded-lg">
            <h4 className="font-semibold mb-2">Após configurar:</h4>
            <ol className="list-decimal list-inside space-y-1 text-sm">
              <li>Reinicie o servidor (npm run dev)</li>
              <li>Teste o formulário de contato</li>
              <li>Acesse o admin em /admin</li>
              <li>Verifique se os dados são salvos</li>
            </ol>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default SupabaseFallback
