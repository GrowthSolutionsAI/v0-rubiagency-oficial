"use client"

import type React from "react"

import { memo, lazy } from "react"
import dynamic from "next/dynamic"
import Image from "next/image"

// Lazy loading de componentes pesados
const LazyPortfolio = lazy(() => import("./portfolio"))
const LazyTestimonials = lazy(() => import("./testimonials"))

// Dynamic imports para componentes não críticos
const DynamicClientArea = dynamic(() => import("./client-area"), {
  loading: () => <div className="h-96 bg-white/5 rounded-2xl animate-pulse" />,
  ssr: false,
})

// Componente de loading otimizado
const OptimizedLoader = memo(() => (
  <div className="flex items-center justify-center h-64">
    <div className="relative">
      <div className="w-12 h-12 border-4 border-gold/30 border-t-gold rounded-full animate-spin"></div>
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-6 h-6 bg-gradient-to-r from-gold to-primary rounded-full animate-pulse"></div>
      </div>
    </div>
  </div>
))

OptimizedLoader.displayName = "OptimizedLoader"

// Componente de imagem otimizada
interface OptimizedImageProps {
  src: string
  alt: string
  width?: number
  height?: number
  className?: string
  priority?: boolean
}

const OptimizedImage = memo(({ src, alt, width, height, className, priority = false }: OptimizedImageProps) => (
  <Image
    src={src || "/placeholder.svg"}
    alt={alt}
    width={width}
    height={height}
    className={className}
    priority={priority}
    loading={priority ? "eager" : "lazy"}
    quality={85}
    placeholder="blur"
    blurDataURL="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAAIAAoDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAv/xAAhEAACAQMDBQAAAAAAAAAAAAABAgMABAUGIWGRkqGx0f/EABUBAQEAAAAAAAAAAAAAAAAAAAMF/8QAGhEAAgIDAAAAAAAAAAAAAAAAAAECEgMRkf/aAAwDAQACEQMRAD8AltJagyeH0AthI5xdrLcNM91BF5pX2HaH9bcfaSXWGaRmknyJckliyjqTzSlT54b6bk+h0R//2Q=="
    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
  />
))

OptimizedImage.displayName = "OptimizedImage"

// Hook para intersection observer otimizado
import { useEffect, useRef, useState } from "react"

export const useOptimizedInView = (options = {}) => {
  const [inView, setInView] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true)
          observer.disconnect() // Desconecta após primeira visualização
        }
      },
      {
        threshold: 0.1,
        rootMargin: "50px",
        ...options,
      },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  return [ref, inView] as const
}

// Componente de seção otimizada
interface OptimizedSectionProps {
  children: React.ReactNode
  className?: string
  id?: string
}

const OptimizedSection = memo(({ children, className, id }: OptimizedSectionProps) => {
  const [ref, inView] = useOptimizedInView()

  return (
    <section ref={ref} className={className} id={id}>
      {inView ? children : <OptimizedLoader />}
    </section>
  )
})

OptimizedSection.displayName = "OptimizedSection"

// Exportações
export { LazyPortfolio, LazyTestimonials, DynamicClientArea, OptimizedLoader, OptimizedImage, OptimizedSection }

// Configurações de performance
export const performanceConfig = {
  // Preload de recursos críticos
  preloadResources: ["/logo-rubi-agency-new.png", "/hero-model.png"],

  // Configurações de cache
  cacheConfig: {
    images: "public, max-age=31536000, immutable",
    static: "public, max-age=31536000, immutable",
    api: "public, max-age=3600, s-maxage=3600",
  },

  // Configurações de compressão
  compression: {
    images: {
      quality: 85,
      formats: ["webp", "avif"],
    },
  },
}
