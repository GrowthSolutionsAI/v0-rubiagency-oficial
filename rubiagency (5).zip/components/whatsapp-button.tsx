"use client"

import { useState } from "react"
import { MessageCircle, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function WhatsAppButton() {
  const [isVisible, setIsVisible] = useState(true)

  const whatsappNumber = "5511999999999" // Replace with actual WhatsApp number
  const message = "Olá! Gostaria de saber mais sobre os serviços da Rubi Agency."

  const handleWhatsAppClick = () => {
    const url = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`
    window.open(url, "_blank")
  }

  if (!isVisible) return null

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <div className="relative">
        <Button
          onClick={handleWhatsAppClick}
          className="h-14 w-14 rounded-full bg-green-500 hover:bg-green-600 shadow-lg hover:shadow-xl transition-all duration-300 animate-pulse"
          aria-label="Contato via WhatsApp"
        >
          <MessageCircle className="h-6 w-6 text-white" />
        </Button>

        <button
          onClick={() => setIsVisible(false)}
          className="absolute -top-2 -right-2 h-6 w-6 rounded-full bg-red-500 hover:bg-red-600 flex items-center justify-center transition-colors"
          aria-label="Fechar botão WhatsApp"
        >
          <X className="h-3 w-3 text-white" />
        </button>
      </div>

      <div className="absolute bottom-16 right-0 bg-white text-black p-3 rounded-lg shadow-lg max-w-xs opacity-0 hover:opacity-100 transition-opacity duration-300 pointer-events-none">
        <p className="text-sm font-medium">Precisa de ajuda?</p>
        <p className="text-xs text-gray-600">Clique aqui para falar conosco no WhatsApp!</p>
      </div>
    </div>
  )
}
