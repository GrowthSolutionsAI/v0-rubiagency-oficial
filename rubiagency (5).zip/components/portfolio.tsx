"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ArrowRight, Eye } from "lucide-react"

export default function Portfolio() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const [selectedImage, setSelectedImage] = useState<number | null>(null)

  const portfolioItems = [
    {
      id: 1,
      title: "Campanha Verão 2023",
      category: "Editorial",
      image: "/placeholder.svg?height=400&width=600",
      client: "Revista Glamour",
    },
    {
      id: 2,
      title: "Desfile Fashion Week",
      category: "Runway",
      image: "/placeholder.svg?height=400&width=600",
      client: "Milano Fashion",
    },
    {
      id: 3,
      title: "Campanha Joias Exclusivas",
      category: "Publicidade",
      image: "/placeholder.svg?height=400&width=600",
      client: "Diamond Collection",
    },
    {
      id: 4,
      title: "Ensaio Artístico",
      category: "Artístico",
      image: "/placeholder.svg?height=400&width=600",
      client: "Art Gallery SP",
    },
    {
      id: 5,
      title: "Campanha Digital",
      category: "Digital",
      image: "/placeholder.svg?height=400&width=600",
      client: "Brand Luxury",
    },
    {
      id: 6,
      title: "Catálogo Primavera",
      category: "Editorial",
      image: "/placeholder.svg?height=400&width=600",
      client: "Fashion Magazine",
    },
  ]

  const [filter, setFilter] = useState("Todos")
  const categories = ["Todos", "Editorial", "Runway", "Publicidade", "Artístico", "Digital"]

  const filteredItems = filter === "Todos" ? portfolioItems : portfolioItems.filter((item) => item.category === filter)

  return (
    <section id="portfolio" className="section-padding premium-gradient relative overflow-hidden">
      {/* Background texture */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=100&width=100')] bg-repeat opacity-20"></div>
      </div>

      <div className="container mx-auto container-padding relative z-10">
        {/* Section Header */}
        <div className="text-center mb-20 lg:mb-28">
          <motion.div
            className="inline-flex items-center gap-3 mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6 }}
          >
            <div className="h-px w-12 bg-gradient-to-r from-transparent to-gold"></div>
            <span className="text-overline text-gold">Trabalhos Exclusivos</span>
            <div className="h-px w-12 bg-gradient-to-l from-transparent to-gold"></div>
          </motion.div>

          <motion.h2
            className="text-headline text-white mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Nosso <span className="text-gradient">Portfólio</span>
          </motion.h2>

          <motion.p
            className="text-body-large text-platinum/80 max-w-4xl mx-auto leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            Conheça alguns dos trabalhos realizados por nossos talentos em parceria com marcas renomadas e fotógrafos
            premiados internacionalmente.
          </motion.p>
        </div>

        {/* Filter Buttons */}
        <motion.div
          className="flex flex-wrap justify-center gap-4 mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          {categories.map((category, index) => (
            <Button
              key={index}
              variant={filter === category ? "default" : "outline"}
              className={
                filter === category
                  ? "btn-primary text-white rounded-full px-6"
                  : "btn-secondary text-platinum hover:text-gold rounded-full px-6"
              }
              onClick={() => setFilter(category)}
            >
              {category}
            </Button>
          ))}
        </motion.div>

        {/* Portfolio Grid */}
        <div ref={ref} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item, index) => (
            <motion.div
              key={item.id}
              className="group relative overflow-hidden rounded-xl premium-shadow-lg hover-lift cursor-pointer"
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.5, delay: 0.1 * index }}
              onClick={() => setSelectedImage(item.id)}
            >
              <div className="relative h-80 w-full">
                <Image
                  src={item.image || "/placeholder.svg"}
                  alt={item.title}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-8">
                <span className="text-overline text-gold mb-2">{item.category}</span>
                <h3 className="text-title text-white mb-2">{item.title}</h3>
                <p className="text-caption text-platinum/80 mb-4">{item.client}</p>
                <div className="flex items-center gap-2 text-gold">
                  <Eye className="h-4 w-4" />
                  <span className="text-caption font-medium">Ver Detalhes</span>
                  <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform duration-300" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA Button */}
        <motion.div
          className="text-center mt-16 lg:mt-20"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <Button asChild size="lg" className="btn-primary text-white font-semibold px-10 py-4 rounded-xl">
            <a href="#contact" className="flex items-center gap-2">
              VER MAIS TRABALHOS
              <ArrowRight className="h-4 w-4" />
            </a>
          </Button>
        </motion.div>
      </div>

      {/* Portfolio Modal */}
      <Dialog open={selectedImage !== null} onOpenChange={() => setSelectedImage(null)}>
        <DialogContent className="max-w-5xl bg-black/95 border-white/10 premium-border rounded-xl">
          <DialogHeader>
            <DialogTitle className="text-title text-white">
              {selectedImage && portfolioItems.find((item) => item.id === selectedImage)?.title}
            </DialogTitle>
            <DialogDescription className="text-platinum/80">
              {selectedImage && portfolioItems.find((item) => item.id === selectedImage)?.client}
            </DialogDescription>
          </DialogHeader>
          <div className="relative h-[70vh] w-full rounded-lg overflow-hidden">
            {selectedImage && (
              <Image
                src={portfolioItems.find((item) => item.id === selectedImage)?.image || ""}
                alt="Portfolio image"
                fill
                className="object-contain"
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </section>
  )
}
