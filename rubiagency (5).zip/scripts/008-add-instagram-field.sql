-- Adicionar campo Instagram à tabela user_registrations
-- Execute este script após o reset completo

-- Adicionar coluna Instagram se não existir
ALTER TABLE user_registrations 
ADD COLUMN IF NOT EXISTS instagram VARCHAR(100);

-- Verificar estrutura da tabela
SELECT column_name, data_type, is_nullable 
FROM information_schema.columns 
WHERE table_name = 'user_registrations' 
ORDER BY ordinal_position;

-- Confirmar alteração
SELECT 'Instagram field added successfully' as status, NOW() as timestamp;
