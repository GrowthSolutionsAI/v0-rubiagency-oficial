-- ✅ SCRIPT DE CORREÇÃO DAS TABELAS SUPABASE
-- Execute este script no SQL Editor do Supabase

-- Remover tabelas existentes se necessário (cuidado em produção!)
-- DROP TABLE IF EXISTS user_registrations CASCADE;
-- DROP TABLE IF EXISTS partners CASCADE;
-- DROP TABLE IF EXISTS admin_users CASCADE;
-- DROP TABLE IF EXISTS system_settings CASCADE;

-- 1. Criar tabela user_registrations se não existir
CREATE TABLE IF NOT EXISTS public.user_registrations (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    instagram VARCHAR(100),
    age INTEGER NOT NULL CHECK (age >= 18),
    subject VARCHAR(255),
    experience VARCHAR(50),
    message TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    partner_id INTEGER,
    partner_code VARCHAR(50),
    partner_name VARCHAR(255),
    notes TEXT,
    approved_at TIMESTAMP WITH TIME ZONE,
    approved_by VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Criar tabela partners se não existir
CREATE TABLE IF NOT EXISTS public.partners (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    company VARCHAR(255),
    website VARCHAR(255),
    description TEXT,
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    code VARCHAR(50) UNIQUE NOT NULL,
    referral_code VARCHAR(50),
    commission_rate DECIMAL(5,2) DEFAULT 10.00,
    total_referrals INTEGER DEFAULT 0,
    total_commission DECIMAL(10,2) DEFAULT 0.00,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Criar tabela system_settings se não existir
CREATE TABLE IF NOT EXISTS public.system_settings (
    id SERIAL PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Criar tabela admin_users se não existir
CREATE TABLE IF NOT EXISTS public.admin_users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'admin' CHECK (role IN ('admin', 'moderator')),
    is_active BOOLEAN DEFAULT true,
    last_login TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. Criar índices para performance
CREATE INDEX IF NOT EXISTS idx_user_registrations_status ON public.user_registrations(status);
CREATE INDEX IF NOT EXISTS idx_user_registrations_created_at ON public.user_registrations(created_at);
CREATE INDEX IF NOT EXISTS idx_user_registrations_partner_id ON public.user_registrations(partner_id);
CREATE INDEX IF NOT EXISTS idx_partners_code ON public.partners(code);
CREATE INDEX IF NOT EXISTS idx_partners_is_active ON public.partners(is_active);
CREATE INDEX IF NOT EXISTS idx_admin_users_email ON public.admin_users(email);
CREATE INDEX IF NOT EXISTS idx_system_settings_key ON public.system_settings(setting_key);

-- 6. Criar função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- 7. Criar triggers para updated_at
DROP TRIGGER IF EXISTS update_user_registrations_updated_at ON public.user_registrations;
CREATE TRIGGER update_user_registrations_updated_at
    BEFORE UPDATE ON public.user_registrations
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_partners_updated_at ON public.partners;
CREATE TRIGGER update_partners_updated_at
    BEFORE UPDATE ON public.partners
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_admin_users_updated_at ON public.admin_users;
CREATE TRIGGER update_admin_users_updated_at
    BEFORE UPDATE ON public.admin_users
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_system_settings_updated_at ON public.system_settings;
CREATE TRIGGER update_system_settings_updated_at
    BEFORE UPDATE ON public.system_settings
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- 8. Inserir configurações básicas do sistema
INSERT INTO public.system_settings (setting_key, setting_value, description) VALUES
('site_name', 'Rubi Agency', 'Nome do site')
ON CONFLICT (setting_key) DO NOTHING;

INSERT INTO public.system_settings (setting_key, setting_value, description) VALUES
('admin_email', 'admin@rubiagency.com', 'Email do administrador')
ON CONFLICT (setting_key) DO NOTHING;

INSERT INTO public.system_settings (setting_key, setting_value, description) VALUES
('smtp_configured', 'false', 'Status da configuração SMTP')
ON CONFLICT (setting_key) DO NOTHING;

-- 9. Criar usuário admin padrão (senha: admin123)
INSERT INTO public.admin_users (email, password_hash, name, role, is_active) VALUES
('admin@rubiagency.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewBdCYEeBP0N1pZa', 'Administrator', 'admin', true)
ON CONFLICT (email) DO NOTHING;

-- 10. Criar parceiro de exemplo
INSERT INTO public.partners (name, email, company, code, description, is_active) VALUES
('Parceiro Exemplo', 'parceiro@exemplo.com', 'Empresa Exemplo', 'EXEMPLO_SP', 'Parceiro de exemplo para testes', true)
ON CONFLICT (code) DO NOTHING;

-- 11. Habilitar RLS (Row Level Security)
ALTER TABLE public.user_registrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.partners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;

-- 12. Criar políticas RLS (permitir acesso com service_role)
CREATE POLICY IF NOT EXISTS "Enable all for service_role" ON public.user_registrations
    FOR ALL USING (auth.role() = 'service_role');

CREATE POLICY IF NOT EXISTS "Enable all for service_role" ON public.partners
    FOR ALL USING (auth.role() = 'service_role');

CREATE POLICY IF NOT EXISTS "Enable all for service_role" ON public.admin_users
    FOR ALL USING (auth.role() = 'service_role');

CREATE POLICY IF NOT EXISTS "Enable all for service_role" ON public.system_settings
    FOR ALL USING (auth.role() = 'service_role');

-- 13. Permitir inserção pública para registrations (formulário do site)
CREATE POLICY IF NOT EXISTS "Enable insert for anon users" ON public.user_registrations
    FOR INSERT WITH CHECK (true);

-- 14. Criar registros de teste (opcional)
INSERT INTO public.user_registrations (name, email, phone, instagram, age, message, status) VALUES
('Julia Santos', 'julia@exemplo.com', '+55 11 99999-1111', '@julia_modelo', 23, 'Interessada em trabalhar como modelo na agência', 'pending'),
('Maria Oliveira', 'maria@exemplo.com', '+55 11 99999-2222', '@maria_criadora', 25, 'Quero fazer parte do time da Rubi Agency', 'approved'),
('Ana Costa', 'ana@exemplo.com', '+55 11 99999-3333', '@ana_modelo', 22, 'Tenho experiência em fotografia e gostaria de uma oportunidade', 'pending')
ON CONFLICT DO NOTHING;

-- 15. Verificar se tudo foi criado
SELECT 
  'user_registrations' as table_name, 
  COUNT(*) as record_count 
FROM public.user_registrations
UNION ALL
SELECT 
  'partners' as table_name, 
  COUNT(*) as record_count 
FROM public.partners
UNION ALL
SELECT 
  'admin_users' as table_name, 
  COUNT(*) as record_count 
FROM public.admin_users
UNION ALL
SELECT 
  'system_settings' as table_name, 
  COUNT(*) as record_count 
FROM public.system_settings;

-- ✅ SCRIPT CONCLUÍDO
-- Todas as tabelas foram criadas/verificadas
-- RLS configurado
-- Políticas criadas
-- Índices adicionados
-- Dados básicos inseridos
-- Triggers configurados

SELECT 'Supabase database setup completed successfully!' as status;
