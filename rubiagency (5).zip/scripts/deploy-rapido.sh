#!/bin/bash

echo "🚀 DEPLOY RÁPIDO - RUBI AGENCY"
echo "================================"

# Verificar se está na pasta correta
if [ ! -f "package.json" ]; then
    echo "❌ Erro: Execute este script na pasta do projeto"
    exit 1
fi

echo "📦 Instalando dependências..."
npm install

echo "🔨 Fazendo build..."
npm run build

if [ $? -eq 0 ]; then
    echo "✅ Build concluído com sucesso!"
    echo ""
    echo "🌐 Próximos passos:"
    echo "1. Vá em vercel.com"
    echo "2. Clique no projeto v0-rubiagency-lancamento"
    echo "3. Vá em Settings > Environment Variables"
    echo "4. Adicione as variáveis do arquivo DEPLOY_SIMPLES.md"
    echo "5. Clique em Redeploy"
    echo ""
    echo "🎉 Seu site estará online em 2-3 minutos!"
else
    echo "❌ Erro no build. Verifique os logs acima."
    exit 1
fi
