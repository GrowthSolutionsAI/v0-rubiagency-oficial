-- Criar tabela de parceiros
CREATE TABLE IF NOT EXISTS partners (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  phone VARCHAR(20),
  commission_rate DECIMAL(5,2) DEFAULT 10.00,
  status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  referral_code VARCHAR(50) UNIQUE NOT NULL,
  total_referrals INTEGER DEFAULT 0,
  total_commission DECIMAL(10,2) DEFAULT 0.00,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Criar índices para performance
CREATE INDEX IF NOT EXISTS idx_partners_status ON partners(status);
CREATE INDEX IF NOT EXISTS idx_partners_referral_code ON partners(referral_code);
CREATE INDEX IF NOT EXISTS idx_partners_email ON partners(email);
CREATE INDEX IF NOT EXISTS idx_partners_created_at ON partners(created_at);

-- Adicionar comentários
COMMENT ON TABLE partners IS 'Tabela para armazenar dados dos parceiros de afiliados';
COMMENT ON COLUMN partners.commission_rate IS 'Taxa de comissão do parceiro em porcentagem';
COMMENT ON COLUMN partners.referral_code IS 'Código único para identificar indicações do parceiro';
COMMENT ON COLUMN partners.total_referrals IS 'Contador total de indicações feitas pelo parceiro';
COMMENT ON COLUMN partners.total_commission IS 'Total de comissão acumulada pelo parceiro';

-- Inserir dados de exemplo
INSERT INTO partners (name, email, phone, commission_rate, status, referral_code, total_referrals, total_commission) 
VALUES 
  ('João Silva', 'joao@exemplo.com', '(11) 99999-1234', 10.00, 'active', 'JOAO001', 23, 2300.00),
  ('Maria Santos', 'maria@exemplo.com', '(11) 99999-5678', 15.00, 'active', 'MARIA002', 45, 6750.00),
  ('Pedro Costa', 'pedro@exemplo.com', '(11) 99999-9012', 8.00, 'inactive', 'PEDRO003', 12, 960.00),
  ('Ana Oliveira', 'ana@exemplo.com', '(11) 99999-3456', 12.00, 'active', 'ANA004', 31, 3720.00),
  ('Carlos Ferreira', 'carlos@exemplo.com', '(11) 99999-7890', 10.00, 'active', 'CARLOS005', 18, 1800.00)
ON CONFLICT (email) DO NOTHING;

-- Atualizar coluna partner_id na tabela registrations se ela existir
DO $$
BEGIN
  -- Verificar se a coluna partner_id existe na tabela registrations
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'registrations' 
    AND column_name = 'partner_id'
  ) THEN
    -- Adicionar algumas indicações de exemplo para os parceiros
    UPDATE registrations 
    SET partner_id = (
      CASE 
        WHEN id % 5 = 1 THEN 1  -- João
        WHEN id % 5 = 2 THEN 2  -- Maria  
        WHEN id % 5 = 3 THEN 3  -- Pedro
        WHEN id % 5 = 4 THEN 4  -- Ana
        ELSE 5                  -- Carlos
      END
    )
    WHERE partner_id IS NULL;
  END IF;
END $$;

-- Função para atualizar estatísticas dos parceiros
CREATE OR REPLACE FUNCTION update_partner_stats()
RETURNS TRIGGER AS $$
BEGIN
  -- Atualizar estatísticas do parceiro se partner_id estiver definido
  IF NEW.partner_id IS NOT NULL THEN
    UPDATE partners 
    SET 
      total_referrals = (
        SELECT COUNT(*) 
        FROM registrations 
        WHERE partner_id = NEW.partner_id
      ),
      total_commission = (
        SELECT COALESCE(COUNT(*) * commission_rate, 0)
        FROM registrations r, partners p
        WHERE r.partner_id = NEW.partner_id 
        AND p.id = NEW.partner_id
        AND r.status = 'approved'
      ),
      updated_at = NOW()
    WHERE id = NEW.partner_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Criar trigger para atualizar estatísticas automaticamente
DROP TRIGGER IF EXISTS trigger_update_partner_stats ON registrations;
CREATE TRIGGER trigger_update_partner_stats
  AFTER INSERT OR UPDATE ON registrations
  FOR EACH ROW
  EXECUTE FUNCTION update_partner_stats();

-- Criar função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Criar trigger para updated_at na tabela partners
DROP TRIGGER IF EXISTS trigger_partners_updated_at ON partners;
CREATE TRIGGER trigger_partners_updated_at
  BEFORE UPDATE ON partners
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Atualizar estatísticas iniciais dos parceiros
UPDATE partners 
SET 
  total_referrals = COALESCE((
    SELECT COUNT(*) 
    FROM registrations 
    WHERE partner_id = partners.id
  ), 0),
  total_commission = COALESCE((
    SELECT COUNT(*) * partners.commission_rate
    FROM registrations 
    WHERE partner_id = partners.id 
    AND status = 'approved'
  ), 0);

COMMIT;
