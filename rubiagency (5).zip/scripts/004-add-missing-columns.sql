-- Script 004: Adicionar colunas que podem estar faltando
-- Execute após o script 003

-- Verificar e adicionar colunas que podem estar faltando na tabela user_registrations
DO $$ 
BEGIN
    -- Adicionar coluna partner_id se não existir
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'user_registrations' AND column_name = 'partner_id') THEN
        ALTER TABLE user_registrations ADD COLUMN partner_id INTEGER REFERENCES partners(id);
        RAISE NOTICE 'Coluna partner_id adicionada';
    END IF;

    -- Adicionar coluna partner_code se não existir
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'user_registrations' AND column_name = 'partner_code') THEN
        ALTER TABLE user_registrations ADD COLUMN partner_code VARCHAR(50);
        CREATE INDEX IF NOT EXISTS idx_user_registrations_partner_code ON user_registrations(partner_code);
        RAISE NOTICE 'Coluna partner_code adicionada';
    END IF;

    -- Adicionar coluna approved_at se não existir
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'user_registrations' AND column_name = 'approved_at') THEN
        ALTER TABLE user_registrations ADD COLUMN approved_at TIMESTAMP;
        RAISE NOTICE 'Coluna approved_at adicionada';
    END IF;

    -- Adicionar coluna approved_by se não existir
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'user_registrations' AND column_name = 'approved_by') THEN
        ALTER TABLE user_registrations ADD COLUMN approved_by VARCHAR(255);
        RAISE NOTICE 'Coluna approved_by adicionada';
    END IF;

    -- Adicionar coluna instagram se não existir
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'user_registrations' AND column_name = 'instagram') THEN
        ALTER TABLE user_registrations ADD COLUMN instagram VARCHAR(100);
        RAISE NOTICE 'Coluna instagram adicionada';
    END IF;
END $$;

-- Verificar e adicionar coluna total_referrals se não existir
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'partners' AND column_name = 'total_referrals') THEN
        ALTER TABLE partners ADD COLUMN total_referrals INTEGER DEFAULT 0;
        RAISE NOTICE 'Coluna total_referrals adicionada';
    END IF;
END $$;

-- Atualizar contagem de referrals dos parceiros
UPDATE partners SET total_referrals = (
    SELECT COUNT(*) 
    FROM user_registrations 
    WHERE user_registrations.partner_id = partners.id
) WHERE id IN (SELECT DISTINCT partner_id FROM user_registrations WHERE partner_id IS NOT NULL);

-- Verificar estrutura final das tabelas
SELECT 
    table_name,
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name IN ('user_registrations', 'partners', 'admin_users', 'system_settings')
ORDER BY table_name, ordinal_position;

-- Criar índices adicionais se não existirem
CREATE INDEX IF NOT EXISTS idx_user_registrations_email ON user_registrations(email);
CREATE INDEX IF NOT EXISTS idx_user_registrations_instagram ON user_registrations(instagram);

-- Verificar se todas as tabelas estão prontas
SELECT 
    t.table_name,
    COUNT(c.column_name) as column_count
FROM information_schema.tables t
LEFT JOIN information_schema.columns c ON t.table_name = c.table_name
WHERE t.table_schema = 'public' 
    AND t.table_name IN ('admin_users', 'system_settings', 'partners', 'user_registrations', 'user_files')
GROUP BY t.table_name
ORDER BY t.table_name;

-- Script concluído com sucesso
SELECT 'Database setup completed successfully!' as status;
