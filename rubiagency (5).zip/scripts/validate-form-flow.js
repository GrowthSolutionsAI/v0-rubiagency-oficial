// Script para validar o fluxo completo do formulário
const { neon } = require("@neondatabase/serverless")

async function validateFormFlow() {
  console.log("🔍 VALIDAÇÃO COMPLETA DO FLUXO DO FORMULÁRIO")
  console.log("=".repeat(60))

  const DATABASE_URL = process.env.DATABASE_URL || process.env.POSTGRES_URL || process.env.NEON_DATABASE_URL

  if (!DATABASE_URL) {
    console.error("❌ DATABASE_URL não encontrada")
    return
  }

  const sql = neon(DATABASE_URL)

  try {
    // 1. Testar conexão
    console.log("1️⃣ Testando conexão com banco de dados...")
    const connectionTest = await sql`SELECT NOW() as current_time, version() as db_version`
    console.log("✅ Conexão estabelecida:", connectionTest[0].current_time)

    // 2. Verificar estrutura das tabelas
    console.log("\n2️⃣ Verificando estrutura das tabelas...")

    const tables = await sql`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      ORDER BY table_name
    `

    console.log(
      "📋 Tabelas encontradas:",
      tables.map((t) => t.table_name),
    )

    // 3. Verificar colunas da tabela user_registrations
    console.log("\n3️⃣ Verificando colunas da tabela user_registrations...")

    const columns = await sql`
      SELECT column_name, data_type, is_nullable 
      FROM information_schema.columns 
      WHERE table_name = 'user_registrations' 
      ORDER BY ordinal_position
    `

    console.log("📊 Colunas da tabela user_registrations:")
    columns.forEach((col) => {
      console.log(`   - ${col.column_name}: ${col.data_type} (${col.is_nullable === "YES" ? "nullable" : "not null"})`)
    })

    // 4. Contar registros existentes
    console.log("\n4️⃣ Contando registros existentes...")

    const totalCount = await sql`SELECT COUNT(*) as total FROM user_registrations`
    const statusCount = await sql`
      SELECT 
        status,
        COUNT(*) as count
      FROM user_registrations 
      GROUP BY status
    `

    console.log(`📈 Total de registros: ${totalCount[0].total}`)
    console.log("📊 Por status:")
    statusCount.forEach((s) => {
      console.log(`   - ${s.status}: ${s.count}`)
    })

    // 5. Verificar parceiros
    console.log("\n5️⃣ Verificando parceiros...")

    const partners = await sql`SELECT id, name, code, is_active FROM partners ORDER BY id`
    console.log("🤝 Parceiros cadastrados:")
    partners.forEach((p) => {
      console.log(`   - ${p.code}: ${p.name} (${p.is_active ? "ativo" : "inativo"})`)
    })

    // 6. Simular inserção de teste
    console.log("\n6️⃣ Simulando inserção de registro de teste...")

    const testRegistration = await sql`
      INSERT INTO user_registrations (
        name, email, phone, instagram, age, experience, message, status, partner_code, created_at, updated_at
      )
      VALUES (
        'Teste Validação', 
        'teste.validacao@email.com', 
        '+55 11 99999-0000',
        '@teste_validacao',
        25, 
        'intermediate', 
        'Mensagem de teste para validação do fluxo completo do formulário.',
        'pending',
        'MODELO_SP',
        NOW(),
        NOW()
      )
      RETURNING *
    `

    console.log("✅ Registro de teste criado:", {
      id: testRegistration[0].id,
      name: testRegistration[0].name,
      email: testRegistration[0].email,
      created_at: testRegistration[0].created_at,
    })

    // 7. Verificar se o registro aparece nas consultas
    console.log("\n7️⃣ Verificando se o registro aparece nas consultas...")

    const recentRegistrations = await sql`
      SELECT 
        ur.id, ur.name, ur.email, ur.status, ur.partner_code,
        p.name as partner_name,
        ur.created_at
      FROM user_registrations ur
      LEFT JOIN partners p ON ur.partner_code = p.code
      ORDER BY ur.created_at DESC
      LIMIT 5
    `

    console.log("📋 Últimos 5 registros:")
    recentRegistrations.forEach((r) => {
      console.log(`   - ${r.name} (${r.email}) - ${r.status} - ${r.partner_name || "sem parceiro"}`)
    })

    // 8. Testar estatísticas
    console.log("\n8️⃣ Testando consulta de estatísticas...")

    const stats = await sql`
      SELECT 
        COUNT(*)::int as total,
        COUNT(CASE WHEN status = 'pending' THEN 1 END)::int as pending,
        COUNT(CASE WHEN status = 'approved' THEN 1 END)::int as approved,
        COUNT(CASE WHEN status = 'rejected' THEN 1 END)::int as rejected
      FROM user_registrations
    `

    console.log("📊 Estatísticas atualizadas:", stats[0])

    // 9. Limpar registro de teste
    console.log("\n9️⃣ Limpando registro de teste...")

    await sql`DELETE FROM user_registrations WHERE email = 'teste.validacao@email.com'`
    console.log("🧹 Registro de teste removido")

    console.log("\n✅ VALIDAÇÃO COMPLETA - TODOS OS TESTES PASSARAM!")
    console.log("=".repeat(60))

    return {
      success: true,
      tablesFound: tables.length,
      totalRegistrations: Number.parseInt(totalCount[0].total),
      partnersFound: partners.length,
      stats: stats[0],
    }
  } catch (error) {
    console.error("❌ Erro durante validação:", error)
    console.error("❌ Stack trace:", error.stack)
    return {
      success: false,
      error: error.message,
    }
  }
}

// Executar validação se chamado diretamente
if (require.main === module) {
  validateFormFlow()
    .then((result) => {
      console.log("\n🎯 Resultado final:", result)
      process.exit(result.success ? 0 : 1)
    })
    .catch((error) => {
      console.error("💥 Erro fatal:", error)
      process.exit(1)
    })
}

module.exports = { validateFormFlow }
