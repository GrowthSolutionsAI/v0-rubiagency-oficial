-- =====================================================
-- VALIDAÇÃO COMPLETA DEVOPS - RUBI AGENCY
-- =====================================================

-- Extensão para UUIDs
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- =====================================================
-- 1. VALIDAÇÃO DE ESTRUTURA
-- =====================================================

-- Função para atualizar updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Verificar e criar tabela partners
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_tables WHERE tablename = 'partners') THEN
    CREATE TABLE partners (
      id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      email VARCHAR(255) UNIQUE NOT NULL,
      phone VARCHAR(20),
      code VARCHAR(50) UNIQUE NOT NULL,
      description TEXT,
      commission_rate DECIMAL(5,2) DEFAULT 10.00,
      is_active BOOLEAN DEFAULT true,
      total_referrals INTEGER DEFAULT 0,
      total_registrations INTEGER DEFAULT 0,
      approved_registrations INTEGER DEFAULT 0,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    );
  END IF;
  
  -- Adicionar colunas se não existirem
  IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'partners' AND column_name = 'total_registrations') THEN
    ALTER TABLE partners ADD COLUMN total_registrations INTEGER DEFAULT 0;
  END IF;
  
  IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'partners' AND column_name = 'approved_registrations') THEN
    ALTER TABLE partners ADD COLUMN approved_registrations INTEGER DEFAULT 0;
  END IF;
  
  IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'partners' AND column_name = 'total_referrals') THEN
    ALTER TABLE partners ADD COLUMN total_referrals INTEGER DEFAULT 0;
  END IF;
  
  IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'partners' AND column_name = 'updated_at') THEN
    ALTER TABLE partners ADD COLUMN updated_at TIMESTAMPTZ DEFAULT NOW();
  END IF;
END $$;

-- Verificar e criar tabela admin_users (SEM full_name)
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_tables WHERE tablename = 'admin_users') THEN
    CREATE TABLE admin_users (
      id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
      username VARCHAR(100) UNIQUE NOT NULL,
      email VARCHAR(255) UNIQUE NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      is_active BOOLEAN DEFAULT true,
      last_login TIMESTAMPTZ,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    );
  END IF;
  
  -- Remover full_name se existir
  IF EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'admin_users' AND column_name = 'full_name') THEN
    ALTER TABLE admin_users DROP COLUMN full_name;
  END IF;
END $$;

-- Verificar e criar tabela system_settings
CREATE TABLE IF NOT EXISTS system_settings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  setting_key VARCHAR(100) UNIQUE NOT NULL,
  setting_value TEXT,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- 2. UPSERT CONFIGURAÇÕES DO SISTEMA
-- =====================================================

INSERT INTO system_settings (setting_key, setting_value, description) VALUES
  ('site_name', 'Rubi Agency', 'Nome do site'),
  ('site_description', 'Agência de Marketing Digital', 'Descrição do site'),
  ('contact_email', 'contato@rubiagency.com', 'Email de contato'),
  ('admin_email', 'contato@rubiagency.com', 'Email do administrador'),
  ('email_service', 'smtp', 'Serviço de email'),
  ('smtp_host', 'smtp.gmail.com', 'Servidor SMTP'),
  ('smtp_port', '465', 'Porta SMTP'),
  ('smtp_user', 'contato@rubiagency.com', 'Usuário SMTP'),
  ('smtp_pass', 'ymxmutrfrtzkeice', 'Senha SMTP'),
  ('smtp_secure', 'true', 'TLS implícito'),
  ('email_from', 'Rubi Agency <contato@rubiagency.com>', 'Remetente padrão'),
  ('next_public_app_url', 'https://www.rubiagency.com', 'URL da aplicação'),
  ('resend_api_key', 're_ffpYK3uV_BYaPm6wcrJE9yAWsgm9BeYaC', 'Chave API Resend'),
  ('sendgrid_api_key', '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', 'Chave API SendGrid')
ON CONFLICT (setting_key) DO UPDATE
SET setting_value = EXCLUDED.setting_value,
    updated_at = NOW();

-- =====================================================
-- 3. UPSERT USUÁRIO ADMIN
-- =====================================================

INSERT INTO admin_users (username, email, password_hash, is_active) VALUES
  ('admin', 'contato@rubiagency.com', '$2b$10$rQZ8kHWKtGkVQW5Oe5nGxeJ7vQZ8kHWKtGkVQW5Oe5nGxeJ7vQZ8kH', true)
ON CONFLICT (username) DO UPDATE
SET email = EXCLUDED.email,
    is_active = EXCLUDED.is_active,
    updated_at = NOW();

-- =====================================================
-- 4. TRIGGERS BEFORE UPDATE
-- =====================================================

-- Trigger para partners
DROP TRIGGER IF EXISTS update_partners_updated_at ON partners;
CREATE TRIGGER update_partners_updated_at
  BEFORE UPDATE ON partners
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Trigger para system_settings
DROP TRIGGER IF EXISTS update_system_settings_updated_at ON system_settings;
CREATE TRIGGER update_system_settings_updated_at
  BEFORE UPDATE ON system_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Trigger para admin_users
DROP TRIGGER IF EXISTS update_admin_users_updated_at ON admin_users;
CREATE TRIGGER update_admin_users_updated_at
  BEFORE UPDATE ON admin_users
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 5. TRIGGER DE MÉTRICAS (com verificação dinâmica)
-- =====================================================

CREATE OR REPLACE FUNCTION update_partner_metrics()
RETURNS TRIGGER AS $$
DECLARE
  registrations_table TEXT;
BEGIN
  -- Verificar qual tabela de registros existe
  IF to_regclass('public.user_registrations') IS NOT NULL THEN
    registrations_table := 'user_registrations';
  ELSIF to_regclass('public.contact_registrations') IS NOT NULL THEN
    registrations_table := 'contact_registrations';
  ELSE
    RETURN NEW; -- Nenhuma tabela encontrada, sair
  END IF;
  
  -- Atualizar métricas do parceiro se partner_id existir
  IF NEW.partner_id IS NOT NULL THEN
    EXECUTE format('
      UPDATE partners 
      SET 
        total_registrations = (SELECT COUNT(*) FROM %I WHERE partner_id = $1),
        approved_registrations = (SELECT COUNT(*) FROM %I WHERE partner_id = $1 AND status = ''approved''),
        total_referrals = (SELECT COUNT(*) FROM %I WHERE partner_id = $1),
        updated_at = NOW()
      WHERE id = $1
    ', registrations_table, registrations_table, registrations_table)
    USING NEW.partner_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Aplicar trigger se tabela de registros existir
DO $$
BEGIN
  IF to_regclass('public.contact_registrations') IS NOT NULL THEN
    DROP TRIGGER IF EXISTS update_partner_metrics_trigger ON contact_registrations;
    CREATE TRIGGER update_partner_metrics_trigger
      AFTER INSERT OR UPDATE ON contact_registrations
      FOR EACH ROW
      EXECUTE FUNCTION update_partner_metrics();
  END IF;
  
  IF to_regclass('public.user_registrations') IS NOT NULL THEN
    DROP TRIGGER IF EXISTS update_partner_metrics_trigger ON user_registrations;
    CREATE TRIGGER update_partner_metrics_trigger
      AFTER INSERT OR UPDATE ON user_registrations
      FOR EACH ROW
      EXECUTE FUNCTION update_partner_metrics();
  END IF;
END $$;

-- =====================================================
-- 6. RECALCULAR MÉTRICAS EXISTENTES
-- =====================================================

DO $$
DECLARE
  registrations_table TEXT;
BEGIN
  -- Verificar qual tabela usar
  IF to_regclass('public.contact_registrations') IS NOT NULL THEN
    registrations_table := 'contact_registrations';
  ELSIF to_regclass('public.user_registrations') IS NOT NULL THEN
    registrations_table := 'user_registrations';
  ELSE
    RETURN; -- Nenhuma tabela encontrada
  END IF;
  
  -- Recalcular métricas
  EXECUTE format('
    UPDATE partners 
    SET 
      total_registrations = COALESCE((SELECT COUNT(*) FROM %I WHERE partner_id = partners.id), 0),
      approved_registrations = COALESCE((SELECT COUNT(*) FROM %I WHERE partner_id = partners.id AND status = ''approved''), 0),
      total_referrals = COALESCE((SELECT COUNT(*) FROM %I WHERE partner_id = partners.id), 0),
      updated_at = NOW()
  ', registrations_table, registrations_table, registrations_table);
END $$;

-- =====================================================
-- 7. ÍNDICES PARA PERFORMANCE
-- =====================================================

CREATE INDEX IF NOT EXISTS idx_partners_code ON partners(code);
CREATE INDEX IF NOT EXISTS idx_partners_email ON partners(email);
CREATE INDEX IF NOT EXISTS idx_partners_is_active ON partners(is_active);
CREATE INDEX IF NOT EXISTS idx_system_settings_key ON system_settings(setting_key);
CREATE INDEX IF NOT EXISTS idx_admin_users_username ON admin_users(username);
CREATE INDEX IF NOT EXISTS idx_admin_users_email ON admin_users(email);

-- Índices condicionais para tabelas de registros
DO $$
BEGIN
  IF to_regclass('public.contact_registrations') IS NOT NULL THEN
    CREATE INDEX IF NOT EXISTS idx_contact_registrations_partner_id ON contact_registrations(partner_id);
    CREATE INDEX IF NOT EXISTS idx_contact_registrations_status ON contact_registrations(status);
  END IF;
  
  IF to_regclass('public.user_registrations') IS NOT NULL THEN
    CREATE INDEX IF NOT EXISTS idx_user_registrations_partner_id ON user_registrations(partner_id);
    CREATE INDEX IF NOT EXISTS idx_user_registrations_status ON user_registrations(status);
  END IF;
END $$;

-- =====================================================
-- 8. VALIDAÇÃO FINAL
-- =====================================================

-- Contagem de registros
SELECT 
  'admin_users' AS tabela, 
  COUNT(*) AS registros,
  'Usuários administradores' AS descricao
FROM admin_users
UNION ALL
SELECT 
  'partners', 
  COUNT(*), 
  'Parceiros cadastrados'
FROM partners
UNION ALL
SELECT 
  'system_settings', 
  COUNT(*), 
  'Configurações do sistema'
FROM system_settings
UNION ALL
SELECT 
  COALESCE(
    (SELECT 'contact_registrations' WHERE to_regclass('public.contact_registrations') IS NOT NULL),
    (SELECT 'user_registrations' WHERE to_regclass('public.user_registrations') IS NOT NULL),
    'no_registrations_table'
  ),
  COALESCE(
    (SELECT COUNT(*) FROM contact_registrations WHERE to_regclass('public.contact_registrations') IS NOT NULL),
    (SELECT COUNT(*) FROM user_registrations WHERE to_regclass('public.user_registrations') IS NOT NULL),
    0
  ),
  'Registros de contato'
ORDER BY tabela;

-- Verificação de triggers
SELECT 
  schemaname,
  tablename,
  triggername,
  'OK' as status
FROM pg_trigger t
JOIN pg_class c ON t.tgrelid = c.oid
JOIN pg_namespace n ON c.relnamespace = n.oid
WHERE n.nspname = 'public' 
  AND c.relname IN ('partners', 'system_settings', 'admin_users', 'contact_registrations', 'user_registrations')
  AND t.tgname LIKE '%update%'
ORDER BY tablename, triggername;

-- Verificação de configurações críticas
SELECT 
  setting_key,
  CASE 
    WHEN setting_key LIKE '%pass%' OR setting_key LIKE '%key%' THEN '***'
    ELSE setting_value
  END as setting_value,
  'OK' as status
FROM system_settings 
WHERE setting_key IN (
  'email_service', 'smtp_host', 'smtp_port', 'smtp_user', 
  'email_from', 'next_public_app_url'
)
ORDER BY setting_key;

-- Status final
SELECT 
  '🎉 VALIDAÇÃO DEVOPS COMPLETA!' as resultado,
  '✅ Sistema pronto para deploy' as status,
  NOW() as timestamp;
