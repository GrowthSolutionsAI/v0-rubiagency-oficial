#!/usr/bin/env node

/**
 * VALIDAÇÃO COMPLETA DO AMBIENTE PARA PRODUÇÃO
 * Verifica todas as configurações necessárias para deploy
 */

import { createClient } from "@supabase/supabase-js"
import nodemailer from "nodemailer"

interface ValidationResult {
  component: string
  status: "PASS" | "FAIL" | "WARN"
  message: string
  details?: any
}

const results: ValidationResult[] = []

// Cores para output
const colors = {
  green: "\x1b[32m",
  red: "\x1b[31m",
  yellow: "\x1b[33m",
  blue: "\x1b[34m",
  reset: "\x1b[0m",
  bold: "\x1b[1m",
}

function log(color: keyof typeof colors, message: string) {
  console.log(`${colors[color]}${message}${colors.reset}`)
}

function addResult(component: string, status: "PASS" | "FAIL" | "WARN", message: string, details?: any) {
  results.push({ component, status, message, details })

  const icon = status === "PASS" ? "✅" : status === "FAIL" ? "❌" : "⚠️"
  const color = status === "PASS" ? "green" : status === "FAIL" ? "red" : "yellow"

  log(color, `${icon} ${component}: ${message}`)
}

async function validateEnvironmentVariables() {
  log("blue", "\n🔍 Validando Variáveis de Ambiente...")

  const requiredVars = [
    "NEXT_PUBLIC_SUPABASE_URL",
    "NEXT_PUBLIC_SUPABASE_ANON_KEY",
    "SUPABASE_SERVICE_ROLE_KEY",
    "SMTP_HOST",
    "SMTP_PORT",
    "SMTP_USER",
    "SMTP_PASS",
    "EMAIL_FROM",
    "NEXT_PUBLIC_APP_URL",
  ]

  const optionalVars = ["RESEND_API_KEY", "SENDGRID_API_KEY", "ADMIN_EMAIL"]

  let missingRequired = 0
  let missingOptional = 0

  for (const varName of requiredVars) {
    if (!process.env[varName]) {
      addResult("Environment", "FAIL", `Variável obrigatória ausente: ${varName}`)
      missingRequired++
    }
  }

  for (const varName of optionalVars) {
    if (!process.env[varName]) {
      addResult("Environment", "WARN", `Variável opcional ausente: ${varName}`)
      missingOptional++
    }
  }

  if (missingRequired === 0) {
    addResult("Environment", "PASS", `Todas as ${requiredVars.length} variáveis obrigatórias configuradas`)
  }

  if (missingOptional === 0) {
    addResult("Environment", "PASS", `Todas as ${optionalVars.length} variáveis opcionais configuradas`)
  }
}

async function validateSupabase() {
  log("blue", "\n🗄️ Validando Conexão Supabase...")

  try {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY

    if (!supabaseUrl || !supabaseKey) {
      addResult("Supabase", "FAIL", "Credenciais do Supabase não configuradas")
      return
    }

    const supabase = createClient(supabaseUrl, supabaseKey)

    // Testar conexão
    const { data, error } = await supabase.from("contact_registrations").select("count").limit(1)

    if (error) {
      addResult("Supabase", "FAIL", `Erro de conexão: ${error.message}`)
      return
    }

    addResult("Supabase", "PASS", "Conexão estabelecida com sucesso")

    // Verificar tabelas
    const tables = ["contact_registrations", "system_settings", "partners", "admin_users"]

    for (const table of tables) {
      try {
        const { error: tableError } = await supabase.from(table).select("*").limit(1)

        if (tableError) {
          addResult("Supabase", "FAIL", `Tabela ${table} não encontrada: ${tableError.message}`)
        } else {
          addResult("Supabase", "PASS", `Tabela ${table} acessível`)
        }
      } catch (err) {
        addResult("Supabase", "FAIL", `Erro ao acessar tabela ${table}`)
      }
    }

    // Verificar estatísticas
    const { data: stats } = await supabase.from("contact_registrations").select("status")

    if (stats) {
      const total = stats.length
      const pending = stats.filter((r) => r.status === "pending").length
      const approved = stats.filter((r) => r.status === "approved").length
      const rejected = stats.filter((r) => r.status === "rejected").length

      addResult(
        "Supabase",
        "PASS",
        `Dados: ${total} registros (${pending} pendentes, ${approved} aprovados, ${rejected} rejeitados)`,
      )
    }
  } catch (error) {
    addResult("Supabase", "FAIL", `Erro na validação: ${error}`)
  }
}

async function validateEmail() {
  log("blue", "\n📧 Validando Configuração de Email...")

  // Validar SMTP
  try {
    const transporter = nodemailer.createTransporter({
      host: process.env.SMTP_HOST,
      port: Number.parseInt(process.env.SMTP_PORT || "587"),
      secure: process.env.SMTP_SECURE === "true",
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    })

    await transporter.verify()
    addResult("Email SMTP", "PASS", "Configuração SMTP válida")
  } catch (error) {
    addResult("Email SMTP", "FAIL", `Erro SMTP: ${error}`)
  }

  // Validar Resend
  if (process.env.RESEND_API_KEY) {
    try {
      const response = await fetch("https://api.resend.com/domains", {
        headers: {
          Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        },
      })

      if (response.ok) {
        addResult("Email Resend", "PASS", "API Key do Resend válida")
      } else {
        addResult("Email Resend", "FAIL", "API Key do Resend inválida")
      }
    } catch (error) {
      addResult("Email Resend", "FAIL", `Erro Resend: ${error}`)
    }
  }

  // Validar SendGrid
  if (process.env.SENDGRID_API_KEY) {
    try {
      const response = await fetch("https://api.sendgrid.com/v3/user/profile", {
        headers: {
          Authorization: `Bearer ${process.env.SENDGRID_API_KEY}`,
        },
      })

      if (response.ok) {
        addResult("Email SendGrid", "PASS", "API Key do SendGrid válida")
      } else {
        addResult("Email SendGrid", "FAIL", "API Key do SendGrid inválida")
      }
    } catch (error) {
      addResult("Email SendGrid", "FAIL", `Erro SendGrid: ${error}`)
    }
  }
}

async function validateBuild() {
  log("blue", "\n🔨 Validando Build...")

  try {
    // Verificar se o projeto compila
    const { execSync } = require("child_process")

    execSync("npm run build", { stdio: "pipe" })
    addResult("Build", "PASS", "Projeto compila sem erros")
  } catch (error) {
    addResult("Build", "FAIL", "Erro na compilação do projeto")
  }
}

async function validateDependencies() {
  log("blue", "\n📦 Validando Dependências...")

  try {
    const packageJson = require("../package.json")
    const dependencies = Object.keys(packageJson.dependencies || {})
    const devDependencies = Object.keys(packageJson.devDependencies || {})

    addResult("Dependencies", "PASS", `${dependencies.length} dependências de produção`)
    addResult("Dependencies", "PASS", `${devDependencies.length} dependências de desenvolvimento`)

    // Verificar dependências críticas
    const criticalDeps = ["@supabase/supabase-js", "next", "react", "nodemailer", "tailwindcss"]

    for (const dep of criticalDeps) {
      if (dependencies.includes(dep)) {
        addResult("Dependencies", "PASS", `Dependência crítica encontrada: ${dep}`)
      } else {
        addResult("Dependencies", "FAIL", `Dependência crítica ausente: ${dep}`)
      }
    }
  } catch (error) {
    addResult("Dependencies", "FAIL", `Erro ao validar dependências: ${error}`)
  }
}

async function generateReport() {
  log("blue", "\n📊 Gerando Relatório Final...")

  const passed = results.filter((r) => r.status === "PASS").length
  const failed = results.filter((r) => r.status === "FAIL").length
  const warnings = results.filter((r) => r.status === "WARN").length

  console.log("\n" + "=".repeat(60))
  log("bold", "📋 RELATÓRIO DE VALIDAÇÃO PARA PRODUÇÃO")
  console.log("=".repeat(60))

  log("green", `✅ PASSOU: ${passed} verificações`)
  log("red", `❌ FALHOU: ${failed} verificações`)
  log("yellow", `⚠️  AVISOS: ${warnings} verificações`)

  console.log("\n📈 RESUMO POR COMPONENTE:")
  console.log("-".repeat(40))

  const components = [...new Set(results.map((r) => r.component))]

  for (const component of components) {
    const componentResults = results.filter((r) => r.component === component)
    const componentPassed = componentResults.filter((r) => r.status === "PASS").length
    const componentFailed = componentResults.filter((r) => r.status === "FAIL").length
    const componentWarnings = componentResults.filter((r) => r.status === "WARN").length

    const status = componentFailed > 0 ? "❌" : componentWarnings > 0 ? "⚠️" : "✅"
    console.log(`${status} ${component}: ${componentPassed}✅ ${componentFailed}❌ ${componentWarnings}⚠️`)
  }

  console.log("\n" + "=".repeat(60))

  if (failed === 0) {
    log("green", "🎉 SISTEMA PRONTO PARA DEPLOY EM PRODUÇÃO!")
    log("green", "🚀 Execute: vercel --prod")
  } else {
    log("red", "🚫 SISTEMA NÃO ESTÁ PRONTO PARA PRODUÇÃO")
    log("red", `❌ Corrija ${failed} erro(s) antes do deploy`)
  }

  console.log("=".repeat(60))
}

async function main() {
  console.clear()
  log("bold", "🔍 INICIANDO VALIDAÇÃO COMPLETA DO SISTEMA")
  log("blue", "⏰ " + new Date().toLocaleString("pt-BR"))

  await validateEnvironmentVariables()
  await validateSupabase()
  await validateEmail()
  await validateDependencies()
  await validateBuild()
  await generateReport()
}

// Executar validação
main().catch(console.error)
