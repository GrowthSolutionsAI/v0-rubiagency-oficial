#!/bin/bash

echo "🔧 Adicionando variáveis de ambiente ao Vercel"

# Cores
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_step() {
    echo -e "${BLUE}$1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️ $1${NC}"
}

# Verificar se está logado
vercel whoami || {
    echo "❌ Faça login primeiro: vercel login"
    exit 1
}

print_step "Adicionando variáveis de ambiente..."

# Supabase
print_step "1. Configurando Supabase..."
echo "Cole a URL do Supabase:"
vercel env add NEXT_PUBLIC_SUPABASE_URL production

echo "Cole a chave anônima do Supabase:"
vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY production

echo "Cole a chave de serviço do Supabase:"
vercel env add SUPABASE_SERVICE_ROLE_KEY production

# Email
print_step "2. Configurando Email SMTP..."
echo "Email remetente (ex: contato@rubiagency.com):"
vercel env add EMAIL_FROM production

echo "Host SMTP (ex: smtp.gmail.com):"
vercel env add SMTP_HOST production

echo "Porta SMTP (ex: 465):"
vercel env add SMTP_PORT production

echo "SMTP Secure (true/false):"
vercel env add SMTP_SECURE production

echo "Usuário SMTP:"
vercel env add SMTP_USER production

echo "Senha SMTP:"
vercel env add SMTP_PASS production

# Site
print_step "3. Configurando URLs do site..."
echo "URL do app (ex: https://rubiagency.com):"
vercel env add NEXT_PUBLIC_APP_URL production

echo "Email do admin:"
vercel env add ADMIN_EMAIL production

print_success "Todas as variáveis de ambiente foram configuradas!"
print_warning "Execute 'vercel --prod' para fazer o deploy final"
