// =====================================================
// SCRIPT DE VALIDAÇÃO COMPLETA DO SISTEMA
// =====================================================

const { createClient } = require("@supabase/supabase-js")

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!supabaseUrl || !supabaseKey) {
  console.error("❌ Variáveis de ambiente do Supabase não configuradas")
  process.exit(1)
}

const supabase = createClient(supabaseUrl, supabaseKey)

async function validateDatabase() {
  console.log("🔍 Validando estrutura do banco de dados...\n")

  const tables = ["contact_registrations", "partners", "system_settings", "admin_users"]
  const results = {}

  for (const table of tables) {
    try {
      const { data, error } = await supabase.from(table).select("count").limit(1)

      if (error) {
        results[table] = { status: "❌", error: error.message }
      } else {
        const { count } = await supabase.from(table).select("*", { count: "exact", head: true })
        results[table] = { status: "✅", count: count || 0 }
      }
    } catch (err) {
      results[table] = { status: "❌", error: err.message }
    }
  }

  console.log("📊 TABELAS DO BANCO:")
  for (const [table, result] of Object.entries(results)) {
    console.log(`${result.status} ${table}: ${result.count !== undefined ? `${result.count} registros` : result.error}`)
  }

  return Object.values(results).every((r) => r.status === "✅")
}

async function validateSettings() {
  console.log("\n⚙️ Validando configurações do sistema...\n")

  const criticalSettings = ["site_name", "email_service", "smtp_host", "smtp_user", "email_from", "contact_email"]

  const { data: settings, error } = await supabase
    .from("system_settings")
    .select("setting_key, setting_value")
    .in("setting_key", criticalSettings)

  if (error) {
    console.error("❌ Erro ao buscar configurações:", error.message)
    return false
  }

  console.log("📋 CONFIGURAÇÕES CRÍTICAS:")
  const settingsMap = {}
  settings?.forEach((s) => {
    settingsMap[s.setting_key] = s.setting_value
  })

  let allValid = true
  for (const key of criticalSettings) {
    const value = settingsMap[key]
    const status = value ? "✅" : "❌"
    const displayValue = key.includes("pass") || key.includes("key") ? "***" : value
    console.log(`${status} ${key}: ${displayValue || "NÃO CONFIGURADO"}`)

    if (!value) allValid = false
  }

  return allValid
}

async function validateAdmin() {
  console.log("\n👤 Validando usuário administrador...\n")

  const { data: admins, error } = await supabase
    .from("admin_users")
    .select("username, email, is_active")
    .eq("is_active", true)

  if (error) {
    console.error("❌ Erro ao buscar admins:", error.message)
    return false
  }

  if (!admins || admins.length === 0) {
    console.log("❌ Nenhum usuário admin ativo encontrado")
    return false
  }

  console.log("👥 USUÁRIOS ADMIN ATIVOS:")
  admins.forEach((admin) => {
    console.log(`✅ ${admin.username} (${admin.email})`)
  })

  return true
}

async function validatePartners() {
  console.log("\n🤝 Validando sistema de parceiros...\n")

  const { data: partners, error } = await supabase
    .from("partners")
    .select("name, code, email, is_active, total_registrations")
    .order("total_registrations", { ascending: false })

  if (error) {
    console.error("❌ Erro ao buscar parceiros:", error.message)
    return false
  }

  if (!partners || partners.length === 0) {
    console.log("⚠️ Nenhum parceiro encontrado (isso é normal se não houver parceiros cadastrados)")
    return true
  }

  console.log("🤝 PARCEIROS CADASTRADOS:")
  partners.forEach((partner) => {
    const status = partner.is_active ? "✅" : "❌"
    console.log(`${status} ${partner.name} (${partner.code}) - ${partner.total_registrations} registros`)
  })

  return true
}

async function validateRegistrations() {
  console.log("\n📝 Validando registros de contato...\n")

  const { data: registrations, error } = await supabase.from("contact_registrations").select("status")

  if (error) {
    console.error("❌ Erro ao buscar registros:", error.message)
    return false
  }

  const stats = {
    total: registrations?.length || 0,
    pending: registrations?.filter((r) => r.status === "pending").length || 0,
    approved: registrations?.filter((r) => r.status === "approved").length || 0,
    rejected: registrations?.filter((r) => r.status === "rejected").length || 0,
  }

  console.log("📊 ESTATÍSTICAS DE REGISTROS:")
  console.log(`📋 Total: ${stats.total}`)
  console.log(`⏳ Pendentes: ${stats.pending}`)
  console.log(`✅ Aprovados: ${stats.approved}`)
  console.log(`❌ Rejeitados: ${stats.rejected}`)

  return true
}

async function validateEmailSystem() {
  console.log("\n📧 Validando sistema de email...\n")

  const { data: emailSettings, error } = await supabase
    .from("system_settings")
    .select("setting_key, setting_value")
    .in("setting_key", ["email_service", "smtp_host", "smtp_user", "smtp_pass"])

  if (error) {
    console.error("❌ Erro ao buscar configurações de email:", error.message)
    return false
  }

  const emailConfig = {}
  emailSettings?.forEach((s) => {
    emailConfig[s.setting_key] = s.setting_value
  })

  const service = emailConfig.email_service || "smtp"
  console.log(`📧 Serviço de email: ${service}`)

  if (service === "smtp") {
    const hasHost = !!emailConfig.smtp_host
    const hasUser = !!emailConfig.smtp_user
    const hasPass = !!emailConfig.smtp_pass

    console.log(`${hasHost ? "✅" : "❌"} SMTP Host: ${emailConfig.smtp_host || "NÃO CONFIGURADO"}`)
    console.log(`${hasUser ? "✅" : "❌"} SMTP User: ${emailConfig.smtp_user || "NÃO CONFIGURADO"}`)
    console.log(`${hasPass ? "✅" : "❌"} SMTP Pass: ${hasPass ? "***" : "NÃO CONFIGURADO"}`)

    return hasHost && hasUser && hasPass
  }

  return true
}

async function main() {
  console.log("🚀 INICIANDO VALIDAÇÃO COMPLETA DO SISTEMA\n")
  console.log("=".repeat(50))

  const validations = [
    { name: "Banco de Dados", fn: validateDatabase },
    { name: "Configurações", fn: validateSettings },
    { name: "Usuário Admin", fn: validateAdmin },
    { name: "Sistema de Parceiros", fn: validatePartners },
    { name: "Registros de Contato", fn: validateRegistrations },
    { name: "Sistema de Email", fn: validateEmailSystem },
  ]

  const results = []

  for (const validation of validations) {
    try {
      const result = await validation.fn()
      results.push({ name: validation.name, success: result })
    } catch (error) {
      console.error(`❌ Erro na validação ${validation.name}:`, error.message)
      results.push({ name: validation.name, success: false, error: error.message })
    }
  }

  console.log("\n" + "=".repeat(50))
  console.log("📋 RESUMO DA VALIDAÇÃO:\n")

  let allValid = true
  results.forEach((result) => {
    const status = result.success ? "✅" : "❌"
    console.log(`${status} ${result.name}`)
    if (!result.success) {
      allValid = false
      if (result.error) {
        console.log(`   Erro: ${result.error}`)
      }
    }
  })

  console.log("\n" + "=".repeat(50))

  if (allValid) {
    console.log("🎉 SISTEMA VALIDADO COM SUCESSO!")
    console.log("✅ Pronto para deploy em produção")
  } else {
    console.log("⚠️ SISTEMA COM PROBLEMAS")
    console.log("❌ Corrija os erros antes do deploy")
  }

  console.log("=".repeat(50))

  process.exit(allValid ? 0 : 1)
}

main().catch((error) => {
  console.error("💥 Erro fatal na validação:", error)
  process.exit(1)
})
