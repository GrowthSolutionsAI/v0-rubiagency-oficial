-- Criar bucket para uploads de contato
INSERT INTO storage.buckets (id, name, public) 
VALUES ('contact_uploads', 'contact_uploads', false)
ON CONFLICT (id) DO NOTHING;

-- Política para permitir upload via service role
CREATE POLICY IF NOT EXISTS "Service role can upload contact files"
ON storage.objects FOR INSERT TO service_role
WITH CHECK (bucket_id = 'contact_uploads');

-- Política para permitir leitura via service role
CREATE POLICY IF NOT EXISTS "Service role can read contact files"
ON storage.objects FOR SELECT TO service_role
USING (bucket_id = 'contact_uploads');

-- Política para permitir delete via service role (para limpeza)
CREATE POLICY IF NOT EXISTS "Service role can delete contact files"
ON storage.objects FOR DELETE TO service_role
USING (bucket_id = 'contact_uploads');

-- Verificar se o bucket foi criado
SELECT id, name, public FROM storage.buckets WHERE id = 'contact_uploads';
