-- Testar sistema de parceiros
SELECT 'Testando sistema de parceiros...' as status;

-- Verificar se a tabela partners existe
SELECT 
    CASE 
        WHEN EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'partners') 
        THEN '✅ Tabela partners existe'
        ELSE '❌ Tabela partners não encontrada'
    END as partners_table_check;

-- Verificar se as colunas de parceiro existem em user_registrations
SELECT 
    CASE 
        WHEN EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'user_registrations' AND column_name = 'partner_id') 
        THEN '✅ Coluna partner_id existe'
        ELSE '❌ Coluna partner_id não encontrada'
    END as partner_id_check;

SELECT 
    CASE 
        WHEN EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'user_registrations' AND column_name = 'partner_code') 
        THEN '✅ Coluna partner_code existe'
        ELSE '❌ Coluna partner_code não encontrada'
    END as partner_code_check;

-- Verificar se existem parceiros cadastrados
SELECT 
    COUNT(*) as total_partners,
    COUNT(CASE WHEN is_active = true THEN 1 END) as active_partners
FROM partners;

-- Mostrar parceiros existentes
SELECT 
    id,
    name,
    code,
    email,
    commission_rate,
    is_active,
    total_referrals,
    created_at
FROM partners 
ORDER BY created_at DESC;

-- Verificar se o trigger existe
SELECT 
    CASE 
        WHEN EXISTS (
            SELECT 1 FROM information_schema.triggers 
            WHERE trigger_name = 'trigger_update_partner_referrals'
        ) 
        THEN '✅ Trigger de atualização existe'
        ELSE '❌ Trigger de atualização não encontrado'
    END as trigger_check;

-- Testar inserção de cadastro com parceiro (simulação)
INSERT INTO user_registrations (
    name, email, instagram, age, message, status, partner_code, created_at, updated_at
) VALUES (
    'Teste Parceiro', 'teste@parceiro.com', '@teste_parceiro', 25, 
    'Teste de cadastro via parceiro', 'pending', 'MODELO_SP', NOW(), NOW()
) ON CONFLICT DO NOTHING;

-- Verificar se o contador foi atualizado
SELECT 
    p.name,
    p.code,
    p.total_referrals,
    COUNT(ur.id) as registrations_count
FROM partners p
LEFT JOIN user_registrations ur ON ur.partner_code = p.code
GROUP BY p.id, p.name, p.code, p.total_referrals
ORDER BY p.created_at DESC;

SELECT '✅ Teste do sistema de parceiros concluído!' as final_status;
