-- Criar tabela de parceiros
CREATE TABLE IF NOT EXISTS partners (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    commission_rate DECIMAL(5,2) DEFAULT 0.00,
    is_active BOOLEAN DEFAULT true,
    total_referrals INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Adicionar colunas de parceiro na tabela de registros (se não existirem)
DO $$ 
BEGIN
    -- Adicionar partner_id se não existir
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'user_registrations' AND column_name = 'partner_id') THEN
        ALTER TABLE user_registrations ADD COLUMN partner_id INTEGER REFERENCES partners(id);
    END IF;
    
    -- Adicionar partner_code se não existir
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'user_registrations' AND column_name = 'partner_code') THEN
        ALTER TABLE user_registrations ADD COLUMN partner_code VARCHAR(50);
    END IF;
END $$;

-- Criar índices para performance
CREATE INDEX IF NOT EXISTS idx_partners_code ON partners(code);
CREATE INDEX IF NOT EXISTS idx_partners_active ON partners(is_active);
CREATE INDEX IF NOT EXISTS idx_registrations_partner_id ON user_registrations(partner_id);
CREATE INDEX IF NOT EXISTS idx_registrations_partner_code ON user_registrations(partner_code);

-- Função para atualizar contador de referrals
CREATE OR REPLACE FUNCTION update_partner_referrals()
RETURNS TRIGGER AS $$
BEGIN
    -- Se um novo registro foi inserido com partner_id
    IF TG_OP = 'INSERT' AND NEW.partner_id IS NOT NULL THEN
        UPDATE partners 
        SET total_referrals = total_referrals + 1,
            updated_at = NOW()
        WHERE id = NEW.partner_id;
    END IF;
    
    -- Se um registro foi atualizado e mudou o partner_id
    IF TG_OP = 'UPDATE' THEN
        -- Decrementar do parceiro antigo
        IF OLD.partner_id IS NOT NULL AND OLD.partner_id != COALESCE(NEW.partner_id, 0) THEN
            UPDATE partners 
            SET total_referrals = GREATEST(total_referrals - 1, 0),
                updated_at = NOW()
            WHERE id = OLD.partner_id;
        END IF;
        
        -- Incrementar no novo parceiro
        IF NEW.partner_id IS NOT NULL AND NEW.partner_id != COALESCE(OLD.partner_id, 0) THEN
            UPDATE partners 
            SET total_referrals = total_referrals + 1,
                updated_at = NOW()
            WHERE id = NEW.partner_id;
        END IF;
    END IF;
    
    -- Se um registro foi deletado
    IF TG_OP = 'DELETE' AND OLD.partner_id IS NOT NULL THEN
        UPDATE partners 
        SET total_referrals = GREATEST(total_referrals - 1, 0),
            updated_at = NOW()
        WHERE id = OLD.partner_id;
    END IF;
    
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

-- Criar trigger para atualizar contador automaticamente
DROP TRIGGER IF EXISTS trigger_update_partner_referrals ON user_registrations;
CREATE TRIGGER trigger_update_partner_referrals
    AFTER INSERT OR UPDATE OR DELETE ON user_registrations
    FOR EACH ROW EXECUTE FUNCTION update_partner_referrals();

-- Inserir alguns parceiros de exemplo
INSERT INTO partners (name, email, code, description, commission_rate, is_active) VALUES
('Agência Modelo SP', 'contato@agenciamodelo.com', 'MODELO_SP', 'Parceria com agência de modelos de São Paulo', 10.00, true),
('Influencer Maria', 'maria@instagram.com', 'MARIA_INFL', 'Influencer digital com 100k seguidores', 15.00, true),
('Studio Fotográfico RJ', 'contato@studiofoto.com', 'FOTO_RJ', 'Studio de fotografia profissional no Rio de Janeiro', 12.50, true)
ON CONFLICT (code) DO NOTHING;

-- Atualizar contadores existentes (caso já existam registros)
UPDATE partners SET total_referrals = (
    SELECT COUNT(*) 
    FROM user_registrations 
    WHERE user_registrations.partner_id = partners.id
);

-- Verificar se tudo foi criado corretamente
SELECT 'Sistema de parceiros criado com sucesso!' as status;

-- Mostrar parceiros criados
SELECT id, name, code, commission_rate, total_referrals, is_active 
FROM partners 
ORDER BY created_at DESC;
