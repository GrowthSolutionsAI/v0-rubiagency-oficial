-- Adicionar coluna attachments à tabela contact_registrations
ALTER TABLE contact_registrations 
ADD COLUMN IF NOT EXISTS attachments text[];

-- Adicionar comentário para documentar a coluna
COMMENT ON COLUMN contact_registrations.attachments IS 'Array de caminhos dos arquivos anexados no Supabase Storage';

-- Verificar se a coluna foi adicionada
SELECT column_name, data_type, is_nullable 
FROM information_schema.columns 
WHERE table_name = 'contact_registrations' 
AND column_name = 'attachments';
