-- Script para limpar todos os dados de teste
-- Execute este script no seu banco Neon para limpar os dados

-- Limpar arquivos de usuários
DELETE FROM user_files;

-- Limpar cadastros de usuários
DELETE FROM user_registrations;

-- Resetar sequências (IDs)
ALTER SEQUENCE user_registrations_id_seq RESTART WITH 1;
ALTER SEQUENCE user_files_id_seq RESTART WITH 1;

-- Verificar se limpou tudo
SELECT 'user_registrations' as table_name, COUNT(*) as count FROM user_registrations
UNION ALL
SELECT 'user_files' as table_name, COUNT(*) as count FROM user_files;
