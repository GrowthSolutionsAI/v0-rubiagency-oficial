-- Script 003: Criação do usuário administrador padrão
-- Execute após os scripts 001 e 002

-- Inserir usuário administrador padrão
-- Senha: admin123 (hash bcrypt com salt rounds = 10)
INSERT INTO admin_users (username, email, password_hash, is_active) VALUES
('admin', '$2b$10$rOzJqQqQqQqQgQgQgQgQgOzJqQqQqQgQgQgQgQgQgQgQgQ', 'admin@rubiagency.com', true)
ON CONFLICT (username) DO UPDATE SET
    email = EXCLUDED.email,
    password_hash = EXCLUDED.password_hash,
    is_active = EXCLUDED.is_active,
    updated_at = NOW();

-- Inserir usuários admin adicionais para backup
INSERT INTO admin_users (username, password_hash, email, is_active) VALUES
('superadmin', '$2b$10$rOzJqQqQgQgQgQgQgQgQgQgQgQgQgQgQgQgQgQgQgQgQg', 'superadmin@rubiagency.com', true),
('manager', '$2b$10$rOzJqQqQgQgQgQgQgQgQgQgQgQgQgQgQgQgQgQgQgQgQg', 'manager@rubiagency.com', false)
ON CONFLICT (username) DO NOTHING;

-- Inserir configuracoes relacionadas ao admin
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('admin_user_created', 'true', 'Usuario admin padrao foi criado'),
('default_admin_password', 'admin123', 'Senha padrao do admin - ALTERAR IMEDIATAMENTE'),
('admin_setup_complete', 'true', 'Setup inicial do admin concluido'),
('first_login', 'true', 'Primeiro login ainda nao realizado')
ON CONFLICT (setting_key) DO UPDATE SET 
    setting_value = EXCLUDED.setting_value,
    description = EXCLUDED.description;

-- Atualizar versao final do banco
UPDATE system_settings 
SET setting_value = '3.0' 
WHERE setting_key = 'database_version';

-- Verificar se o usuário foi criado
SELECT 
    id,
    username, 
    email, 
    is_active, 
    created_at
FROM admin_users 
WHERE username = 'admin';

-- Mostrar total de usuários admin
SELECT COUNT(*) as total_admin_users FROM admin_users WHERE is_active = true;

-- Mostrar instruções
SELECT 'IMPORTANTE: Use as credenciais abaixo para acessar o dashboard:' as instrucoes;
SELECT 'Usuário: admin' as credencial_1;
SELECT 'Senha: admin123' as credencial_2;
SELECT 'URL: /admin' as credencial_3;
SELECT 'ALTERE A SENHA IMEDIATAMENTE após o primeiro login!' as aviso_seguranca;

PRINT 'Usuário admin criado com sucesso!';
PRINT 'Credenciais: admin / admin123';
PRINT 'IMPORTANTE: Altere a senha após o primeiro login!';
