const testFormSubmission = async () => {
  console.log("🧪 INICIANDO TESTE DE CADASTRO NO FORMULÁRIO")
  console.log("=".repeat(50))

  // Dados de teste
  const testData = {
    name: "Maria Silva Teste",
    email: "maria.teste@email.com",
    whatsapp: "+55 11 99999-8888",
    instagram: "@maria_teste_model",
    age: 25,
    experience: "intermediate",
    message:
      "Olá! Sou a Maria e tenho interesse em trabalhar como modelo. Tenho experiência em fotografia e já participei de alguns ensaios. Meu Instagram é @maria_teste_model onde vocês podem ver meu portfólio. Estou muito animada com esta oportunidade!",
    partner_code: "MODELO_SP",
  }

  console.log("📝 Dados de teste preparados:")
  console.log(JSON.stringify(testData, null, 2))
  console.log("")

  try {
    // Simular o envio do formulário
    console.log("🚀 Simulando envio do formulário...")

    // Validações que serão feitas no servidor
    console.log("✅ Validando dados...")

    // 1. Validar campos obrigatórios
    if (!testData.name?.trim()) {
      throw new Error("Nome é obrigatório")
    }

    if (!testData.email?.trim()) {
      throw new Error("Email é obrigatório")
    }

    if (!testData.message?.trim()) {
      throw new Error("Mensagem é obrigatória")
    }

    if (!testData.age || isNaN(testData.age)) {
      throw new Error("Idade deve ser um número válido")
    }

    // 2. Validar idade
    if (testData.age < 18 || testData.age > 65) {
      throw new Error("Idade deve estar entre 18 e 65 anos")
    }

    // 3. Validar email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(testData.email.trim())) {
      throw new Error("Email inválido")
    }

    // 4. Validar Instagram
    if (!testData.instagram?.trim()) {
      throw new Error("Instagram é obrigatório")
    }

    if (!testData.instagram.startsWith("@")) {
      throw new Error("Instagram deve começar com @")
    }

    const instagramRegex = /^@[a-zA-Z0-9._]{1,30}$/
    if (!instagramRegex.test(testData.instagram.trim())) {
      throw new Error("Instagram inválido. Use apenas letras, números, pontos e underscore")
    }

    console.log("✅ Todas as validações passaram!")
    console.log("")

    // Simular limpeza dos dados
    const cleanData = {
      name: testData.name.trim(),
      email: testData.email.trim().toLowerCase(),
      phone: testData.whatsapp?.trim() || null,
      instagram: testData.instagram.trim(),
      age: Number(testData.age),
      subject: null,
      experience: testData.experience?.trim() || null,
      message: testData.message.trim(),
      partner_code: testData.partner_code?.trim() || null,
      status: "pending",
    }

    console.log("🧹 Dados limpos para o banco:")
    console.log(JSON.stringify(cleanData, null, 2))
    console.log("")

    // Simular busca do parceiro
    if (cleanData.partner_code) {
      console.log(`🔍 Buscando parceiro com código: ${cleanData.partner_code}`)
      console.log("✅ Parceiro encontrado: Agência Modelo SP")
    }

    // Simular inserção no banco
    console.log("💾 Simulando inserção no banco de dados...")
    const mockRegistration = {
      id: Date.now(),
      ...cleanData,
      partner_id: cleanData.partner_code ? 1 : null,
      partner_name: cleanData.partner_code ? "Agência Modelo SP" : null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }

    console.log("✅ Registro criado com sucesso!")
    console.log("📋 Dados do registro:")
    console.log(JSON.stringify(mockRegistration, null, 2))
    console.log("")

    // Simular revalidação das páginas
    console.log("🔄 Revalidando páginas do admin...")
    console.log("✅ Páginas revalidadas")
    console.log("")

    // Simular busca da mensagem de boas-vindas
    console.log("💬 Buscando mensagem de boas-vindas...")
    const welcomeMessage =
      "🌟 Obrigada por se cadastrar na Rubi Agency! Recebemos sua candidatura e nossa equipe irá analisá-la cuidadosamente. Entraremos em contato em até 48 horas através do seu Instagram ou email."
    console.log("✅ Mensagem encontrada")
    console.log("")

    // Resultado final
    const result = {
      success: true,
      message: welcomeMessage,
      registrationId: mockRegistration.id,
      registration: mockRegistration,
    }

    console.log("🎉 TESTE CONCLUÍDO COM SUCESSO!")
    console.log("📊 Resultado final:")
    console.log(JSON.stringify(result, null, 2))
    console.log("")

    // Instruções para teste real
    console.log("🔧 PRÓXIMOS PASSOS PARA TESTE REAL:")
    console.log("1. Execute os scripts SQL na ordem: 001 → 002 → 003 → 004")
    console.log("2. Acesse o site e preencha o formulário com dados similares")
    console.log("3. Verifique os logs no console do navegador")
    console.log("4. Acesse /admin com usuário 'admin' e senha 'admin123'")
    console.log("5. Confirme se o cadastro aparece na lista de registros")
    console.log("")

    return result
  } catch (error) {
    console.error("❌ ERRO NO TESTE:", error.message)
    console.log("")
    console.log("🔧 VERIFIQUE:")
    console.log("- Se todos os campos obrigatórios estão preenchidos")
    console.log("- Se o formato do email está correto")
    console.log("- Se o Instagram começa com @ e tem formato válido")
    console.log("- Se a idade está entre 18 e 65 anos")

    return {
      success: false,
      message: error.message,
      error: error,
    }
  }
}

async function runTest() {
  console.log("🧪 Starting form submission test...")

  try {
    const result = await testFormSubmission()

    console.log("🧪 Test completed!")
    console.log("📊 Result:", JSON.stringify(result, null, 2))

    if (result.success) {
      console.log("✅ Test PASSED - Form submission working correctly!")
      console.log("📝 Registration created:", result.registration)
    } else {
      console.log("❌ Test FAILED - Error:", result.error)
    }
  } catch (error) {
    console.error("💥 Test crashed:", error)
  }
}

// Executar o teste
runTest()
