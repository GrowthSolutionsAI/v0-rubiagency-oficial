-- Debug: Verificar se existem registros na tabela
SELECT 'Total de registros:' as info, COUNT(*) as count FROM user_registrations;

-- Debug: Contar por status
SELECT 
  'Contagem por status:' as info,
  status,
  COUNT(*) as count
FROM user_registrations 
GROUP BY status
ORDER BY status;

-- Debug: Verificar estrutura da tabela
SELECT 
  'Estrutura da tabela:' as info,
  column_name,
  data_type,
  is_nullable
FROM information_schema.columns 
WHERE table_name = 'user_registrations'
ORDER BY ordinal_position;

-- Debug: Últimos 5 registros
SELECT 
  'Últimos registros:' as info,
  id,
  name,
  email,
  status,
  created_at
FROM user_registrations 
ORDER BY created_at DESC 
LIMIT 5;

-- Debug: Verificar se a query de estatísticas funciona
SELECT 
  'Estatísticas agregadas:' as info,
  COUNT(*) as total,
  COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
  COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved,
  COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejected
FROM user_registrations;
