-- Adicionar configurações de email padrão ao sistema
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('site_name', 'Rubi Agency', 'Nome do site/empresa'),
('company_email', 'contato@rubiagency.com', 'Email principal da empresa'),
('company_phone', '(11) 99999-9999', 'Telefone principal da empresa'),
('admin_email', 'admin@rubiagency.com', 'Email do administrador para notificações'),
('smtp_enabled', 'false', 'Se o envio de email está ativo'),
('smtp_provider', 'gmail', 'Provedor de email (gmail, outlook, custom)'),
('smtp_from_name', 'Rubi Agency', 'Nome que aparece como remetente'),
('smtp_from_email', 'noreply@rubiagency.com', 'Email que aparece como remetente')
ON CONFLICT (setting_key) DO UPDATE SET
  setting_value = EXCLUDED.setting_value,
  updated_at = CURRENT_TIMESTAMP;
