#!/bin/bash

echo "🔍 Verificando configuração do Vercel..."

# Verificar se está logado
echo "Verificando login..."
vercel whoami

# Listar teams disponíveis
echo "Teams disponíveis:"
vercel teams list

# Verificar team atual
echo "Team atual:"
vercel teams current

# Listar projetos no team atual
echo "Projetos no team atual:"
vercel list

echo "✅ Verificação completa!"
echo ""
echo "📋 Próximos passos:"
echo "1. Se não estiver no team Premium, execute: vercel teams switch"
echo "2. Selecione seu team Premium"
echo "3. Execute: vercel --prod"
