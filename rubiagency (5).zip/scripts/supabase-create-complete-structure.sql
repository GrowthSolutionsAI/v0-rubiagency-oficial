-- =====================================================
-- SCRIPT COMPLETO CORRIGIDO (com valores reais e UPSERTs)
-- =====================================================

-- Extensão p/ gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- =====================================================
-- ESTRUTURA (idempotente)
-- =====================================================

CREATE TABLE IF NOT EXISTS contact_registrations (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  phone VARCHAR(20),
  instagram VARCHAR(100),
  age INTEGER,
  subject VARCHAR(255),
  experience TEXT,
  message TEXT NOT NULL,
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  partner_code VARCHAR(50),
  partner_id UUID,
  partner_name VARCHAR(255),
  attachments JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  approved_at TIMESTAMPTZ,
  approved_by VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS partners (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  phone VARCHAR(20),
  code VARCHAR(50) UNIQUE NOT NULL,
  description TEXT,
  commission_rate DECIMAL(5,2) DEFAULT 10.00,
  is_active BOOLEAN DEFAULT true,
  total_referrals INTEGER DEFAULT 0,
  total_registrations INTEGER DEFAULT 0,
  approved_registrations INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS system_settings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  setting_key VARCHAR(100) UNIQUE NOT NULL,
  setting_value TEXT,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS admin_users (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  username VARCHAR(100) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(255),
  is_active BOOLEAN DEFAULT true,
  last_login TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- ÍNDICES
-- =====================================================

CREATE INDEX IF NOT EXISTS idx_contact_registrations_status ON contact_registrations(status);
CREATE INDEX IF NOT EXISTS idx_contact_registrations_partner_code ON contact_registrations(partner_code);
CREATE INDEX IF NOT EXISTS idx_contact_registrations_partner_id ON contact_registrations(partner_id);
CREATE INDEX IF NOT EXISTS idx_contact_registrations_created_at ON contact_registrations(created_at);
CREATE INDEX IF NOT EXISTS idx_contact_registrations_email ON contact_registrations(email);

CREATE INDEX IF NOT EXISTS idx_partners_code ON partners(code);
CREATE INDEX IF NOT EXISTS idx_partners_email ON partners(email);
CREATE INDEX IF NOT EXISTS idx_partners_is_active ON partners(is_active);
CREATE INDEX IF NOT EXISTS idx_partners_created_at ON partners(created_at);

CREATE INDEX IF NOT EXISTS idx_system_settings_key ON system_settings(setting_key);

CREATE INDEX IF NOT EXISTS idx_admin_users_username ON admin_users(username);
CREATE INDEX IF NOT EXISTS idx_admin_users_email ON admin_users(email);
CREATE INDEX IF NOT EXISTS idx_admin_users_is_active ON admin_users(is_active);

-- =====================================================
-- DADOS PADRÃO (UPSERT com valores reais)
-- =====================================================

-- 1. PRIMEIRO: Inserir configurações do sistema
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
  ('site_name', 'Rubi Agency', 'Nome do site'),
  ('site_description', 'Agência de Marketing Digital', 'Descrição do site'),
  ('contact_email', 'contato@rubiagency.com', 'Email de contato'),
  ('admin_email', 'contato@rubiagency.com', 'Email do administrador'),
  ('email_service', 'smtp', 'Serviço de email (resend, sendgrid, smtp)'),
  ('smtp_host', 'smtp.gmail.com', 'Servidor SMTP'),
  ('smtp_port', '465', 'Porta SMTP'),
  ('smtp_user', 'contato@rubiagency.com', 'Usuário SMTP'),
  ('smtp_pass', 'ymxmutrfrtzkeice', 'Senha SMTP (senha de app Google, sem espaços)'),
  ('smtp_secure', 'true', 'Usa TLS implícito (true=465 | false=587 STARTTLS)'),
  ('email_from', 'Rubi Agency <contato@rubiagency.com>', 'Remetente padrão'),
  ('next_public_app_url', 'https://www.rubiagency.com', 'URL pública da aplicação'),
  ('resend_api_key', '', 'Chave API do Resend'),
  ('sendgrid_api_key', '', 'Chave API do SendGrid')
ON CONFLICT (setting_key) DO UPDATE
SET setting_value = EXCLUDED.setting_value,
    description   = COALESCE(system_settings.description, EXCLUDED.description),
    updated_at    = NOW();

-- 2. SEGUNDO: Inserir usuário admin
INSERT INTO admin_users (username, email, password_hash, full_name, is_active) VALUES
  ('admin', 'contato@rubiagency.com', '$2b$10$rQZ8kHWKtGkVQW5Oe5nGxeJ7vQZ8kHWKtGkVQW5Oe5nGxeJ7vQZ8kH', 'Administrador', true)
ON CONFLICT (username) DO UPDATE
SET email = EXCLUDED.email,
    full_name = EXCLUDED.full_name,
    is_active = EXCLUDED.is_active,
    updated_at = NOW();

-- 3. TERCEIRO: Inserir parceiros (sem conflito)
INSERT INTO partners (name, email, code, description, commission_rate, is_active, total_referrals, total_registrations, approved_registrations) VALUES
  ('João Silva', 'joao@exemplo.com', 'JOAO001', 'Parceiro especializado em redes sociais', 10.00, true, 0, 0, 0),
  ('Maria Santos', 'maria@exemplo.com', 'MARIA002', 'Influenciadora digital', 15.00, true, 0, 0, 0),
  ('Pedro Costa', 'pedro@exemplo.com', 'PEDRO003', 'Consultor de marketing', 12.00, true, 0, 0, 0),
  ('Ana Oliveira', 'ana@exemplo.com', 'ANA004', 'Especialista em SEO', 10.00, false, 0, 0, 0),
  ('Carlos Ferreira', 'carlos@exemplo.com', 'CARLOS005', 'Designer gráfico', 8.00, true, 0, 0, 0)
ON CONFLICT (email) DO NOTHING;

-- 4. QUARTO: Inserir registros de exemplo (usando subquery para pegar partner_id)
DO $$
DECLARE
    joao_id UUID;
    maria_id UUID;
    pedro_id UUID;
    ana_id UUID;
    carlos_id UUID;
BEGIN
    -- Buscar IDs dos parceiros
    SELECT id INTO joao_id FROM partners WHERE code = 'JOAO001';
    SELECT id INTO maria_id FROM partners WHERE code = 'MARIA002';
    SELECT id INTO pedro_id FROM partners WHERE code = 'PEDRO003';
    SELECT id INTO ana_id FROM partners WHERE code = 'ANA004';
    SELECT id INTO carlos_id FROM partners WHERE code = 'CARLOS005';

    -- Inserir registros de exemplo
    INSERT INTO contact_registrations (name, email, phone, instagram, age, message, status, partner_code, partner_id, partner_name) VALUES
      ('Ana Silva', 'ana.silva@email.com', '(11) 99999-1111', '@anasilva', 25, 'Gostaria de saber mais sobre os serviços de marketing digital.', 'pending', 'JOAO001', joao_id, 'João Silva'),
      ('Bruno Santos', 'bruno@email.com', '(11) 99999-2222', '@brunosantos', 30, 'Preciso de ajuda com minha presença online.', 'approved', 'MARIA002', maria_id, 'Maria Santos'),
      ('Carla Oliveira', 'carla@email.com', '(11) 99999-3333', '@carlaoliveira', 28, 'Quero melhorar o SEO do meu site.', 'approved', 'PEDRO003', pedro_id, 'Pedro Costa'),
      ('Diego Costa', 'diego@email.com', '(11) 99999-4444', '@diegocosta', 35, 'Interessado em campanhas de publicidade.', 'rejected', 'ANA004', ana_id, 'Ana Oliveira'),
      ('Elena Ferreira', 'elena@email.com', '(11) 99999-5555', '@elenaferreira', 27, 'Preciso de um novo design para minha marca.', 'pending', 'CARLOS005', carlos_id, 'Carlos Ferreira'),
      ('Felipe Lima', 'felipe@email.com', '(11) 99999-6666', '@felipelima', 32, 'Quero aumentar minhas vendas online.', 'approved', 'JOAO001', joao_id, 'João Silva'),
      ('Gabriela Rocha', 'gabriela@email.com', '(11) 99999-7777', '@gabrielarocha', 26, 'Interessada em consultoria de marketing.', 'pending', 'MARIA002', maria_id, 'Maria Santos'),
      ('Henrique Alves', 'henrique@email.com', '(11) 99999-8888', '@henriquealves', 29, 'Preciso de ajuda com redes sociais.', 'approved', 'PEDRO003', pedro_id, 'Pedro Costa')
    ON CONFLICT (email) DO NOTHING;
END $$;

-- =====================================================
-- FUNÇÕES / TRIGGERS
-- =====================================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Remover triggers existentes se houver
DROP TRIGGER IF EXISTS update_contact_registrations_updated_at ON contact_registrations;
DROP TRIGGER IF EXISTS update_partners_updated_at ON partners;
DROP TRIGGER IF EXISTS update_system_settings_updated_at ON system_settings;
DROP TRIGGER IF EXISTS update_admin_users_updated_at ON admin_users;

-- Criar triggers
CREATE TRIGGER update_contact_registrations_updated_at
  BEFORE UPDATE ON contact_registrations
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_partners_updated_at
  BEFORE UPDATE ON partners
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_system_settings_updated_at
  BEFORE UPDATE ON system_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_admin_users_updated_at
  BEFORE UPDATE ON admin_users
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Função para atualizar estatísticas dos parceiros
CREATE OR REPLACE FUNCTION update_partner_stats()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.partner_id IS NOT NULL THEN
    UPDATE partners 
    SET 
      total_registrations = (SELECT COUNT(*) FROM contact_registrations WHERE partner_id = NEW.partner_id),
      approved_registrations = (SELECT COUNT(*) FROM contact_registrations WHERE partner_id = NEW.partner_id AND status = 'approved'),
      total_referrals = (SELECT COUNT(*) FROM contact_registrations WHERE partner_id = NEW.partner_id),
      updated_at = NOW()
    WHERE id = NEW.partner_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para estatísticas
DROP TRIGGER IF EXISTS update_partner_stats_trigger ON contact_registrations;
CREATE TRIGGER update_partner_stats_trigger
  AFTER INSERT OR UPDATE ON contact_registrations
  FOR EACH ROW
  EXECUTE FUNCTION update_partner_stats();

-- =====================================================
-- ATUALIZAR ESTATÍSTICAS INICIAIS
-- =====================================================
UPDATE partners 
SET 
  total_registrations = COALESCE((SELECT COUNT(*) FROM contact_registrations WHERE partner_id = partners.id), 0),
  approved_registrations = COALESCE((SELECT COUNT(*) FROM contact_registrations WHERE partner_id = partners.id AND status = 'approved'), 0),
  total_referrals = COALESCE((SELECT COUNT(*) FROM contact_registrations WHERE partner_id = partners.id), 0);

-- =====================================================
-- PERMISSÕES (RLS) - idempotente
-- =====================================================
ALTER TABLE contact_registrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE partners ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Remover políticas existentes
DROP POLICY IF EXISTS "Allow public read access" ON contact_registrations;
DROP POLICY IF EXISTS "Allow public insert access" ON contact_registrations;
DROP POLICY IF EXISTS "Allow public update access" ON contact_registrations;
DROP POLICY IF EXISTS "Allow public delete access" ON contact_registrations;

DROP POLICY IF EXISTS "Allow public read access" ON partners;
DROP POLICY IF EXISTS "Allow public insert access" ON partners;
DROP POLICY IF EXISTS "Allow public update access" ON partners;
DROP POLICY IF EXISTS "Allow public delete access" ON partners;

DROP POLICY IF EXISTS "Allow public read access" ON system_settings;
DROP POLICY IF EXISTS "Allow public insert access" ON system_settings;
DROP POLICY IF EXISTS "Allow public update access" ON system_settings;
DROP POLICY IF EXISTS "Allow public delete access" ON system_settings;

DROP POLICY IF EXISTS "Allow public read access" ON admin_users;
DROP POLICY IF EXISTS "Allow public insert access" ON admin_users;
DROP POLICY IF EXISTS "Allow public update access" ON admin_users;
DROP POLICY IF EXISTS "Allow public delete access" ON admin_users;

-- Criar políticas permissivas (ajustar conforme necessário em produção)
CREATE POLICY "Allow public read access" ON contact_registrations FOR SELECT USING (true);
CREATE POLICY "Allow public insert access" ON contact_registrations FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update access" ON contact_registrations FOR UPDATE USING (true);
CREATE POLICY "Allow public delete access" ON contact_registrations FOR DELETE USING (true);

CREATE POLICY "Allow public read access" ON partners FOR SELECT USING (true);
CREATE POLICY "Allow public insert access" ON partners FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update access" ON partners FOR UPDATE USING (true);
CREATE POLICY "Allow public delete access" ON partners FOR DELETE USING (true);

CREATE POLICY "Allow public read access" ON system_settings FOR SELECT USING (true);
CREATE POLICY "Allow public insert access" ON system_settings FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update access" ON system_settings FOR UPDATE USING (true);
CREATE POLICY "Allow public delete access" ON system_settings FOR DELETE USING (true);

CREATE POLICY "Allow public read access" ON admin_users FOR SELECT USING (true);
CREATE POLICY "Allow public insert access" ON admin_users FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update access" ON admin_users FOR UPDATE USING (true);
CREATE POLICY "Allow public delete access" ON admin_users FOR DELETE USING (true);

-- =====================================================
-- FOREIGN KEYS (opcional, para integridade referencial)
-- =====================================================
DO $$
BEGIN
    -- Adicionar FK se não existir
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'fk_contact_registrations_partner_id'
    ) THEN
        ALTER TABLE contact_registrations 
        ADD CONSTRAINT fk_contact_registrations_partner_id 
        FOREIGN KEY (partner_id) REFERENCES partners(id) ON DELETE SET NULL;
    END IF;
END $$;

-- =====================================================
-- COMENTÁRIOS E DOCUMENTAÇÃO
-- =====================================================
COMMENT ON TABLE contact_registrations IS 'Registros de contato e inscrições dos usuários';
COMMENT ON TABLE partners IS 'Parceiros e afiliados do sistema';
COMMENT ON TABLE system_settings IS 'Configurações gerais do sistema';
COMMENT ON TABLE admin_users IS 'Usuários administradores do sistema';

COMMENT ON COLUMN partners.code IS 'Código único do parceiro para referências';
COMMENT ON COLUMN partners.commission_rate IS 'Taxa de comissão em porcentagem';
COMMENT ON COLUMN contact_registrations.partner_code IS 'Código do parceiro que fez a indicação';
COMMENT ON COLUMN contact_registrations.status IS 'Status: pending, approved, rejected';

-- =====================================================
-- RESUMO FINAL
-- =====================================================
SELECT 
    'contact_registrations' AS tabela, 
    COUNT(*) AS registros,
    'Registros de contato' AS descricao
FROM contact_registrations
UNION ALL 
SELECT 
    'partners', 
    COUNT(*), 
    'Parceiros cadastrados'
FROM partners
UNION ALL 
SELECT 
    'system_settings', 
    COUNT(*), 
    'Configurações do sistema'
FROM system_settings
UNION ALL 
SELECT 
    'admin_users', 
    COUNT(*), 
    'Usuários administradores'
FROM admin_users
ORDER BY tabela;

-- Mostrar alguns dados de exemplo
SELECT 'PARCEIROS CADASTRADOS:' AS info;
SELECT code, name, email, is_active, total_registrations FROM partners ORDER BY code;

SELECT 'CONFIGURAÇÕES PRINCIPAIS:' AS info;
SELECT setting_key, setting_value FROM system_settings 
WHERE setting_key IN ('site_name', 'email_service', 'smtp_host', 'contact_email') 
ORDER BY setting_key;

SELECT 'ESTATÍSTICAS:' AS info;
SELECT 
    COUNT(*) as total_registrations,
    COUNT(*) FILTER (WHERE status = 'pending') as pending,
    COUNT(*) FILTER (WHERE status = 'approved') as approved,
    COUNT(*) FILTER (WHERE status = 'rejected') as rejected
FROM contact_registrations;
