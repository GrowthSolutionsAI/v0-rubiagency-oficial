-- Script de validação completa do sistema
-- Verificar todas as configurações e estruturas

-- 1. Verificar se todas as tabelas existem
SELECT 
    'Tabelas do Sistema' as categoria,
    CASE 
        WHEN EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'user_registrations') 
        THEN '✅ user_registrations existe'
        ELSE '❌ user_registrations NÃO existe'
    END as user_registrations,
    CASE 
        WHEN EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'partners') 
        THEN '✅ partners existe'
        ELSE '❌ partners NÃO existe'
    END as partners,
    CASE 
        WHEN EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'system_settings') 
        THEN '✅ system_settings existe'
        ELSE '❌ system_settings NÃO existe'
    END as system_settings;

-- 2. Verificar colunas da tabela user_registrations
SELECT 
    'Colunas user_registrations' as categoria,
    CASE 
        WHEN EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'user_registrations' AND column_name = 'partner_id') 
        THEN '✅ partner_id existe'
        ELSE '❌ partner_id NÃO existe'
    END as partner_id,
    CASE 
        WHEN EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'user_registrations' AND column_name = 'partner_code') 
        THEN '✅ partner_code existe'
        ELSE '❌ partner_code NÃO existe'
    END as partner_code,
    CASE 
        WHEN EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'user_registrations' AND column_name = 'instagram') 
        THEN '✅ instagram existe'
        ELSE '❌ instagram NÃO existe'
    END as instagram;

-- 3. Verificar índices importantes
SELECT 
    'Índices do Sistema' as categoria,
    CASE 
        WHEN EXISTS (SELECT 1 FROM pg_indexes WHERE tablename = 'partners' AND indexname = 'idx_partners_code') 
        THEN '✅ idx_partners_code existe'
        ELSE '❌ idx_partners_code NÃO existe'
    END as partners_code_index,
    CASE 
        WHEN EXISTS (SELECT 1 FROM pg_indexes WHERE tablename = 'user_registrations' AND indexname = 'idx_registrations_partner_id') 
        THEN '✅ idx_registrations_partner_id existe'
        ELSE '❌ idx_registrations_partner_id NÃO existe'
    END as registrations_partner_index;

-- 4. Verificar triggers e funções
SELECT 
    'Triggers e Funções' as categoria,
    CASE 
        WHEN EXISTS (SELECT 1 FROM information_schema.routines WHERE routine_name = 'update_partner_referrals') 
        THEN '✅ update_partner_referrals função existe'
        ELSE '❌ update_partner_referrals função NÃO existe'
    END as partner_function,
    CASE 
        WHEN EXISTS (SELECT 1 FROM information_schema.triggers WHERE trigger_name = 'trigger_update_partner_referrals') 
        THEN '✅ trigger_update_partner_referrals existe'
        ELSE '❌ trigger_update_partner_referrals NÃO existe'
    END as partner_trigger;

-- 5. Contar dados existentes
SELECT 
    'Dados do Sistema' as categoria,
    (SELECT COUNT(*) FROM user_registrations) as total_registrations,
    (SELECT COUNT(*) FROM partners) as total_partners,
    (SELECT COUNT(*) FROM system_settings) as total_settings,
    (SELECT COUNT(*) FROM user_registrations WHERE partner_id IS NOT NULL) as registrations_with_partner;

-- 6. Verificar parceiros de exemplo
SELECT 
    'Parceiros Cadastrados' as categoria,
    id,
    name,
    code,
    commission_rate,
    total_referrals,
    is_active,
    created_at
FROM partners 
ORDER BY created_at DESC;

-- 7. Verificar configurações do sistema
SELECT 
    'Configurações do Sistema' as categoria,
    setting_key,
    LEFT(setting_value, 100) as setting_value_preview,
    updated_at
FROM system_settings 
ORDER BY setting_key;

-- 8. Verificar registros recentes com informações de parceiro
SELECT 
    'Registros Recentes' as categoria,
    ur.id,
    ur.name,
    ur.email,
    ur.instagram,
    ur.status,
    ur.partner_code,
    p.name as partner_name,
    ur.created_at
FROM user_registrations ur
LEFT JOIN partners p ON ur.partner_id = p.id
ORDER BY ur.created_at DESC
LIMIT 10;

-- 9. Verificar integridade referencial
SELECT 
    'Integridade dos Dados' as categoria,
    CASE 
        WHEN (SELECT COUNT(*) FROM user_registrations WHERE partner_id IS NOT NULL AND partner_id NOT IN (SELECT id FROM partners)) = 0
        THEN '✅ Todas as referências de partner_id são válidas'
        ELSE '❌ Existem referências inválidas de partner_id'
    END as partner_references,
    CASE 
        WHEN (SELECT COUNT(*) FROM partners WHERE total_referrals != (SELECT COUNT(*) FROM user_registrations WHERE partner_id = partners.id)) = 0
        THEN '✅ Contadores de referrals estão corretos'
        ELSE '❌ Contadores de referrals estão incorretos'
    END as referral_counters;

-- 10. Status geral do sistema
SELECT 
    'Status Geral' as categoria,
    CASE 
        WHEN EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'partners')
        AND EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'user_registrations' AND column_name = 'partner_id')
        AND EXISTS (SELECT 1 FROM information_schema.triggers WHERE trigger_name = 'trigger_update_partner_referrals')
        AND (SELECT COUNT(*) FROM partners) > 0
        THEN '🎉 SISTEMA COMPLETAMENTE CONFIGURADO E FUNCIONAL!'
        ELSE '⚠️ Sistema precisa de configuração adicional'
    END as status_final;
