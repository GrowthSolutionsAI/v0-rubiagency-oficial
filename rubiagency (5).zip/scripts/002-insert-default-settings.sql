-- Inserir configurações padrão do sistema
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('welcome_message', '🌟 Obrigada por se cadastrar na Rubi Agency! Recebemos sua candidatura e nossa equipe irá analisá-la cuidadosamente. Entraremos em contato em até 48 horas através do seu Instagram ou email.', 'Mensagem exibida após cadastro bem-sucedido'),
('site_name', 'Rubi Agency', 'Nome do site'),
('contact_email', 'contato@rubiagency.com', 'Email principal de contato'),
('max_age', '50', 'Idade máxima permitida para cadastro'),
('min_age', '16', 'Idade mínima permitida para cadastro'),
('registration_enabled', 'true', 'Se o cadastro está habilitado'),
('admin_notifications', 'true', 'Se notificações admin estão habilitadas')
ON CONFLICT (setting_key) DO UPDATE SET
    setting_value = EXCLUDED.setting_value,
    updated_at = NOW();

-- Inserir parceiros de exemplo
INSERT INTO partners (name, email, code, description, commission_rate, is_active) VALUES
('Agência Modelo SP', 'contato@agenciamodelo.com', 'MODELO_SP', 'Parceria com agência de modelos de São Paulo', 10.00, true),
('Influencer Maria', 'maria@instagram.com', 'MARIA_INFL', 'Influencer digital com 100k seguidores', 15.00, true),
('Studio Fashion RJ', 'contato@studiofashion.com', 'FASHION_RJ', 'Estúdio de fotografia fashion no Rio de Janeiro', 8.00, true),
('Agência Elite Models', 'elite@models.com', 'ELITE_MODELS', 'Agência de modelos elite', 12.00, true)
ON CONFLICT (code) DO UPDATE SET
    name = EXCLUDED.name,
    email = EXCLUDED.email,
    description = EXCLUDED.description,
    commission_rate = EXCLUDED.commission_rate,
    is_active = EXCLUDED.is_active,
    updated_at = NOW();

-- Verificar inserções
SELECT 'system_settings' as tabela, COUNT(*) as registros FROM system_settings
UNION ALL
SELECT 'partners' as tabela, COUNT(*) as registros FROM partners;

PRINT 'Configurações padrão inseridas com sucesso!';
