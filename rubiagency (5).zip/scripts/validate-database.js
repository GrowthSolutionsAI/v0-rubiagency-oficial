import { testDatabaseConnection, getUserRegistrations, getRegistrationStats } from "../lib/database.js"

async function validateDatabase() {
  console.log("🔍 Starting database validation...")

  try {
    // Test connection
    console.log("1. Testing database connection...")
    const isConnected = await testDatabaseConnection()
    console.log(`   Connection: ${isConnected ? "✅ SUCCESS" : "❌ FAILED"}`)

    // Test registrations
    console.log("2. Testing user registrations...")
    const registrations = await getUserRegistrations()
    console.log(`   Found ${registrations.length} registrations`)

    // Test stats
    console.log("3. Testing registration stats...")
    const stats = await getRegistrationStats()
    console.log("   Stats:", stats)

    // Summary
    console.log("\n📊 VALIDATION SUMMARY:")
    console.log(`   Database Connected: ${isConnected ? "✅" : "❌"}`)
    console.log(`   Total Registrations: ${registrations.length}`)
    console.log(`   Pending: ${stats.pending}`)
    console.log(`   Approved: ${stats.approved}`)
    console.log(`   Rejected: ${stats.rejected}`)

    if (isConnected && registrations.length >= 0) {
      console.log("\n🎉 Database validation PASSED!")
    } else {
      console.log("\n⚠️ Database validation has issues")
    }
  } catch (error) {
    console.error("💥 Validation crashed:", error)
  }
}

validateDatabase()
