-- Validação final das estatísticas do dashboard
-- Este script verifica se existem dados na tabela user_registrations

-- 1. Verificar se a tabela existe
SELECT 
  table_name,
  table_schema
FROM information_schema.tables 
WHERE table_name = 'user_registrations';

-- 2. Contar total de registros
SELECT 
  'Total de registros' as metric,
  COUNT(*) as value
FROM user_registrations;

-- 3. Contar por status
SELECT 
  'Contagem por status' as metric,
  status,
  COUNT(*) as count
FROM user_registrations 
GROUP BY status
ORDER BY status;

-- 4. Estatísticas agregadas (igual à função do dashboard)
SELECT 
  COUNT(*) as total,
  COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
  COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved,
  COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejected
FROM user_registrations;

-- 5. Verificar registros recentes
SELECT 
  id,
  name,
  email,
  status,
  created_at
FROM user_registrations 
ORDER BY created_at DESC 
LIMIT 5;

-- 6. Verificar se há problemas de encoding ou dados nulos
SELECT 
  'Verificação de dados' as check_type,
  COUNT(CASE WHEN status IS NULL THEN 1 END) as null_status,
  COUNT(CASE WHEN status NOT IN ('pending', 'approved', 'rejected') THEN 1 END) as invalid_status,
  COUNT(CASE WHEN name IS NULL OR name = '' THEN 1 END) as empty_names
FROM user_registrations;
