-- Verificar se existem dados na tabela user_registrations
SELECT 
  'user_registrations' as tabela,
  COUNT(*) as total_registros,
  COUNT(CASE WHEN status = 'pending' THEN 1 END) as pendentes,
  COUNT(CASE WHEN status = 'approved' THEN 1 END) as aprovados,
  COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejeitados
FROM user_registrations;

-- Verificar os últimos 5 registros
SELECT 
  id,
  name,
  email,
  status,
  partner_code,
  created_at
FROM user_registrations 
ORDER BY created_at DESC 
LIMIT 5;

-- Verificar se existem parceiros
SELECT 
  'partners' as tabela,
  COUNT(*) as total_parceiros,
  COUNT(CASE WHEN is_active = true THEN 1 END) as ativos
FROM partners;

-- Verificar registros com parceiros
SELECT 
  ur.name,
  ur.status,
  p.name as partner_name,
  ur.created_at
FROM user_registrations ur
LEFT JOIN partners p ON ur.partner_id = p.id
WHERE ur.partner_id IS NOT NULL
ORDER BY ur.created_at DESC
LIMIT 3;
