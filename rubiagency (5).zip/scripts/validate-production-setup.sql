-- ===================================
-- VALIDAÇÃO COMPLETA DO SISTEMA PARA PRODUÇÃO
-- ===================================

-- 1. Verificar estrutura das tabelas
SELECT 
    table_name,
    column_name,
    data_type,
    is_nullable
FROM information_schema.columns 
WHERE table_schema = 'public' 
    AND table_name IN ('contact_registrations', 'system_settings', 'partners', 'admin_users')
ORDER BY table_name, ordinal_position;

-- 2. Verificar dados de teste
SELECT 
    'contact_registrations' as table_name,
    COUNT(*) as total_records,
    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
    COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved,
    COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejected
FROM contact_registrations

UNION ALL

SELECT 
    'system_settings' as table_name,
    COUNT(*) as total_records,
    0 as pending,
    0 as approved,
    0 as rejected
FROM system_settings

UNION ALL

SELECT 
    'partners' as table_name,
    COUNT(*) as total_records,
    COUNT(CASE WHEN is_active = true THEN 1 END) as active,
    COUNT(CASE WHEN is_active = false THEN 1 END) as inactive,
    0 as rejected
FROM partners;

-- 3. Verificar configurações do sistema
SELECT setting_key, setting_value, description
FROM system_settings
ORDER BY setting_key;

-- 4. Verificar políticas RLS
SELECT 
    schemaname,
    tablename,
    rowsecurity,
    policyname,
    permissive,
    roles,
    cmd,
    qual
FROM pg_policies 
WHERE schemaname = 'public';

-- 5. Verificar triggers
SELECT 
    trigger_name,
    event_manipulation,
    event_object_table,
    action_statement
FROM information_schema.triggers 
WHERE trigger_schema = 'public';

-- 6. Verificar índices
SELECT 
    schemaname,
    tablename,
    indexname,
    indexdef
FROM pg_indexes 
WHERE schemaname = 'public'
ORDER BY tablename, indexname;

-- 7. Testar inserção de registro
INSERT INTO contact_registrations (
    name, 
    email, 
    phone, 
    instagram, 
    message, 
    status,
    created_at
) VALUES (
    'Teste Produção',
    'teste@rubiagency.com',
    '(11) 99999-9999',
    '@testeprod',
    'Teste de validação para produção',
    'pending',
    NOW()
) RETURNING id, name, status, created_at;

-- 8. Verificar estatísticas finais
SELECT 
    'VALIDAÇÃO COMPLETA' as status,
    COUNT(*) as total_registrations,
    COUNT(CASE WHEN created_at >= CURRENT_DATE - INTERVAL '30 days' THEN 1 END) as last_30_days,
    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_approval
FROM contact_registrations;

-- 9. Verificar configurações de email
SELECT 
    setting_key,
    CASE 
        WHEN setting_key LIKE '%password%' OR setting_key LIKE '%key%' OR setting_key LIKE '%secret%' 
        THEN '***HIDDEN***'
        ELSE setting_value
    END as setting_value
FROM system_settings 
WHERE setting_key LIKE '%email%' OR setting_key LIKE '%smtp%' OR setting_key LIKE '%resend%' OR setting_key LIKE '%sendgrid%'
ORDER BY setting_key;

-- 10. Status final
SELECT 
    'SISTEMA VALIDADO PARA PRODUÇÃO' as message,
    NOW() as validation_timestamp,
    'READY FOR DEPLOYMENT' as status;
