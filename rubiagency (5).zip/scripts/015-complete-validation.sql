-- ===================================
-- VALIDAÇÃO COMPLETA DO SISTEMA
-- ===================================

-- 1. Verificar se as tabelas existem
SELECT 
    'user_registrations' as table_name,
    COUNT(*) as total_records
FROM user_registrations
UNION ALL
SELECT 
    'partners' as table_name,
    COUNT(*) as total_records  
FROM partners
UNION ALL
SELECT 
    'system_settings' as table_name,
    COUNT(*) as total_records
FROM system_settings;

-- 2. Verificar estatísticas detalhadas dos cadastros
SELECT 
    'ESTATÍSTICAS GERAIS' as categoria,
    COUNT(*) as total,
    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pendentes,
    COUNT(CASE WHEN status = 'approved' THEN 1 END) as aprovados,
    COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejeitados
FROM user_registrations;

-- 3. Verificar cadastros por status
SELECT 
    status,
    COUNT(*) as quantidade,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM user_registrations), 2) as percentual
FROM user_registrations 
GROUP BY status
ORDER BY quantidade DESC;

-- 4. Verificar cadastros recentes (últimos 10)
SELECT 
    id,
    name,
    email,
    status,
    partner_code,
    created_at,
    CASE 
        WHEN created_at > NOW() - INTERVAL '1 day' THEN 'Hoje'
        WHEN created_at > NOW() - INTERVAL '7 days' THEN 'Esta semana'
        WHEN created_at > NOW() - INTERVAL '30 days' THEN 'Este mês'
        ELSE 'Mais antigo'
    END as periodo
FROM user_registrations 
ORDER BY created_at DESC 
LIMIT 10;

-- 5. Verificar parceiros e suas indicações
SELECT 
    p.name as parceiro,
    p.code as codigo,
    p.is_active as ativo,
    COUNT(ur.id) as total_indicacoes,
    COUNT(CASE WHEN ur.status = 'pending' THEN 1 END) as pendentes,
    COUNT(CASE WHEN ur.status = 'approved' THEN 1 END) as aprovados
FROM partners p
LEFT JOIN user_registrations ur ON p.id = ur.partner_id
GROUP BY p.id, p.name, p.code, p.is_active
ORDER BY total_indicacoes DESC;

-- 6. Verificar integridade dos dados
SELECT 
    'Cadastros sem nome' as problema,
    COUNT(*) as quantidade
FROM user_registrations 
WHERE name IS NULL OR name = ''
UNION ALL
SELECT 
    'Cadastros sem email' as problema,
    COUNT(*) as quantidade
FROM user_registrations 
WHERE email IS NULL OR email = ''
UNION ALL
SELECT 
    'Cadastros com partner_code mas sem partner_id' as problema,
    COUNT(*) as quantidade
FROM user_registrations 
WHERE partner_code IS NOT NULL AND partner_id IS NULL;

-- 7. Verificar configurações do sistema
SELECT 
    setting_key as configuracao,
    LEFT(setting_value, 50) as valor_preview,
    updated_at as ultima_atualizacao
FROM system_settings
ORDER BY setting_key;

-- 8. Verificar dados de teste/exemplo
SELECT 
    'Cadastros de teste' as tipo,
    COUNT(*) as quantidade
FROM user_registrations 
WHERE email LIKE '%test%' OR email LIKE '%exemplo%' OR name LIKE '%Test%';

-- 9. Resumo final para dashboard
SELECT 
    'RESUMO PARA DASHBOARD' as info,
    (SELECT COUNT(*) FROM user_registrations) as total_cadastros,
    (SELECT COUNT(*) FROM user_registrations WHERE status = 'pending') as pendentes,
    (SELECT COUNT(*) FROM user_registrations WHERE status = 'approved') as aprovados,
    (SELECT COUNT(*) FROM user_registrations WHERE status = 'rejected') as rejeitados,
    (SELECT COUNT(*) FROM partners WHERE is_active = true) as parceiros_ativos;
