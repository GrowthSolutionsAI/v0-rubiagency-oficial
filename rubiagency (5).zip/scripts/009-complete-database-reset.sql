-- ============================================
-- SCRIPT DE RESET COMPLETO DO BANCO DE DADOS
-- Execute este script para limpar todos os dados
-- ============================================

-- 1. LIMPAR TODOS OS DADOS
DELETE FROM user_files;
DELETE FROM user_registrations;
DELETE FROM system_settings;

-- 2. RESETAR SEQUÊNCIAS (IDs voltam para 1)
ALTER SEQUENCE user_registrations_id_seq RESTART WITH 1;
ALTER SEQUENCE user_files_id_seq RESTART WITH 1;

-- 3. INSERIR CONFIGURAÇÕES PADRÃO
INSERT INTO system_settings (setting_key, setting_value, description, updated_at) VALUES
('welcome_message', '🌟 Obrigada por se cadastrar na Rubi Agency! Recebemos sua candidatura e nossa equipe irá analisá-la cuidadosamente. Entraremos em contato em até 48 horas através do seu Instagram ou email.', 'Mensagem exibida após o cadastro', NOW()),
('site_title', 'Rubi Agency - Agência de Modelos', 'Título do site', NOW()),
('contact_email', 'contato@rubiagency.com', 'Email de contato principal', NOW()),
('max_file_size', '5242880', 'Tamanho máximo de arquivo em bytes (5MB)', NOW()),
('allowed_file_types', 'image/jpeg,image/png,image/webp', 'Tipos de arquivo permitidos', NOW()),
('registration_enabled', 'true', 'Se o cadastro está habilitado', NOW()),
('admin_notifications', 'true', 'Se notificações admin estão habilitadas', NOW())
ON CONFLICT (setting_key) DO UPDATE SET 
  setting_value = EXCLUDED.setting_value,
  updated_at = NOW();

-- 4. VERIFICAR SE O RESET FOI EXECUTADO
SELECT 
  'RESET COMPLETO EXECUTADO' as status,
  NOW() as timestamp,
  (SELECT COUNT(*) FROM user_registrations) as registrations_count,
  (SELECT COUNT(*) FROM user_files) as files_count,
  (SELECT COUNT(*) FROM system_settings) as settings_count;

-- 5. TESTAR INSERÇÃO DE DADOS DE EXEMPLO
INSERT INTO user_registrations (
  name, email, phone, age, height, weight, city, state, 
  experience, instagram, status, created_at, updated_at
) VALUES (
  'Teste Sistema', 
  'teste@sistema.com', 
  '(11) 99999-9999', 
  25, 
  170, 
  60, 
  'São Paulo', 
  'SP', 
  'Iniciante', 
  '@teste_sistema', 
  'pending', 
  NOW(), 
  NOW()
);

-- 6. VERIFICAR SE A INSERÇÃO FUNCIONOU
SELECT 
  'TESTE DE INSERÇÃO' as test_type,
  id, name, email, instagram, status, created_at
FROM user_registrations 
WHERE email = 'teste@sistema.com';

-- 7. REMOVER O REGISTRO DE TESTE
DELETE FROM user_registrations WHERE email = 'teste@sistema.com';

-- 8. CONFIRMAÇÃO FINAL
SELECT 
  'DATABASE RESET E TESTE CONCLUÍDO' as final_status,
  NOW() as completion_time,
  (SELECT COUNT(*) FROM user_registrations) as final_registrations_count,
  (SELECT COUNT(*) FROM system_settings) as final_settings_count;
