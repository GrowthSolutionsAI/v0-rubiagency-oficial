import fs from "node:fs"

interface ValidationResult {
  step: string
  status: "PASS" | "FAIL"
  details: string
  patch?: string
}

export default async function run() {
  const results: ValidationResult[] = []

  console.log("🚀 INICIANDO VALIDAÇÃO DEVOPS - RUBI AGENCY")
  console.log("=".repeat(60))

  // 1. BUILD VALIDATION
  try {
    console.log("📦 Validando Build...")

    // Verificar se package.json existe
    if (!fs.existsSync("package.json")) {
      results.push({
        step: "Build - package.json",
        status: "FAIL",
        details: "package.json não encontrado",
        patch: "Certifique-se de estar no diretório raiz do projeto",
      })
    } else {
      results.push({
        step: "Build - package.json",
        status: "PASS",
        details: "package.json encontrado",
      })
    }

    // Verificar dependências críticas
    const packageJson = JSON.parse(fs.readFileSync("package.json", "utf8"))
    const criticalDeps = ["next", "react", "@supabase/supabase-js", "nodemailer"]

    for (const dep of criticalDeps) {
      if (packageJson.dependencies?.[dep] || packageJson.devDependencies?.[dep]) {
        results.push({
          step: `Build - ${dep}`,
          status: "PASS",
          details: `Dependência ${dep} encontrada`,
        })
      } else {
        results.push({
          step: `Build - ${dep}`,
          status: "FAIL",
          details: `Dependência ${dep} não encontrada`,
          patch: `npm install ${dep}`,
        })
      }
    }

    // Verificar arquivos críticos
    const criticalFiles = [
      "app/layout.tsx",
      "app/page.tsx",
      "lib/email.ts",
      "app/admin/actions.tsx",
      "app/actions/contact.ts",
    ]

    for (const file of criticalFiles) {
      if (fs.existsSync(file)) {
        results.push({
          step: `Build - ${file}`,
          status: "PASS",
          details: `Arquivo ${file} encontrado`,
        })
      } else {
        results.push({
          step: `Build - ${file}`,
          status: "FAIL",
          details: `Arquivo ${file} não encontrado`,
          patch: `Criar arquivo ${file} com conteúdo apropriado`,
        })
      }
    }
  } catch (error) {
    results.push({
      step: "Build - Geral",
      status: "FAIL",
      details: `Erro na validação de build: ${error}`,
      patch: "Verificar estrutura do projeto e dependências",
    })
  }

  // 2. ENVIRONMENT VALIDATION
  console.log("🌍 Validando Variáveis de Ambiente...")

  const requiredEnvVars = [
    "NEXT_PUBLIC_SUPABASE_URL",
    "SUPABASE_SERVICE_ROLE_KEY",
    "EMAIL_FROM",
    "SMTP_HOST",
    "SMTP_PORT",
    "SMTP_SECURE",
    "SMTP_USER",
    "SMTP_PASS",
    "NEXT_PUBLIC_APP_URL",
  ]

  for (const envVar of requiredEnvVars) {
    if (process.env[envVar]) {
      results.push({
        step: `Env - ${envVar}`,
        status: "PASS",
        details: `Variável ${envVar} configurada`,
      })
    } else {
      results.push({
        step: `Env - ${envVar}`,
        status: "FAIL",
        details: `Variável ${envVar} não configurada`,
        patch: `vercel env set ${envVar} "valor_aqui"`,
      })
    }
  }

  // 3. FILE STRUCTURE VALIDATION
  console.log("📁 Validando Estrutura de Arquivos...")

  const requiredDirs = ["app", "components", "lib", "scripts", "public"]

  for (const dir of requiredDirs) {
    if (fs.existsSync(dir) && fs.statSync(dir).isDirectory()) {
      results.push({
        step: `Structure - ${dir}/`,
        status: "PASS",
        details: `Diretório ${dir}/ encontrado`,
      })
    } else {
      results.push({
        step: `Structure - ${dir}/`,
        status: "FAIL",
        details: `Diretório ${dir}/ não encontrado`,
        patch: `mkdir -p ${dir}`,
      })
    }
  }

  // 4. TYPESCRIPT VALIDATION
  console.log("🔍 Validando TypeScript...")

  try {
    if (fs.existsSync("tsconfig.json")) {
      const tsconfig = JSON.parse(fs.readFileSync("tsconfig.json", "utf8"))

      results.push({
        step: "TypeScript - tsconfig.json",
        status: "PASS",
        details: "Configuração TypeScript encontrada",
      })

      // Verificar configurações críticas
      if (tsconfig.compilerOptions?.strict) {
        results.push({
          step: "TypeScript - strict mode",
          status: "PASS",
          details: "Modo strict habilitado",
        })
      } else {
        results.push({
          step: "TypeScript - strict mode",
          status: "FAIL",
          details: "Modo strict não habilitado",
          patch: 'Adicionar "strict": true em compilerOptions',
        })
      }
    } else {
      results.push({
        step: "TypeScript - tsconfig.json",
        status: "FAIL",
        details: "tsconfig.json não encontrado",
        patch: "Criar tsconfig.json com configurações Next.js",
      })
    }
  } catch (error) {
    results.push({
      step: "TypeScript - Parsing",
      status: "FAIL",
      details: `Erro ao analisar tsconfig.json: ${error}`,
      patch: "Verificar sintaxe do tsconfig.json",
    })
  }

  // 5. NEXT.JS CONFIG VALIDATION
  console.log("⚙️ Validando Configuração Next.js...")

  if (fs.existsSync("next.config.mjs")) {
    results.push({
      step: "Next.js - config",
      status: "PASS",
      details: "next.config.mjs encontrado",
    })
  } else if (fs.existsSync("next.config.js")) {
    results.push({
      step: "Next.js - config",
      status: "PASS",
      details: "next.config.js encontrado",
    })
  } else {
    results.push({
      step: "Next.js - config",
      status: "FAIL",
      details: "Configuração Next.js não encontrada",
      patch: "Criar next.config.mjs com configurações básicas",
    })
  }

  // RELATÓRIO FINAL
  console.log("\n" + "=".repeat(60))
  console.log("📊 RELATÓRIO FINAL DE VALIDAÇÃO")
  console.log("=".repeat(60))

  const passCount = results.filter((r) => r.status === "PASS").length
  const failCount = results.filter((r) => r.status === "FAIL").length
  const totalCount = results.length

  console.log(`✅ PASS: ${passCount}/${totalCount}`)
  console.log(`❌ FAIL: ${failCount}/${totalCount}`)
  console.log(`📈 Taxa de Sucesso: ${Math.round((passCount / totalCount) * 100)}%`)

  // Mostrar falhas
  const failures = results.filter((r) => r.status === "FAIL")
  if (failures.length > 0) {
    console.log("\n🔧 CORREÇÕES NECESSÁRIAS:")
    failures.forEach((failure, index) => {
      console.log(`\n${index + 1}. ${failure.step}`)
      console.log(`   Problema: ${failure.details}`)
      if (failure.patch) {
        console.log(`   Solução: ${failure.patch}`)
      }
    })
  }

  // Status final
  const isReadyForDeploy = failCount === 0
  console.log("\n" + "=".repeat(60))
  console.log(`🚀 PRONTO PARA DEPLOY: ${isReadyForDeploy ? "✅ SIM" : "❌ NÃO"}`)
  console.log("=".repeat(60))

  if (isReadyForDeploy) {
    console.log("🎉 Sistema validado com sucesso!")
    console.log("📋 Próximos passos:")
    console.log("   1. Execute o script SQL no Supabase")
    console.log("   2. Configure as variáveis de ambiente no Vercel")
    console.log("   3. Execute: vercel --prod")
  } else {
    console.log("⚠️  Corrija os problemas acima antes do deploy")
  }

  return {
    success: isReadyForDeploy,
    passCount,
    failCount,
    totalCount,
    results,
  }
}
