-- Script para reset completo de todos os dados
-- Execute este script no seu banco Neon para limpar completamente

-- Limpar arquivos de usuários
DELETE FROM user_files;

-- Limpar cadastros de usuários  
DELETE FROM user_registrations;

-- Resetar sequências (IDs) para começar do 1
ALTER SEQUENCE user_registrations_id_seq RESTART WITH 1;
ALTER SEQUENCE user_files_id_seq RESTART WITH 1;

-- Limpar configurações de teste (manter apenas as essenciais)
DELETE FROM system_settings WHERE setting_key NOT IN ('welcome_message');

-- Inserir mensagem de boas-vindas padrão
INSERT INTO system_settings (setting_key, setting_value, description, updated_at)
VALUES (
  'welcome_message',
  '🌟 Obrigada por se cadastrar na Rubi Agency! Recebemos sua candidatura e nossa equipe irá analisá-la cuidadosamente. Entraremos em contato em até 48 horas através do seu Instagram ou email.',
  'Mensagem exibida após o cadastro',
  NOW()
) ON CONFLICT (setting_key) DO UPDATE SET 
  setting_value = EXCLUDED.setting_value,
  updated_at = NOW();

-- Verificar se limpou tudo
SELECT 'Registrations' as table_name, COUNT(*) as count FROM user_registrations
UNION ALL
SELECT 'Files' as table_name, COUNT(*) as count FROM user_files
UNION ALL
SELECT 'Settings' as table_name, COUNT(*) as count FROM system_settings;

-- Confirmar reset
SELECT 'DATABASE RESET COMPLETED' as status, NOW() as timestamp;
