-- =====================================================
-- SCRIPT DE DADOS PADRÃO - RUBI AGENCY
-- Execute este script APÓS o script de criação de tabelas
-- =====================================================

-- =====================================================
-- CONFIGURAÇÕES DO SISTEMA
-- =====================================================

INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('site_name', 'Rubi Agency', 'Nome do site'),
('site_description', 'Agência especializada em criação de conteúdo para OnlyFans', 'Descrição do site'),
('contact_email', 'contato@rubiagency.com', 'Email de contato principal'),
('whatsapp_number', '+5511999999999', 'Número do WhatsApp para contato'),
('instagram_url', 'https://instagram.com/rubiagency', 'URL do Instagram'),
('facebook_url', 'https://facebook.com/rubiagency', 'URL do Facebook'),
('twitter_url', 'https://twitter.com/rubiagency', 'URL do Twitter'),
('linkedin_url', 'https://linkedin.com/company/rubiagency', 'URL do LinkedIn'),
('youtube_url', 'https://youtube.com/@rubiagency', 'URL do YouTube'),
('tiktok_url', 'https://tiktok.com/@rubiagency', 'URL do TikTok'),
('site_logo_url', '/rubi-agency-new-logo.png', 'URL do logo do site'),
('hero_title', 'Transforme sua presença digital com a Rubi Agency', 'Título principal da página inicial'),
('hero_subtitle', 'Somos especialistas em criação de conteúdo para OnlyFans e outras plataformas digitais', 'Subtítulo da página inicial'),
('about_title', 'Sobre a Rubi Agency', 'Título da seção sobre'),
('about_description', 'A Rubi Agency é uma agência especializada em criação de conteúdo para plataformas digitais, com foco em OnlyFans. Nossa equipe experiente ajuda criadores de conteúdo a maximizar seus ganhos e construir uma presença digital sólida.', 'Descrição da empresa'),
('services_title', 'Nossos Serviços', 'Título da seção de serviços'),
('contact_title', 'Entre em Contato', 'Título da seção de contato'),
('contact_description', 'Pronto para começar sua jornada conosco? Entre em contato e vamos conversar sobre como podemos ajudar você a alcançar seus objetivos.', 'Descrição da seção de contato'),
('footer_text', '© 2024 Rubi Agency. Todos os direitos reservados.', 'Texto do rodapé'),
('meta_keywords', 'rubi agency, onlyfans, criação de conteúdo, marketing digital, agência', 'Palavras-chave para SEO'),
('google_analytics_id', '', 'ID do Google Analytics'),
('facebook_pixel_id', '', 'ID do Facebook Pixel'),
('enable_blog', 'true', 'Habilitar seção de blog'),
('enable_testimonials', 'true', 'Habilitar seção de depoimentos'),
('enable_faq', 'true', 'Habilitar seção de FAQ'),
('enable_partners', 'true', 'Habilitar sistema de parceiros'),
('max_file_size', '10485760', 'Tamanho máximo de arquivo em bytes (10MB)'),
('allowed_file_types', 'jpg,jpeg,png,gif,pdf,doc,docx', 'Tipos de arquivo permitidos'),
('smtp_host', 'smtp.gmail.com', 'Servidor SMTP'),
('smtp_port', '587', 'Porta SMTP'),
('smtp_secure', 'true', 'Usar conexão segura SMTP'),
('email_from_name', 'Rubi Agency', 'Nome do remetente dos emails'),
('email_from_address', 'noreply@rubiagency.com', 'Email do remetente'),
('notification_email', 'admin@rubiagency.com', 'Email para notificações'),
('maintenance_mode', 'false', 'Modo de manutenção'),
('maintenance_message', 'Site em manutenção. Voltamos em breve!', 'Mensagem do modo de manutenção'),
('registration_enabled', 'true', 'Permitir novos registros'),
('auto_approve_registrations', 'false', 'Aprovar registros automaticamente'),
('require_age_verification', 'true', 'Exigir verificação de idade'),
('min_age', '18', 'Idade mínima para registro'),
('privacy_policy_url', '/privacy', 'URL da política de privacidade'),
('terms_of_service_url', '/terms', 'URL dos termos de serviço'),
('cookie_policy_url', '/cookies', 'URL da política de cookies')
ON CONFLICT (setting_key) DO UPDATE SET
    setting_value = EXCLUDED.setting_value,
    description = EXCLUDED.description,
    updated_at = NOW();

-- =====================================================
-- USUÁRIO ADMINISTRADOR PADRÃO
-- =====================================================

-- Senha: admin123 (hash bcrypt)
INSERT INTO admin_users (username, email, password_hash, is_active) VALUES
('admin', 'admin@rubiagency.com', '$2b$10$rQZ8kHWKQVXqKQYQQYQQQeJ8kHWKQVXqKQYQQYQQQeJ8kHWKQVXqKQ', true)
ON CONFLICT (username) DO UPDATE SET
    email = EXCLUDED.email,
    is_active = EXCLUDED.is_active,
    updated_at = NOW();

-- =====================================================
-- PARCEIROS DE EXEMPLO
-- =====================================================

INSERT INTO partners (name, email, code, description, commission_rate, is_active) VALUES
('Parceiro Exemplo 1', 'parceiro1@example.com', 'PARTNER01', 'Parceiro de exemplo para testes', 10.00, true),
('Parceiro Exemplo 2', 'parceiro2@example.com', 'PARTNER02', 'Segundo parceiro de exemplo', 15.00, true),
('Influencer Test', 'influencer@example.com', 'INFLUENCER', 'Influencer parceiro para testes', 20.00, false)
ON CONFLICT (code) DO UPDATE SET
    name = EXCLUDED.name,
    email = EXCLUDED.email,
    description = EXCLUDED.description,
    commission_rate = EXCLUDED.commission_rate,
    is_active = EXCLUDED.is_active,
    updated_at = NOW();

-- =====================================================
-- REGISTROS DE EXEMPLO (OPCIONAL - PARA TESTES)
-- =====================================================

INSERT INTO user_registrations (name, email, phone, instagram, age, subject, experience, message, status, partner_code, partner_name) VALUES
('Maria Silva', 'maria@example.com', '+5511999999999', '@maria_silva', 25, 'Criação de Conteúdo', 'Iniciante', 'Gostaria de saber mais sobre os serviços da agência.', 'pending', 'PARTNER01', 'Parceiro Exemplo 1'),
('Ana Santos', 'ana@example.com', '+5511888888888', '@ana_santos', 28, 'Marketing Digital', 'Intermediário', 'Tenho experiência com redes sociais e gostaria de expandir para OnlyFans.', 'approved', NULL, NULL),
('Julia Costa', 'julia@example.com', '+5511777777777', '@julia_costa', 22, 'Fotografia', 'Avançado', 'Sou fotógrafa e quero trabalhar com criação de conteúdo.', 'rejected', 'PARTNER02', 'Parceiro Exemplo 2')
ON CONFLICT DO NOTHING;

-- =====================================================
-- VERIFICAÇÃO DOS DADOS INSERIDOS
-- =====================================================

-- Contar registros inseridos
SELECT 
    'system_settings' as tabela, COUNT(*) as registros FROM system_settings
UNION ALL
SELECT 
    'admin_users' as tabela, COUNT(*) as registros FROM admin_users
UNION ALL
SELECT 
    'partners' as tabela, COUNT(*) as registros FROM partners
UNION ALL
SELECT 
    'user_registrations' as tabela, COUNT(*) as registros FROM user_registrations;

-- Mostrar algumas configurações importantes
SELECT setting_key, setting_value 
FROM system_settings 
WHERE setting_key IN ('site_name', 'contact_email', 'registration_enabled', 'min_age')
ORDER BY setting_key;

-- Mostrar usuários admin
SELECT username, email, is_active, created_at 
FROM admin_users 
ORDER BY created_at;

-- Mostrar parceiros ativos
SELECT name, code, commission_rate, is_active 
FROM partners 
WHERE is_active = true
ORDER BY name;

-- =====================================================
-- FINALIZAÇÃO
-- =====================================================

-- Atualizar estatísticas das tabelas
ANALYZE user_registrations;
ANALYZE partners;
ANALYZE system_settings;
ANALYZE admin_users;

-- Mensagem de sucesso
SELECT 'Dados padrão inseridos com sucesso!' as status;
