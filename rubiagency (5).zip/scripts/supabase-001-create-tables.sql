-- =====================================================
-- SCRIPT 1: CRIAÇÃO DE TABELAS PARA SUPABASE - RUBI AGENCY
-- =====================================================
-- Execute este script primeiro no Supabase SQL Editor
-- Dashboard > SQL Editor > New Query > Cole este código > Run

-- Habilitar extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =====================================================
-- 1. TABELA DE CONFIGURAÇÕES DO SISTEMA
-- =====================================================
CREATE TABLE IF NOT EXISTS system_settings (
    id BIGSERIAL PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT,
    description TEXT,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índice para performance
CREATE INDEX IF NOT EXISTS idx_system_settings_key ON system_settings(setting_key);

-- =====================================================
-- 2. TABELA DE USUÁRIOS ADMINISTRATIVOS
-- =====================================================
CREATE TABLE IF NOT EXISTS admin_users (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    last_login TIMESTAMPTZ
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_admin_users_username ON admin_users(username);
CREATE INDEX IF NOT EXISTS idx_admin_users_email ON admin_users(email);
CREATE INDEX IF NOT EXISTS idx_admin_users_is_active ON admin_users(is_active);

-- =====================================================
-- 3. TABELA DE PARCEIROS/AFILIADOS
-- =====================================================
CREATE TABLE IF NOT EXISTS partners (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    code VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    commission_rate DECIMAL(5,2) DEFAULT 0.00 CHECK (commission_rate >= 0 AND commission_rate <= 100),
    is_active BOOLEAN DEFAULT true,
    total_referrals INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_partners_code ON partners(code);
CREATE INDEX IF NOT EXISTS idx_partners_is_active ON partners(is_active);
CREATE INDEX IF NOT EXISTS idx_partners_email ON partners(email);

-- =====================================================
-- 4. TABELA DE REGISTROS DE USUÁRIOS
-- =====================================================
CREATE TABLE IF NOT EXISTS user_registrations (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    instagram VARCHAR(100),
    age INTEGER NOT NULL CHECK (age >= 18 AND age <= 100),
    subject VARCHAR(100),
    experience TEXT,
    message TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    partner_id BIGINT,
    partner_code VARCHAR(50),
    partner_name VARCHAR(255),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    approved_at TIMESTAMPTZ,
    approved_by VARCHAR(255)
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_user_registrations_status ON user_registrations(status);
CREATE INDEX IF NOT EXISTS idx_user_registrations_created_at ON user_registrations(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_registrations_email ON user_registrations(email);
CREATE INDEX IF NOT EXISTS idx_user_registrations_partner_code ON user_registrations(partner_code);

-- =====================================================
-- 5. TABELA DE POSTS DO BLOG
-- =====================================================
-- ** rest of code here **

-- =====================================================
-- 6. TABELA DE LOGS DE ATIVIDADES
-- =====================================================
-- ** rest of code here **

-- =====================================================
-- 7. TRIGGERS PARA UPDATED_AT AUTOMÁTICO
-- =====================================================

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers para atualizar updated_at automaticamente
CREATE TRIGGER update_system_settings_updated_at 
    BEFORE UPDATE ON system_settings 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_admin_users_updated_at 
    BEFORE UPDATE ON admin_users 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_partners_updated_at 
    BEFORE UPDATE ON partners 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_registrations_updated_at 
    BEFORE UPDATE ON user_registrations 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ** rest of code here **

-- =====================================================
-- 8. POLÍTICAS DE SEGURANÇA RLS
-- =====================================================

-- Habilitar RLS nas tabelas principais
ALTER TABLE user_registrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE partners ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Políticas para user_registrations
CREATE POLICY "Permitir leitura para service_role" ON user_registrations
    FOR SELECT USING (auth.role() = 'service_role');

CREATE POLICY "Permitir inserção para service_role" ON user_registrations
    FOR INSERT WITH CHECK (auth.role() = 'service_role');

CREATE POLICY "Permitir atualização para service_role" ON user_registrations
    FOR UPDATE USING (auth.role() = 'service_role');

-- Políticas para partners
CREATE POLICY "Permitir leitura para service_role" ON partners
    FOR SELECT USING (auth.role() = 'service_role');

CREATE POLICY "Permitir inserção para service_role" ON partners
    FOR INSERT WITH CHECK (auth.role() = 'service_role');

CREATE POLICY "Permitir atualização para service_role" ON partners
    FOR UPDATE USING (auth.role() = 'service_role');

-- Políticas para system_settings
CREATE POLICY "Permitir leitura para service_role" ON system_settings
    FOR SELECT USING (auth.role() = 'service_role');

CREATE POLICY "Permitir inserção para service_role" ON system_settings
    FOR INSERT WITH CHECK (auth.role() = 'service_role');

CREATE POLICY "Permitir atualização para service_role" ON system_settings
    FOR UPDATE USING (auth.role() = 'service_role');

-- Políticas para admin_users
CREATE POLICY "Permitir leitura para service_role" ON admin_users
    FOR SELECT USING (auth.role() = 'service_role');

CREATE POLICY "Permitir inserção para service_role" ON admin_users
    FOR INSERT WITH CHECK (auth.role() = 'service_role');

CREATE POLICY "Permitir atualização para service_role" ON admin_users
    FOR UPDATE USING (auth.role() = 'service_role');

-- ** rest of code here **

-- =====================================================
-- 9. COMENTÁRIOS NAS TABELAS
-- =====================================================

COMMENT ON TABLE user_registrations IS 'Registros de interesse dos usuários';
COMMENT ON TABLE partners IS 'Parceiros e afiliados do sistema';
COMMENT ON TABLE system_settings IS 'Configurações gerais do sistema';
COMMENT ON TABLE admin_users IS 'Usuários administrativos';

-- =====================================================
-- VERIFICAÇÃO FINAL
-- =====================================================

-- Verificar se todas as tabelas foram criadas
SELECT 
    schemaname,
    tablename,
    tableowner
FROM pg_tables 
WHERE schemaname = 'public' 
    AND tablename IN ('user_registrations', 'partners', 'system_settings', 'admin_users')
ORDER BY tablename;

-- Mostrar contagem de registros (deve ser 0 inicialmente)
SELECT 
    'user_registrations' as tabela, COUNT(*) as registros FROM user_registrations
UNION ALL
SELECT 
    'partners' as tabela, COUNT(*) as registros FROM partners
UNION ALL
SELECT 
    'system_settings' as tabela, COUNT(*) as registros FROM system_settings
UNION ALL
SELECT 
    'admin_users' as tabela, COUNT(*) as registros FROM admin_users;

-- Mensagem de sucesso
SELECT 'SCRIPT 1 EXECUTADO COM SUCESSO! Agora execute o SCRIPT 2.' as status;
