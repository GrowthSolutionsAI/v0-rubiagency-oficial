-- =====================================================
-- SCRIPT DE VALIDAÇÃO DO BANCO DE DADOS
-- =====================================================

-- Verificar se todas as tabelas existem
SELECT 
    'TABELAS EXISTENTES:' as info,
    '' as tabela,
    '' as status;

SELECT 
    table_name as tabela,
    CASE 
        WHEN table_name IN ('contact_registrations', 'partners', 'system_settings', 'admin_users') 
        THEN '✅ OK' 
        ELSE '❌ MISSING' 
    END as status
FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN ('contact_registrations', 'partners', 'system_settings', 'admin_users')
ORDER BY table_name;

-- Verificar estrutura das colunas principais
SELECT 
    'ESTRUTURA DAS TABELAS:' as info,
    '' as tabela,
    '' as coluna,
    '' as tipo;

-- contact_registrations
SELECT 
    'contact_registrations' as tabela,
    column_name as coluna,
    data_type as tipo
FROM information_schema.columns 
WHERE table_name = 'contact_registrations' 
AND table_schema = 'public'
ORDER BY ordinal_position;

-- partners
SELECT 
    'partners' as tabela,
    column_name as coluna,
    data_type as tipo
FROM information_schema.columns 
WHERE table_name = 'partners' 
AND table_schema = 'public'
ORDER BY ordinal_position;

-- Verificar índices
SELECT 
    'ÍNDICES CRIADOS:' as info,
    '' as indice,
    '' as tabela;

SELECT 
    indexname as indice,
    tablename as tabela
FROM pg_indexes 
WHERE schemaname = 'public' 
AND tablename IN ('contact_registrations', 'partners', 'system_settings', 'admin_users')
ORDER BY tablename, indexname;

-- Verificar triggers
SELECT 
    'TRIGGERS ATIVOS:' as info,
    '' as trigger_name,
    '' as table_name;

SELECT 
    trigger_name,
    event_object_table as table_name
FROM information_schema.triggers 
WHERE trigger_schema = 'public'
ORDER BY event_object_table, trigger_name;

-- Verificar dados inseridos
SELECT 
    'DADOS INSERIDOS:' as info,
    '' as tabela,
    0 as registros;

SELECT 
    'contact_registrations' as tabela,
    COUNT(*) as registros
FROM contact_registrations
UNION ALL
SELECT 
    'partners' as tabela,
    COUNT(*) as registros
FROM partners
UNION ALL
SELECT 
    'system_settings' as tabela,
    COUNT(*) as registros
FROM system_settings
UNION ALL
SELECT 
    'admin_users' as tabela,
    COUNT(*) as registros
FROM admin_users;

-- Verificar configurações críticas
SELECT 
    'CONFIGURAÇÕES CRÍTICAS:' as info,
    '' as setting_key,
    '' as setting_value;

SELECT 
    setting_key,
    CASE 
        WHEN setting_key LIKE '%pass%' THEN '***HIDDEN***'
        WHEN setting_key LIKE '%key%' THEN '***HIDDEN***'
        ELSE setting_value 
    END as setting_value
FROM system_settings 
WHERE setting_key IN (
    'site_name', 'email_service', 'smtp_host', 'smtp_port', 
    'smtp_user', 'email_from', 'contact_email', 'admin_email'
)
ORDER BY setting_key;

-- Verificar integridade dos dados
SELECT 
    'INTEGRIDADE DOS DADOS:' as info,
    '' as check_name,
    '' as result;

-- Verificar se há registros órfãos
SELECT 
    'Registros com partner_id inválido' as check_name,
    COUNT(*) as result
FROM contact_registrations cr
LEFT JOIN partners p ON cr.partner_id = p.id
WHERE cr.partner_id IS NOT NULL AND p.id IS NULL;

-- Verificar consistência de códigos de parceiros
SELECT 
    'Registros com partner_code inconsistente' as check_name,
    COUNT(*) as result
FROM contact_registrations cr
LEFT JOIN partners p ON cr.partner_code = p.code
WHERE cr.partner_code IS NOT NULL AND p.code IS NULL;

-- Verificar estatísticas dos parceiros
SELECT 
    'ESTATÍSTICAS DOS PARCEIROS:' as info,
    '' as partner_name,
    '' as code,
    0 as total_registrations,
    0 as approved_registrations;

SELECT 
    p.name as partner_name,
    p.code,
    p.total_registrations,
    p.approved_registrations
FROM partners p
ORDER BY p.total_registrations DESC;

-- Status final
SELECT 
    'STATUS FINAL DO BANCO:' as info,
    CASE 
        WHEN (SELECT COUNT(*) FROM contact_registrations) > 0 
        AND (SELECT COUNT(*) FROM partners) > 0 
        AND (SELECT COUNT(*) FROM system_settings) > 10 
        AND (SELECT COUNT(*) FROM admin_users) > 0 
        THEN '✅ BANCO PRONTO PARA PRODUÇÃO'
        ELSE '❌ BANCO INCOMPLETO'
    END as status;
