#!/bin/bash

echo "🚀 Iniciando deploy da Rubi Agency via Vercel CLI"

# Verificar se o Vercel CLI está instalado
if ! command -v vercel &> /dev/null; then
    echo "📦 Instalando Vercel CLI..."
    npm install -g vercel
fi

# Fazer login no Vercel (se necessário)
echo "🔐 Verificando autenticação..."
vercel whoami || vercel login

# Configurar projeto
echo "⚙️ Configurando projeto..."
vercel --confirm

# Adicionar variáveis de ambiente
echo "🔧 Configurando variáveis de ambiente..."
vercel env add NEXT_PUBLIC_SUPABASE_URL
vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY  
vercel env add SUPABASE_SERVICE_ROLE_KEY
vercel env add EMAIL_FROM
vercel env add SMTP_HOST
vercel env add SMTP_PORT
vercel env add SMTP_SECURE
vercel env add SMTP_USER
vercel env add SMTP_PASS
vercel env add NEXT_PUBLIC_APP_URL
vercel env add ADMIN_EMAIL

# Deploy para produção
echo "🚀 Fazendo deploy..."
vercel --prod

echo "✅ Deploy concluído!"
echo "🌐 Acesse seu site em: https://rubiagency.vercel.app"
