#!/bin/bash

echo "🔧 Configurando Vercel CLI para Rubi Agency"

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para imprimir com cores
print_step() {
    echo -e "${BLUE}$1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Passo 1: Verificar Node.js
print_step "1. Verificando Node.js..."
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    print_success "Node.js encontrado: $NODE_VERSION"
else
    print_error "Node.js não encontrado. Instale Node.js 18+ primeiro."
    exit 1
fi

# Passo 2: Verificar pnpm
print_step "2. Verificando pnpm..."
if command -v pnpm &> /dev/null; then
    PNPM_VERSION=$(pnpm --version)
    print_success "pnpm encontrado: $PNPM_VERSION"
else
    print_warning "pnpm não encontrado. Instalando..."
    npm install -g pnpm
fi

# Passo 3: Instalar Vercel CLI
print_step "3. Instalando Vercel CLI..."
if command -v vercel &> /dev/null; then
    VERCEL_VERSION=$(vercel --version)
    print_success "Vercel CLI já instalado: $VERCEL_VERSION"
else
    npm install -g vercel
    print_success "Vercel CLI instalado com sucesso!"
fi

# Passo 4: Verificar dependências do projeto
print_step "4. Instalando dependências do projeto..."
pnpm install

# Passo 5: Fazer login no Vercel
print_step "5. Fazendo login no Vercel..."
vercel whoami || {
    print_warning "Não logado. Iniciando processo de login..."
    vercel login
}

# Passo 6: Configurar projeto
print_step "6. Configurando projeto Vercel..."
echo -e "${YELLOW}"
echo "📋 Configurações recomendadas:"
echo "   - Project Name: rubiagency"
echo "   - Directory: ./"
echo "   - Framework: Next.js"
echo -e "${NC}"

# Passo 7: Instruções finais
print_step "7. Próximos passos:"
echo "   1. Execute: vercel"
echo "   2. Configure as variáveis de ambiente"
echo "   3. Execute: vercel --prod"

print_success "Setup do Vercel CLI concluído!"
