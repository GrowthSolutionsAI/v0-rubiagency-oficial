const { createClient } = require("@supabase/supabase-js")

// Configuração do Supabase
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

console.log("🚀 Iniciando migração para Supabase...")
console.log("📋 Verificando configuração...")

if (!supabaseUrl) {
  console.error("❌ NEXT_PUBLIC_SUPABASE_URL não configurada")
  process.exit(1)
}

if (!supabaseServiceKey) {
  console.error("❌ SUPABASE_SERVICE_ROLE_KEY não configurada")
  process.exit(1)
}

console.log("✅ Variáveis de ambiente configuradas")
console.log(`📍 URL: ${supabaseUrl}`)
console.log(`🔑 Service Key: ${supabaseServiceKey.substring(0, 20)}...`)

// Criar cliente Supabase
const supabase = createClient(supabaseUrl, supabaseServiceKey)

async function testConnection() {
  console.log("\n🔍 Testando conexão com Supabase...")

  try {
    const { data, error } = await supabase.from("system_settings").select("count", { count: "exact" }).limit(1)

    if (error) {
      console.error("❌ Erro na conexão:", error.message)
      return false
    }

    console.log("✅ Conexão estabelecida com sucesso")
    return true
  } catch (error) {
    console.error("❌ Erro inesperado:", error.message)
    return false
  }
}

async function validateTables() {
  console.log("\n📋 Validando estrutura das tabelas...")

  const tables = ["user_registrations", "partners", "system_settings", "admin_users"]

  const results = []

  for (const table of tables) {
    try {
      const { data, error } = await supabase.from(table).select("count", { count: "exact" }).limit(1)

      if (error) {
        console.log(`❌ Tabela ${table}: ${error.message}`)
        results.push({ table, exists: false, error: error.message })
      } else {
        console.log(`✅ Tabela ${table}: OK`)
        results.push({ table, exists: true, count: data?.length || 0 })
      }
    } catch (error) {
      console.log(`❌ Tabela ${table}: ${error.message}`)
      results.push({ table, exists: false, error: error.message })
    }
  }

  return results
}

async function testCRUD() {
  console.log("\n🧪 Testando operações CRUD...")

  try {
    // Teste de leitura
    console.log("📖 Testando leitura...")
    const { data: settings, error: readError } = await supabase.from("system_settings").select("*").limit(5)

    if (readError) {
      console.error("❌ Erro na leitura:", readError.message)
      return false
    }

    console.log(`✅ Leitura OK - ${settings?.length || 0} configurações encontradas`)

    // Teste de escrita (inserir configuração de teste)
    console.log("✏️ Testando escrita...")
    const testKey = `test_${Date.now()}`
    const { data: insertData, error: insertError } = await supabase
      .from("system_settings")
      .insert([
        {
          setting_key: testKey,
          setting_value: "test_value",
          description: "Teste de migração",
        },
      ])
      .select()

    if (insertError) {
      console.error("❌ Erro na escrita:", insertError.message)
      return false
    }

    console.log("✅ Escrita OK")

    // Teste de atualização
    console.log("🔄 Testando atualização...")
    const { error: updateError } = await supabase
      .from("system_settings")
      .update({ setting_value: "updated_value" })
      .eq("setting_key", testKey)

    if (updateError) {
      console.error("❌ Erro na atualização:", updateError.message)
      return false
    }

    console.log("✅ Atualização OK")

    // Teste de exclusão (limpar teste)
    console.log("🗑️ Limpando dados de teste...")
    const { error: deleteError } = await supabase.from("system_settings").delete().eq("setting_key", testKey)

    if (deleteError) {
      console.error("❌ Erro na exclusão:", deleteError.message)
      return false
    }

    console.log("✅ Exclusão OK")
    return true
  } catch (error) {
    console.error("❌ Erro no teste CRUD:", error.message)
    return false
  }
}

async function getStats() {
  console.log("\n📊 Coletando estatísticas...")

  try {
    // Estatísticas de registros
    const { data: registrations } = await supabase.from("user_registrations").select("status")

    const stats = {
      total: registrations?.length || 0,
      pending: registrations?.filter((r) => r.status === "pending").length || 0,
      approved: registrations?.filter((r) => r.status === "approved").length || 0,
      rejected: registrations?.filter((r) => r.status === "rejected").length || 0,
    }

    // Estatísticas de parceiros
    const { data: partners } = await supabase.from("partners").select("is_active")

    const partnerStats = {
      total: partners?.length || 0,
      active: partners?.filter((p) => p.is_active).length || 0,
    }

    // Configurações
    const { data: settings } = await supabase.from("system_settings").select("setting_key")

    console.log("📈 Estatísticas do sistema:")
    console.log(
      `   Registros: ${stats.total} (${stats.pending} pendentes, ${stats.approved} aprovados, ${stats.rejected} rejeitados)`,
    )
    console.log(`   Parceiros: ${partnerStats.total} (${partnerStats.active} ativos)`)
    console.log(`   Configurações: ${settings?.length || 0}`)

    return { registrations: stats, partners: partnerStats, settings: settings?.length || 0 }
  } catch (error) {
    console.error("❌ Erro ao coletar estatísticas:", error.message)
    return null
  }
}

async function main() {
  console.log("🎯 MIGRAÇÃO PARA SUPABASE - RUBI AGENCY")
  console.log("=".repeat(50))

  // 1. Testar conexão
  const connectionOK = await testConnection()
  if (!connectionOK) {
    console.log("\n❌ FALHA: Não foi possível conectar ao Supabase")
    console.log("🔧 Verifique:")
    console.log("   - Se o projeto Supabase está ativo")
    console.log("   - Se as variáveis de ambiente estão corretas")
    console.log("   - Se as chaves de API são válidas")
    process.exit(1)
  }

  // 2. Validar tabelas
  const tableResults = await validateTables()
  const missingTables = tableResults.filter((r) => !r.exists)

  if (missingTables.length > 0) {
    console.log("\n❌ FALHA: Tabelas não encontradas")
    console.log("🔧 Execute os scripts SQL no Supabase:")
    console.log("   1. scripts/supabase-001-create-tables.sql")
    console.log("   2. scripts/supabase-002-insert-default-data.sql")
    process.exit(1)
  }

  // 3. Testar CRUD
  const crudOK = await testCRUD()
  if (!crudOK) {
    console.log("\n❌ FALHA: Operações CRUD falharam")
    console.log("🔧 Verifique as políticas RLS no Supabase")
    process.exit(1)
  }

  // 4. Coletar estatísticas
  const stats = await getStats()

  // 5. Resultado final
  console.log("\n🎉 MIGRAÇÃO CONCLUÍDA COM SUCESSO!")
  console.log("=".repeat(50))
  console.log("✅ Conexão: OK")
  console.log("✅ Tabelas: OK")
  console.log("✅ Operações CRUD: OK")
  console.log("✅ Estatísticas: OK")

  if (stats) {
    console.log("\n📊 Sistema pronto para uso:")
    console.log(`   - ${stats.registrations.total} registros de usuários`)
    console.log(`   - ${stats.partners.total} parceiros cadastrados`)
    console.log(`   - ${stats.settings} configurações do sistema`)
  }

  console.log("\n🚀 Próximos passos:")
  console.log("   1. Execute: npm run dev")
  console.log("   2. Acesse: http://localhost:3000")
  console.log("   3. Admin: http://localhost:3000/admin (admin/admin123)")
  console.log("\n🔒 IMPORTANTE: Altere a senha do admin após o primeiro login!")
}

// Executar migração
main().catch((error) => {
  console.error("\n💥 ERRO FATAL:", error.message)
  process.exit(1)
})
