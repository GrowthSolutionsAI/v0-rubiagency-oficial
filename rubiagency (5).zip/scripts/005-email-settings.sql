-- Adicionar configurações de email SMTP
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('smtp_enabled', 'false', 'Habilitar envio de emails via SMTP'),
('smtp_provider', 'resend', 'Provedor de email (resend, smtp, sendgrid)'),
('smtp_host', '', 'Servidor SMTP (ex: smtp.gmail.com)'),
('smtp_port', '587', 'Porta SMTP (587 para TLS, 465 para SSL)'),
('smtp_secure', 'true', 'Usar conexão segura (TLS/SSL)'),
('smtp_user', '', 'Usuário SMTP / Email remetente'),
('smtp_password', '', 'Senha SMTP / API Key'),
('smtp_from_name', 'Rubi Agency', 'Nome do remetente'),
('smtp_from_email', '', 'Email remetente'),
('resend_api_key', '', 'Chave API do Resend'),
('sendgrid_api_key', '', 'Chave API do SendGrid'),
('email_test_recipient', '', 'Email para testes de configuração')
ON CONFLICT (setting_key) DO NOTHING;
