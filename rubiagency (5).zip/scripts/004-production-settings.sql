-- Configurações adicionais para produção
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('system_status', 'online', 'Status do sistema (online/maintenance)'),
('analytics_google_analytics_id', 'G-XXXXXXXXXX', 'Google Analytics 4 Measurement ID'),
('analytics_facebook_pixel_id', 'XXXXXXXXXXXXXXX', 'Facebook Pixel ID'),
('analytics_google_ads_id', 'AW-XXXXXXXXXX', 'Google Ads Conversion ID'),
('analytics_search_console_verified', 'false', 'Google Search Console verification status'),
('email_service_active', 'true', 'Status do serviço de email'),
('welcome_email_subject', 'Bem-vinda à Rubi Agency! 🌟', 'Assunto do email de boas-vindas'),
('welcome_email_body', 'Olá {name},

🌟 Obrigada por se cadastrar na Rubi Agency!

Recebemos sua candidatura e nossa equipe irá analisá-la cuidadosamente. Entraremos em contato em até 48 horas com mais informações.

Enquanto isso, siga-nos nas redes sociais para ficar por dentro das novidades:
📱 Instagram: @rubiagency
📘 Facebook: Rubi Agency

Estamos ansiosos para conhecer mais sobre você!

Atenciosamente,
Equipe Rubi Agency', 'Corpo do email de boas-vindas')
ON CONFLICT (setting_key) DO UPDATE SET 
    setting_value = EXCLUDED.setting_value,
    updated_at = CURRENT_TIMESTAMP;

-- Atualizar configurações existentes
UPDATE system_settings SET 
    setting_value = 'online',
    updated_at = CURRENT_TIMESTAMP
WHERE setting_key = 'system_status';

-- Verificar se todas as tabelas estão funcionando
SELECT 'Sistema configurado com sucesso!' as status;
