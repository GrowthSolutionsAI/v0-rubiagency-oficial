# 🎯 Configuração de Team no Vercel

## ✅ Problema Resolvido!

Você já está no team correto: **Personal Premium**

## 📋 Próximos Passos:

### 1. Fechar este menu
Clique fora do menu ou pressione ESC

### 2. Importar o Projeto
- Vá em "New Project" 
- Procure por `v0-rubiagency-lancamento`
- Clique em "Import"

### 3. Configurar o Deploy
- Project Name: `rubiagency`
- Framework: Next.js (auto-detectado)
- Build Command: `pnpm run build`
- Install Command: `pnpm install`

### 4. Adicionar Environment Variables
\`\`\`bash
NEXT_PUBLIC_SUPABASE_URL=https://lovnfxbjqclblzizokcn.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
EMAIL_FROM=contato@rubiagency.com
SMTP_HOST=smtp.gmail.com
SMTP_PORT=465
SMTP_SECURE=true
SMTP_USER=contato@rubiagency.com
SMTP_PASS=ymxmutrfrtzkeice
NEXT_PUBLIC_APP_URL=https://rubiagency.vercel.app
ADMIN_EMAIL=admin@rubiagency.com
\`\`\`

### 5. Deploy
Clique em "Deploy" e aguarde!

## 🚀 Recursos Premium Disponíveis:
- ✅ Build mais rápido
- ✅ Mais recursos de CPU/RAM
- ✅ Analytics avançados
- ✅ Domínios ilimitados
- ✅ Suporte prioritário

---

**Agora você pode usar todos os recursos Premium no seu projeto!**
