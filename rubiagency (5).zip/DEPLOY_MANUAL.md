# 📋 Manual Deployment Guide

## 🚀 Deploy sem GitHub (3 opções)

### **Opção 1: Vercel CLI (Recomendado)**

\`\`\`bash
# 1. Instalar Vercel CLI
npm install -g vercel

# 2. Fazer login
vercel login

# 3. Deploy
vercel

# 4. Deploy de produção
vercel --prod
\`\`\`

### **Opção 2: Upload Manual**

1. Acesse [vercel.com](https://vercel.com)
2. Clique em "Add New Project"
3. Escolha "Upload"
4. Faça upload do ZIP do projeto
5. Configure as variáveis de ambiente

### **Opção 3: Script Automático**

\`\`\`bash
# Dar permissão ao script
chmod +x deploy.sh

# Executar deploy
./deploy.sh
\`\`\`

## 🔧 Variáveis de Ambiente Obrigatórias

Configure no painel do Vercel:

\`\`\`env
# Supabase (Obrigatório)
NEXT_PUBLIC_SUPABASE_URL=sua_url_supabase
NEXT_PUBLIC_SUPABASE_ANON_KEY=sua_chave_anonima
SUPABASE_SERVICE_ROLE_KEY=sua_chave_service_role

# Email SMTP (Obrigatório)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=seu_email@gmail.com
SMTP_PASS=sua_senha_app

# Email Providers Alternativos (Opcional)
RESEND_API_KEY=sua_chave_resend
SENDGRID_API_KEY=sua_chave_sendgrid

# Admin (Obrigatório)
ADMIN_EMAIL=admin@rubiagency.com

# App URL (Automático no Vercel)
NEXT_PUBLIC_APP_URL=https://seu-projeto.vercel.app
\`\`\`

## 📋 Checklist Pré-Deploy

- [ ] ✅ Projeto buildando sem erros (`npm run build`)
- [ ] ✅ Supabase configurado e tabelas criadas
- [ ] ✅ Variáveis de ambiente definidas
- [ ] ✅ Email SMTP testado
- [ ] ✅ Domínio personalizado (opcional)

## 🔍 Verificação Pós-Deploy

1. **Teste o formulário de contato**
2. **Acesse o admin**: `/admin`
3. **Verifique emails**: Teste envio
4. **Teste responsividade**: Mobile/Desktop
5. **Performance**: Lighthouse score

## 🆘 Troubleshooting

### **Erro de Build:**
\`\`\`bash
# Limpar cache
rm -rf .next node_modules
npm install
npm run build
\`\`\`

### **Erro de Email:**
- Verificar credenciais SMTP
- Testar com Gmail App Password
- Verificar firewall/porta 587

### **Erro de Database:**
- Verificar URL do Supabase
- Executar scripts SQL
- Verificar permissões RLS

## 📞 Suporte

Se precisar de ajuda:
1. Verificar logs no Vercel
2. Testar localmente primeiro
3. Verificar todas as variáveis de ambiente
